import React, { useState, useEffect, useRef } from "react";
import { collection, query, where, onSnapshot, doc, setDoc, updateDoc, deleteDoc } from "firebase/firestore";
import { db, handleFirestoreError, OperationType } from "./firebase";
import { Raffle, Ticket, UserProfile, Winner } from "./types";
import { compressImage } from "./utils";
import RaffleDetailModal from "./components/RaffleDetailModal";
import CustomAuthModal from "./components/CustomAuthModal";
import AdminPanel from "./components/AdminPanel";
import CreatorPanel from "./components/CreatorPanel";
import TermsModal from "./components/TermsModal";
import { 
  Award, Clock, Coins, UserCheck, HelpCircle, Flame, ShieldAlert, Sparkles, AlertTriangle, ExternalLink,
  Loader2, RefreshCw, X, Clover, LogIn, LogOut, ChevronRight, User as UserIcon, Plus, Trash, Search, Users,
  CheckSquare, Square, Check, ArrowRight, Upload, Play, Ticket as TicketIcon, Phone, FileText, CheckCircle2, ChevronDown, ListFilter, SlidersHorizontal, Copy, Trophy
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

const formatCPF = (val: string) => {
  const parts = val.replace(/\D/g, "");
  if (parts.length !== 11) return val;
  return `${parts.substring(0, 3)}.${parts.substring(3, 6)}.${parts.substring(6, 9)}-${parts.substring(9, 11)}`;
};

// Helper component to track and render raffle progress dynamically
function RaffleProgress({ 
  raffleId, 
  totalNumbers, 
  allTicketsList, 
  isQuotaExceeded 
}: { 
  raffleId: string; 
  totalNumbers: number; 
  allTicketsList?: Ticket[]; 
  isQuotaExceeded?: boolean; 
}) {
  const [reservedCount, setReservedCount] = useState(0);

  useEffect(() => {
    if (isQuotaExceeded && allTicketsList) {
      const count = allTicketsList.filter(
        (t) => t.raffleId === raffleId && (t.status === "pending" || t.status === "confirmed")
      ).length;
      setReservedCount(count);
      return;
    }

    const q = query(
      collection(db, "tickets"),
      where("raffleId", "==", raffleId),
      where("status", "in", ["pending", "confirmed"])
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      setReservedCount(snapshot.size);
    }, (error) => {
      const errMsg = error?.message || String(error);
      const isQuota = errMsg.toLowerCase().includes("quota") ||
                      errMsg.toLowerCase().includes("limit") ||
                      errMsg.toLowerCase().includes("exhausted");

      if (isQuota) {
        console.warn("Firestore Read Quota exceeded in RaffleProgress, falling back to local list: ", raffleId);
        if (allTicketsList) {
          const count = allTicketsList.filter(
            (t) => t.raffleId === raffleId && (t.status === "pending" || t.status === "confirmed")
          ).length;
          setReservedCount(count);
        }
      } else {
        console.warn("Error loading tickets count: ", error);
      }
    });

    return () => unsubscribe();
  }, [raffleId, isQuotaExceeded, allTicketsList]);

  const soldPercent = Math.min(100, Math.max(0, Math.round((reservedCount / totalNumbers) * 100)));

  return (
    <div className="space-y-1.5 text-left">
      <div className="flex justify-between items-center text-[10px] font-bold uppercase tracking-wider text-zinc-400">
        <span>Cotas Reservadas</span>
        <span className="text-fuchsia-400 font-extrabold">{soldPercent}%</span>
      </div>
      <div className="w-full bg-zinc-950/80 h-2 rounded-full overflow-hidden flex border border-zinc-800/80 p-[1px]">
        <div 
          className="h-full bg-gradient-to-r from-fuchsia-500 via-pink-500 to-indigo-600 rounded-full transition-all duration-500 ease-out shadow-[0_0_8px_rgba(236,72,153,0.6)]"
          style={{ width: `${soldPercent}%` }}
        />
      </div>
    </div>
  );
}

export default function App() {
  const [user, setUser] = useState<any>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [ticketCounts, setTicketCounts] = useState<{[key: string]: number}>({});

  // Navigation tab state
  const [currentTab, setCurrentTab] = useState<"home" | "create" | "manage" | "tickets" | "ranking" | "historico">("home");

  // Modals & overlay boards
  const [selectedRaffle, setSelectedRaffle] = useState<Raffle | null>(null);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showProfileDropdown, setShowProfileDropdown] = useState(false);
  const [showAdminPanel, setShowAdminPanel] = useState(false);
  const [showCreatorPanel, setShowCreatorPanel] = useState(false);
  const [adminPanelDefaultTab, setAdminPanelDefaultTab] = useState<"sorteios" | "transacoes" | "ganhadores" | "usuarios" | "logs_compras" | "config" | "afiliados" | "cadastrar_afiliado" | undefined>(undefined);
  const [showTermsModal, setShowTermsModal] = useState(false);

  // Active/Finished list sub-filter
  const [listFilter, setListFilter] = useState<"ativos" | "realizados">("ativos");
  
  // Real-time Firestore synchronized states
  const [raffles, setRaffles] = useState<Raffle[]>([]);
  const [allTickets, setAllTickets] = useState<Ticket[]>([]); // Sourced for live creator panel filters
  const [myTickets, setMyTickets] = useState<Ticket[]>([]);
  const [winners, setWinners] = useState<Winner[]>([]);
  const [affiliates, setAffiliates] = useState<any[]>([]);
  const [isQuotaExceeded, setIsQuotaExceeded] = useState(false);

  const checkForQuotaError = (err: any, context: string) => {
    const errMsg = err?.message || String(err);
    const isQuota = errMsg.toLowerCase().includes("quota") ||
                    errMsg.toLowerCase().includes("limit") ||
                    errMsg.toLowerCase().includes("exhausted");
    
    if (isQuota) {
      console.warn(`Firestore Database Quota Limit reached during subscription (${context}) — Switching to offline/simulated mode.`, err);
      if (!isQuotaExceeded) {
        setIsQuotaExceeded(true);
      }
    } else {
      console.warn(`Error loading database source (${context}):`, err);
    }
    setLoading(false);
  };

  // NEW RAFFLE FORM STATE (Criador / Renter)
  const [newTitle, setNewTitle] = useState("");
  const [newAward, setNewAward] = useState("");
  const [newDescription, setNewDescription] = useState("");
  const [newPrice, setNewPrice] = useState("10.00");
  const [newNumbersAmount, setNewNumbersAmount] = useState<100 | 1000>(100);
  const [newDrawDate, setNewDrawDate] = useState("");
  const [newPixKey, setNewPixKey] = useState("");
  const [newPixName, setNewPixName] = useState("");
  const [newImageBase64, setNewImageBase64] = useState("");
  const [creatingLoading, setCreatingLoading] = useState(false);
  const [createError, setCreateError] = useState("");
  const [clientSearch, setClientSearch] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  // ACTIVE MANAGEMENT WORKSPACE (Renter cockpit stats + Quota batches)
  const [confirmDialog, setConfirmDialog] = useState<{
    title: string;
    description: string;
    onConfirm: () => void;
  } | null>(null);
  const [selectedRaffleToManage, setSelectedRaffleToManage] = useState<Raffle | null>(null);
  const [quotaGridSearch, setQuotaGridSearch] = useState("");
  const [quotaFilter, setQuotaFilter] = useState<"all" | "free" | "pending" | "confirmed">("all");
  const [gridPaginationRange, setGridPaginationRange] = useState({ start: 0, end: 199 });
  
  // Batch Multi-Select Mode
  const [multiSelectEnabled, setMultiSelectEnabled] = useState(false);
  const [selectedQuotasForBatch, setSelectedQuotasForBatch] = useState<number[]>([]);
  const [batchActionType, setBatchActionType] = useState<"free" | "pending" | "confirmed">("confirmed");
  const [batchBuyerName, setBatchBuyerName] = useState("");
  const [batchBuyerPhone, setBatchBuyerPhone] = useState("");
  const [batchSubmitLoading, setBatchSubmitLoading] = useState(false);

  // Live Winner Drawing panel
  const [showDrawModal, setShowDrawModal] = useState(false);
  const [drawMethod, setDrawMethod] = useState<"system" | "manual">("system");
  const [manualWinningNum, setManualWinningNum] = useState<number | "">("");
  const [drawnWinnerTicket, setDrawnWinnerTicket] = useState<Ticket | null>(null);
  const [drawnWinnerPhoto, setDrawnWinnerPhoto] = useState<string>("");
  const fileWinnerRef = useRef<HTMLInputElement>(null);

  const [isSpinning, setIsSpinning] = useState(false);
  const [spinNum, setSpinNum] = useState<number>(0);
  const [drawError, setDrawError] = useState("");
  const [drawSuccess, setDrawSuccess] = useState("");
  const [savingDrawLoading, setSavingDrawLoading] = useState(false);

  // Tenant-isolation states & copy clipboard indicators
  const [isolatedRaffleId, setIsolatedRaffleId] = useState<string | null>(null);
  const [isolatedCreatorUid, setIsolatedCreatorUid] = useState<string | null>(null);
  const [copiedType, setCopiedType] = useState<"single" | "vitrine" | null>(null);

  // 1. Listen to Custom CPF Auth Session states
  useEffect(() => {
    setLoading(true);
    const savedCpf = localStorage.getItem("lucky_user_cpf");
    if (savedCpf) {
      if (savedCpf === "admicarlos") {
        // Logged in as master administrator
        setIsAdmin(true);
        setProfile({
          uid: "admicarlos",
          name: "Admin Carlos",
          cpf: "admicarlos",
          phone: "(00) 00000-0000",
          birthDate: "1990-01-01",
          photo: "",
          email: "admin@luckyneon.com",
          isAdmin: true,
          createdAt: new Date().toISOString()
        });
        setUser({ uid: "admicarlos" });
        setLoading(false);
      } else {
        // Standard participant listener
        const unsub = onSnapshot(doc(db, "users", savedCpf), (docSnap) => {
          if (docSnap.exists()) {
            const docData = docSnap.data() as UserProfile;
            setProfile(docData);
            setIsAdmin(docData.isAdmin || false);
            setUser({ uid: savedCpf });
          } else {
            // Document removed or not found, clear
            localStorage.removeItem("lucky_user_cpf");
            setProfile(null);
            setIsAdmin(false);
            setUser(null);
          }
          setLoading(false);
        }, (err) => {
          console.error("Error loaded custom profile: ", err);
          checkForQuotaError(err, "custom profile");
          setLoading(false);
        });
        return () => unsub();
      }
    } else {
      setProfile(null);
      setIsAdmin(false);
      setUser(null);
      setLoading(false);
    }
  }, []);

  // 1b. Check for Tenant-Isolated URL links (e.g. ?r=raffleId or ?c=creatorUid)
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const rParam = params.get("r") || params.get("rifa");
    const cParam = params.get("c") || params.get("criador");
    if (rParam) {
      setIsolatedRaffleId(rParam);
    }
    if (cParam) {
      setIsolatedCreatorUid(cParam);
    }
  }, []);

  // 1c. Auto-focus isolated raffle details when list is ready
  useEffect(() => {
    if (isolatedRaffleId && raffles.length > 0) {
      const match = raffles.find(r => r.id === isolatedRaffleId);
      if (match) {
        setSelectedRaffle(match);
      }
    }
  }, [isolatedRaffleId, raffles]);

  // 2. Load active/finished raffles in real-time
  useEffect(() => {
    const qRaffles = query(collection(db, "raffles"));
    const unsubscribe = onSnapshot(qRaffles, (snapshot) => {
      const list: Raffle[] = [];
      snapshot.forEach((doc) => {
        list.push({ id: doc.id, ...doc.data() } as Raffle);
      });
      setRaffles(list.sort((a, b) => b.createdAt.localeCompare(a.createdAt)));
    }, (error) => {
      console.error("Error loaded raffles:", error);
      checkForQuotaError(error, "raffles");
    });

    return () => unsubscribe();
  }, []);

  // 3. Listen to all tickets (for creator stats and management view)
  useEffect(() => {
    const qTickets = query(collection(db, "tickets"));
    const unsubscribe = onSnapshot(qTickets, (snapshot) => {
      const list: Ticket[] = [];
      snapshot.forEach((doc) => {
        list.push({ id: doc.id, ...doc.data() } as Ticket);
      });
      setAllTickets(list);
    }, (error) => {
      console.error("Error loading global tickets: ", error);
      checkForQuotaError(error, "global tickets");
    });

    return () => unsubscribe();
  }, []);

  // 3b. Listen to all affiliates (used to hide paused campaigns and filter logs)
  useEffect(() => {
    const qAffiliates = query(collection(db, "affiliates"));
    const unsubscribe = onSnapshot(qAffiliates, (snapshot) => {
      const list: any[] = [];
      snapshot.forEach((doc) => {
        list.push({ id: doc.id, ...doc.data() });
      });
      setAffiliates(list);
    }, (error) => {
      console.error("Error loading affiliates: ", error);
      checkForQuotaError(error, "affiliates");
    });

    return () => unsubscribe();
  }, []);

  // 4. Listen to Current User's Tickets in real-time if logged in
  useEffect(() => {
    if (!profile) {
      setMyTickets([]);
      return;
    }

    const qTickets = query(
      collection(db, "tickets"),
      where("userCpf", "==", profile.cpf)
    );

    const unsubscribe = onSnapshot(qTickets, (snapshot) => {
      const list: Ticket[] = [];
      snapshot.forEach((doc) => {
        list.push(doc.data() as Ticket);
      });
      setMyTickets(list.sort((a, b) => b.reservedAt.localeCompare(a.reservedAt)));
    }, (error) => {
      console.error("Error loading my tickets: ", error);
      checkForQuotaError(error, "my tickets");
    });

    return () => unsubscribe();
  }, [profile]);

  // 5. Listen to Winners list in real-time
  useEffect(() => {
    const qWinners = query(collection(db, "winners"));
    const unsubscribe = onSnapshot(qWinners, (snapshot) => {
      const list: Winner[] = [];
      snapshot.forEach((doc) => {
        list.push({ id: doc.id, ...doc.data() } as Winner);
      });
      setWinners(list.sort((a, b) => b.announcedAt.localeCompare(a.announcedAt)));
    }, (error) => {
      console.error("Error loading winners from db: ", error);
      checkForQuotaError(error, "winners from db");
    });

    return () => unsubscribe();
  }, []);

  // 5b. Seeding mock fallback lists securely when Firestore Quota Limit is Exceeded
  useEffect(() => {
    if (isQuotaExceeded) {
      console.warn("Firestore Daily Quota Limit detected. Initializing client-side fallback simulation data.");
      
      const mockRaffles: Raffle[] = [
        {
          id: "mock_raffle_1",
          title: "Pix de R$ 10.000,00 Mil",
          description: "Concorra a R$ 10.000,00 diretamente na sua conta com apenas R$ 1,00 por bilhete! O sorteio mais quente da semana.",
          image: "https://images.unsplash.com/photo-1598257006458-087169a1f08d?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
          pricePerTicket: 1.00,
          totalNumbers: 100,
          status: "active",
          award: "R$ 10.000,00 no PIX",
          createdAt: new Date(Date.now() - 3600000 * 24).toISOString(),
          creatorUid: "demo_creator",
          creatorName: "Lucador Oficial",
          pixKey: "luckyneon@pix.com",
          pixReceiver: "LuckyNeon S.A."
        },
        {
          id: "mock_raffle_2",
          title: "iPhone 15 Pro Max 256GB Titanium",
          description: "A joia tecnológica da Apple pode ser sua por menos de uma xícara de café. Todos os números com frete grátis nacional.",
          image: "https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
          pricePerTicket: 1.50,
          totalNumbers: 100,
          status: "active",
          award: "iPhone 15 Pro Max Titanium",
          createdAt: new Date(Date.now() - 3600000 * 48).toISOString(),
          creatorUid: "admicarlos",
          creatorName: "Admin Carlos",
          pixKey: "admin@luckyneon.com",
          pixReceiver: "Carlos Administrador"
        },
        {
          id: "mock_raffle_3",
          title: "PlayStation 5 Slim Marvel Bundle",
          description: "Console de nova geração com 2 controles e o jogo do Homem-Aranha incluso. Viva o poder e a velocidade extrema.",
          image: "https://images.unsplash.com/photo-1606813907291-d86efa9b94db?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
          pricePerTicket: 2.00,
          totalNumbers: 100,
          status: "finished",
          award: "PlayStation 5 Slim Bundle",
          createdAt: new Date(Date.now() - 3600000 * 72).toISOString(),
          creatorUid: "demo_creator",
          creatorName: "Lucador Oficial",
          pixKey: "ps@luckypix.com",
          pixReceiver: "Sorteios PS Ltda."
        }
      ];

      const userList = [
        { cpf: "11122233344", name: "Gabriel Martins", phone: "(11) 98765-4321" },
        { cpf: "22233344455", name: "Beatriz Oliveira", phone: "(21) 99888-7766" },
        { cpf: "33344455566", name: "Rodrigo Santos", phone: "(31) 97777-6655" }
      ];

      const mockTickets: Ticket[] = [
        {
          id: "mock_raffle_1_12",
          raffleId: "mock_raffle_1",
          ticketNumber: 12,
          userCpf: userList[0].cpf,
          userName: userList[0].name,
          userPhone: userList[0].phone,
          status: "confirmed",
          reservedAt: new Date(Date.now() - 3600000 * 5).toISOString(),
          confirmedAt: new Date(Date.now() - 3600000 * 4.8).toISOString()
        },
        {
          id: "mock_raffle_1_13",
          raffleId: "mock_raffle_1",
          ticketNumber: 13,
          userCpf: userList[0].cpf,
          userName: userList[0].name,
          userPhone: userList[0].phone,
          status: "confirmed",
          reservedAt: new Date(Date.now() - 3600000 * 5).toISOString(),
          confirmedAt: new Date(Date.now() - 3600000 * 4.8).toISOString()
        },
        {
          id: "mock_raffle_1_25",
          raffleId: "mock_raffle_1",
          ticketNumber: 25,
          userCpf: userList[1].cpf,
          userName: userList[1].name,
          userPhone: userList[1].phone,
          status: "pending",
          reservedAt: new Date(Date.now() - 3600000 * 2).toISOString()
        },
        {
          id: "mock_raffle_1_45",
          raffleId: "mock_raffle_1",
          ticketNumber: 45,
          userCpf: userList[2].cpf,
          userName: userList[2].name,
          userPhone: userList[2].phone,
          status: "confirmed",
          reservedAt: new Date(Date.now() - 3600000 * 1).toISOString(),
          confirmedAt: new Date(Date.now() - 3600000 * 0.9).toISOString()
        },
        {
          id: "mock_raffle_2_7",
          raffleId: "mock_raffle_2",
          ticketNumber: 7,
          userCpf: userList[1].cpf,
          userName: userList[1].name,
          userPhone: userList[1].phone,
          status: "confirmed",
          reservedAt: new Date(Date.now() - 3600000 * 12).toISOString(),
          confirmedAt: new Date(Date.now() - 3600000 * 11).toISOString()
        },
        {
          id: "mock_raffle_2_88",
          raffleId: "mock_raffle_2",
          ticketNumber: 88,
          userCpf: userList[2].cpf,
          userName: userList[2].name,
          userPhone: userList[2].phone,
          status: "pending",
          reservedAt: new Date(Date.now() - 3600000 * 4).toISOString()
        }
      ];

      const mockWinners: Winner[] = [
        {
          id: "win_mock_raffle_3",
          raffleId: "mock_raffle_3",
          raffleTitle: "PlayStation 5 Slim Marvel Bundle",
          userName: "Rodrigo Santos",
          userCpf: "33344455566",
          winningNumber: 42,
          award: "PlayStation 5 Slim Bundle",
          prizePhoto: "https://images.unsplash.com/photo-1606813907291-d86efa9b94db?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
          announcedAt: new Date(Date.now() - 3600000 * 12).toISOString()
        }
      ];

      setRaffles(prev => prev.length === 0 ? mockRaffles : prev);
      setAllTickets(prev => prev.length === 0 ? mockTickets : prev);
      setWinners(prev => prev.length === 0 ? mockWinners : prev);

      const savedCpf = localStorage.getItem("lucky_user_cpf");
      if (savedCpf && !profile) {
        if (savedCpf === "admicarlos") {
          setIsAdmin(true);
          setProfile({
            uid: "admicarlos",
            name: "Admin Carlos",
            cpf: savedCpf,
            phone: "(00) 00000-0000",
            birthDate: "1990-01-01",
            photo: "",
            email: "admin@luckyneon.com",
            isAdmin: true,
            createdAt: new Date().toISOString()
          });
          setUser({ uid: savedCpf });
        } else {
          setProfile({
            uid: savedCpf,
            name: "Parceiro Lucky",
            cpf: savedCpf,
            phone: "(11) 99999-9999",
            birthDate: "1995-10-10",
            photo: "",
            email: "user@luckyneon.com",
            isAdmin: false,
            isCreator: true,
            createdAt: new Date().toISOString()
          });
          setUser({ uid: savedCpf });
        }
      }
      setLoading(false);
    }
  }, [isQuotaExceeded]);

  // Compute hottest raffle (with most bookings / confirmation)
  useEffect(() => {
    if (raffles.length === 0) return;
    const counts: {[key: string]: number} = {};
    allTickets.forEach(t => {
      if (t.status === "pending" || t.status === "confirmed") {
        counts[t.raffleId] = (counts[t.raffleId] || 0) + 1;
      }
    });
    setTicketCounts(counts);
  }, [raffles, allTickets]);

  const hottestRaffleId = React.useMemo(() => {
    let maxCount = 0;
    let maxId = "";
    const activeList = raffles.filter((r) => r.status === "active");
    activeList.forEach(r => {
      const count = ticketCounts[r.id] || 0;
      if (count > maxCount) {
        maxCount = count;
        maxId = r.id;
      }
    });
    return maxCount > 0 ? maxId : "";
  }, [raffles, ticketCounts]);

  // Statistics computations
  const totalSaaSStatistics = React.useMemo(() => {
    const affiliateCpfs = new Set(affiliates.map(a => a.cpf));
    // If Admin: only their own master campaigns. If regular logged creator: only their rented raffles!
    const targetRaffles = profile?.isAdmin 
      ? raffles.filter(r => !r.creatorUid || !affiliateCpfs.has(r.creatorUid))
      : raffles.filter(r => r.creatorUid === profile?.uid);

    const totalCampaigns = targetRaffles.length;
    const activeCampaigns = targetRaffles.filter(r => r.status === "active").length;
    const completedCampaigns = targetRaffles.filter(r => r.status === "finished").length;

    let totalRevenue = 0;
    allTickets.forEach(t => {
      const isLinkedRaffle = targetRaffles.some(r => r.id === t.raffleId);
      if (isLinkedRaffle && t.status === "confirmed") {
        const rDetail = targetRaffles.find(r => r.id === t.raffleId);
        totalRevenue += (rDetail ? rDetail.pricePerTicket : 10.00);
      }
    });

    return {
      totalCampaigns,
      activeCampaigns,
      completedCampaigns,
      totalRevenue
    };
  }, [raffles, allTickets, profile, affiliates]);

  // Ranking states & calculations
  const [selectedRankingRaffleId, setSelectedRankingRaffleId] = useState<string>("");

  const activeRafflesForRanking = React.useMemo(() => {
    let list = raffles.filter(r => r.status === "active");

    // Filter out paused affiliates
    list = list.filter((r) => {
      if (!r.creatorUid) return true;
      const aff = affiliates.find(a => a.cpf === r.creatorUid || a.id === r.creatorUid);
      if (aff && aff.status === "paused") {
        return false;
      }
      return true;
    });

    if (profile && profile.isCreator && !profile.isAdmin) {
      list = list.filter(r => r.creatorUid === profile.uid);
    } else if (profile && profile.isAdmin) {
      const affiliateCpfs = new Set(affiliates.map(a => a.cpf));
      list = list.filter(r => !r.creatorUid || !affiliateCpfs.has(r.creatorUid));
    } else {
      if (isolatedRaffleId) {
        list = list.filter(r => r.id === isolatedRaffleId);
      } else if (isolatedCreatorUid) {
        list = list.filter(r => r.creatorUid === isolatedCreatorUid);
      } else {
        const affiliateCpfs = new Set(affiliates.map(a => a.cpf));
        list = list.filter(r => !r.creatorUid || !affiliateCpfs.has(r.creatorUid));
      }
    }
    return list;
  }, [raffles, isolatedRaffleId, isolatedCreatorUid, profile, affiliates]);

  // Find active raffles where the current user actually holds tickets
  const userActiveRafflesWithTickets = React.useMemo(() => {
    if (!profile) return [];
    if (profile.isAdmin) return activeRafflesForRanking; // Administrators can view all active raffles
    return activeRafflesForRanking.filter(r =>
      allTickets.some(t => t.raffleId === r.id && t.userCpf === profile.cpf)
    );
  }, [activeRafflesForRanking, allTickets, profile]);

  // Automatically select the appropriate raffle ranking based on user context
  useEffect(() => {
    if (profile) {
      if (userActiveRafflesWithTickets.length > 0) {
        // If the current selected ID is not in their ticket-associated active list, set it to the first one available
        if (!userActiveRafflesWithTickets.some(r => r.id === selectedRankingRaffleId)) {
          setSelectedRankingRaffleId(userActiveRafflesWithTickets[0].id);
        }
      } else if (activeRafflesForRanking.length > 0) {
        // Fallback for user without any tickets in active raffles so they can still see locked banners correctly
        if (!activeRafflesForRanking.some(r => r.id === selectedRankingRaffleId)) {
          setSelectedRankingRaffleId(activeRafflesForRanking[0].id);
        }
      }
    } else {
      // Unauthenticated fallback
      if (activeRafflesForRanking.length > 0 && (!selectedRankingRaffleId || !activeRafflesForRanking.some(r => r.id === selectedRankingRaffleId))) {
        setSelectedRankingRaffleId(activeRafflesForRanking[0].id);
      }
    }
  }, [profile, userActiveRafflesWithTickets, activeRafflesForRanking, selectedRankingRaffleId]);

  const rankingList = React.useMemo(() => {
    if (!selectedRankingRaffleId) return [];

    const raffleConfirmedTickets = allTickets.filter(
      t => t.raffleId === selectedRankingRaffleId && t.status === "confirmed"
    );

    const userCounts: { [key: string]: { name: string; cpf: string; phone: string; count: number } } = {};
    raffleConfirmedTickets.forEach(t => {
      if (!userCounts[t.userCpf]) {
        userCounts[t.userCpf] = {
          name: t.userName || "Participante",
          cpf: t.userCpf,
          phone: t.userPhone || "",
          count: 0
        };
      }
      userCounts[t.userCpf].count += 1;
    });

    return Object.values(userCounts).sort((a, b) => b.count - a.count);
  }, [allTickets, selectedRankingRaffleId]);

  const hasPurchasedForSelectedRaffle = React.useMemo(() => {
    if (!profile) return false;
    if (profile.isAdmin) return true; // Admins can always see the ranking
    return allTickets.some(t => t.raffleId === selectedRankingRaffleId && t.userCpf === profile.cpf);
  }, [allTickets, selectedRankingRaffleId, profile]);

  const activeRaffles = React.useMemo(() => {
    let list = raffles.filter((r) => r.status === "active");

    // Filter out paused affiliates
    list = list.filter((r) => {
      if (!r.creatorUid) return true;
      const aff = affiliates.find(a => a.cpf === r.creatorUid || a.id === r.creatorUid);
      if (aff && aff.status === "paused") {
        return false;
      }
      return true;
    });

    if (profile && profile.isCreator && !profile.isAdmin) {
      list = list.filter((r) => r.creatorUid === profile.uid);
    } else if (profile && profile.isAdmin) {
      const affiliateCpfs = new Set(affiliates.map(a => a.cpf));
      list = list.filter((r) => !r.creatorUid || !affiliateCpfs.has(r.creatorUid));
    } else {
      if (isolatedRaffleId) {
        list = list.filter((r) => r.id === isolatedRaffleId);
      } else if (isolatedCreatorUid) {
        list = list.filter((r) => r.creatorUid === isolatedCreatorUid);
      } else {
        const affiliateCpfs = new Set(affiliates.map(a => a.cpf));
        list = list.filter((r) => !r.creatorUid || !affiliateCpfs.has(r.creatorUid));
      }
    }
    return list;
  }, [raffles, isolatedRaffleId, isolatedCreatorUid, profile, affiliates]);

  const completedRaffles = React.useMemo(() => {
    let list = raffles.filter((r) => r.status === "finished");

    // Filter out paused affiliates
    list = list.filter((r) => {
      if (!r.creatorUid) return true;
      const aff = affiliates.find(a => a.cpf === r.creatorUid || a.id === r.creatorUid);
      if (aff && aff.status === "paused") {
        return false;
      }
      return true;
    });

    if (profile && profile.isCreator && !profile.isAdmin) {
      list = list.filter((r) => r.creatorUid === profile.uid);
    } else if (profile && profile.isAdmin) {
      const affiliateCpfs = new Set(affiliates.map(a => a.cpf));
      list = list.filter((r) => !r.creatorUid || !affiliateCpfs.has(r.creatorUid));
    } else {
      if (isolatedRaffleId) {
        list = list.filter((r) => r.id === isolatedRaffleId);
      } else if (isolatedCreatorUid) {
        list = list.filter((r) => r.creatorUid === isolatedCreatorUid);
      } else {
        const affiliateCpfs = new Set(affiliates.map(a => a.cpf));
        list = list.filter((r) => !r.creatorUid || !affiliateCpfs.has(r.creatorUid));
      }
    }
    return list;
  }, [raffles, isolatedRaffleId, isolatedCreatorUid, profile, affiliates]);

  const filteredWinners = React.useMemo(() => {
    let list = winners;

    if (profile && profile.isCreator && !profile.isAdmin) {
      list = list.filter((win) => {
        const matchedRaffle = raffles.find(r => r.id === win.raffleId);
        return matchedRaffle?.creatorUid === profile.uid;
      });
    } else if (profile && profile.isAdmin) {
      const affiliateCpfs = new Set(affiliates.map(a => a.cpf));
      list = list.filter((win) => {
        const matchedRaffle = raffles.find(r => r.id === win.raffleId);
        return matchedRaffle && (!matchedRaffle.creatorUid || !affiliateCpfs.has(matchedRaffle.creatorUid));
      });
    } else {
      if (isolatedRaffleId) {
        list = list.filter((win) => win.raffleId === isolatedRaffleId);
      } else if (isolatedCreatorUid) {
        list = list.filter((win) => {
          const matchedRaffle = raffles.find(r => r.id === win.raffleId);
          return matchedRaffle?.creatorUid === isolatedCreatorUid;
        });
      } else {
        const affiliateCpfs = new Set(affiliates.map(a => a.cpf));
        list = list.filter((win) => {
          const matchedRaffle = raffles.find(r => r.id === win.raffleId);
          return matchedRaffle && (!matchedRaffle.creatorUid || !affiliateCpfs.has(matchedRaffle.creatorUid));
        });
      }
    }

    // Hide winners for paused affiliates' campaigns
    list = list.filter((win) => {
      const matchedRaffle = raffles.find(r => r.id === win.raffleId);
      if (matchedRaffle?.creatorUid) {
        const aff = affiliates.find(a => a.cpf === matchedRaffle.creatorUid || a.id === matchedRaffle.creatorUid);
        if (aff && aff.status === "paused") {
          return false;
        }
      }
      return true;
    });

    return list;
  }, [winners, raffles, isolatedRaffleId, isolatedCreatorUid, profile, affiliates]);

  const isolatedCreatorName = React.useMemo(() => {
    const found = raffles.find(r => r.id === isolatedRaffleId || r.creatorUid === isolatedCreatorUid);
    return found?.creatorName || "Locador Oficial";
  }, [raffles, isolatedRaffleId, isolatedCreatorUid]);

  const handleLoginPromptWithWarning = () => {
    setShowAuthModal(true);
  };

  // Image Upload Form Handler
  const handleRafflePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 10 * 1024 * 1024) {
      setCreateError("A imagem excede o tamanho limite de 10MB.");
      return;
    }

    setCreatingLoading(true);
    setCreateError("");
    try {
      const compressed = await compressImage(file, 600, 0.4);
      setNewImageBase64(compressed);
    } catch (err: any) {
      setCreateError(err.message || "Erro ao compactar imagem.");
    } finally {
      setCreatingLoading(false);
    }
  };

  const handleCreateRaffleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreateError("");

    if (!profile) {
      setCreateError("Você deve se registrar para alugar e criar rifas.");
      return;
    }

    if (!newTitle.trim() || !newAward.trim() || !newImageBase64) {
      setCreateError("Por favor preencha todos os campos obrigatórios e envie uma foto de apresentação.");
      return;
    }

    setCreatingLoading(true);
    const id = "raffle_" + Math.random().toString(36).substring(2, 11);
    
    const newRaffle: Raffle = {
      id,
      title: newTitle.trim(),
      description: newDescription.trim(),
      image: newImageBase64,
      pricePerTicket: Number(newPrice),
      totalNumbers: Number(newNumbersAmount),
      status: "active",
      award: newAward.trim(),
      createdAt: new Date().toISOString(),
      creatorUid: profile.uid,
      creatorName: profile.name,
      pixKey: newPixKey.trim() || undefined,
      pixReceiver: newPixName.trim() || undefined
    };

    try {
      await setDoc(doc(db, "raffles", id), newRaffle);
      
      // Clear forms
      setNewTitle("");
      setNewAward("");
      setNewDescription("");
      setNewPrice("10.00");
      setNewNumbersAmount(100);
      setNewDrawDate("");
      setNewPixKey("");
      setNewPixName("");
      setNewImageBase64("");
      
      // Auto switch tabs to Manage to show links immediately
      setSelectedRaffleToManage(newRaffle);
      setCurrentTab("manage");
      alert("Seu sorteio foi criado e está ativo! Você foi redirecionado para a página de gerenciamento para copiar os links de divulgação.");
    } catch (error: any) {
      setCreateError("Falha ao salvar seu sorteio: " + error.message);
    } finally {
      setCreatingLoading(false);
    }
  };

  // Live Management Quota Workspace calculations
  const filteredManagedRaffles = React.useMemo(() => {
    if (!profile) return [];
    if (profile.isAdmin) {
      const affiliateCpfs = new Set(affiliates.map(a => a.cpf));
      return raffles.filter(r => !r.creatorUid || !affiliateCpfs.has(r.creatorUid));
    }
    return raffles.filter(r => r.creatorUid === profile.uid);
  }, [raffles, profile, affiliates]);

  const selectedRaffleTickets = React.useMemo(() => {
    if (!selectedRaffleToManage) return [];
    return allTickets.filter(t => t.raffleId === selectedRaffleToManage.id);
  }, [selectedRaffleToManage, allTickets]);

  const managedTicketsStatistics = React.useMemo(() => {
    if (!selectedRaffleToManage) return { free: 0, pending: 0, confirmed: 0, totalRevenue: 0 };
    
    let pending = 0;
    let confirmed = 0;
    selectedRaffleTickets.forEach(t => {
      if (t.status === "pending") pending++;
      if (t.status === "confirmed") confirmed++;
    });

    const free = Math.max(0, selectedRaffleToManage.totalNumbers - (pending + confirmed));
    const totalRevenue = confirmed * selectedRaffleToManage.pricePerTicket;

    return {
      free,
      pending,
      confirmed,
      totalRevenue
    };
  }, [selectedRaffleToManage, selectedRaffleTickets]);

  const computedGridNumbers = React.useMemo(() => {
    if (!selectedRaffleToManage) return [];

    const map: { [num: number]: Ticket } = {};
    selectedRaffleTickets.forEach(t => {
      map[t.ticketNumber] = t;
    });

    const list = [];
    for (let i = 0; i < selectedRaffleToManage.totalNumbers; i++) {
      const ticket = map[i];
      let match = true;

      // search filter
      if (quotaGridSearch.trim()) {
        const queryClean = quotaGridSearch.toLowerCase().trim();
        const numMatch = i.toString().includes(queryClean);
        const nameMatch = ticket && ticket.userName.toLowerCase().includes(queryClean);
        const phoneMatch = ticket && ticket.userPhone.includes(queryClean);
        match = numMatch || !!nameMatch || !!phoneMatch;
      }

      // tab filter
      if (match) {
        if (quotaFilter === "free" && ticket) match = false;
        if (quotaFilter === "pending" && (!ticket || ticket.status !== "pending")) match = false;
        if (quotaFilter === "confirmed" && (!ticket || ticket.status !== "confirmed")) match = false;
      }

      if (match) {
        list.push({
          number: i,
          ticket
        });
      }
    }

    return list;
  }, [selectedRaffleToManage, selectedRaffleTickets, quotaGridSearch, quotaFilter]);

  // Handle setting pagination range for manage grids
  useEffect(() => {
    if (!selectedRaffleToManage) return;
    if (selectedRaffleToManage.totalNumbers <= 200) {
      setGridPaginationRange({ start: 0, end: selectedRaffleToManage.totalNumbers - 1 });
    } else {
      setGridPaginationRange({ start: 0, end: 199 });
    }
    // Clean states
    setSelectedQuotasForBatch([]);
    setMultiSelectEnabled(false);
  }, [selectedRaffleToManage]);

  const handleQuotaClickOnManage = (num: number, hasTicket: boolean, ticket: Ticket | undefined) => {
    if (!multiSelectEnabled) {
      // Toggle a neat custom modal or panel info showing buyer details immediately
      if (ticket) {
        alert(`Bilhete #${num.toString().padStart(3, "0")} vendido para:\nNome: ${ticket.userName}\nTelefone: ${ticket.userPhone}\nCPF: ${ticket.userCpf}\nStatus: ${ticket.status.toUpperCase()}`);
      } else {
        alert(`O número #${num.toString().padStart(3, "0")} está livre e disponível.`);
      }
      return;
    }

    // Multi-Select Toggle
    setSelectedQuotasForBatch(prev => 
      prev.includes(num) ? prev.filter(n => n !== num) : [...prev, num]
    );
  };

  const handleBatchAlterSubmit = async () => {
    if (!selectedRaffleToManage || selectedQuotasForBatch.length === 0) return;
    
    setBatchSubmitLoading(true);
    try {
      for (const num of selectedQuotasForBatch) {
        const ticketId = `${selectedRaffleToManage.id}_${num}`;
        
        if (batchActionType === "free") {
          // Delete ticket from Firestore completely to release number
          await deleteDoc(doc(db, "tickets", ticketId));
        } else {
          // Write/update ticket
          const ticketPayload: Ticket = {
            id: ticketId,
            raffleId: selectedRaffleToManage.id,
            ticketNumber: num,
            userCpf: batchBuyerName.trim() ? "MANUAL_" + num : profile?.cpf || "00000000000",
            userName: batchBuyerName.trim() || profile?.name || "Locador da Plataforma",
            userPhone: batchBuyerPhone.trim() || profile?.phone || "(00) 00000-0000",
            status: batchActionType,
            reservedAt: new Date().toISOString()
          };
          if (batchActionType === "confirmed") {
            ticketPayload.confirmedAt = new Date().toISOString();
          }
          await setDoc(doc(db, "tickets", ticketId), ticketPayload);
        }
      }

      alert("Lote de bilhetes atualizado com sucesso!");
      setSelectedQuotasForBatch([]);
      setBatchBuyerName("");
      setBatchBuyerPhone("");
    } catch (err: any) {
      alert("Erro ao aplicar em lote: " + err.message);
    } finally {
      setBatchSubmitLoading(false);
    }
  };

  const handleApproveSingleTicket = async (ticket: Ticket) => {
    try {
      await updateDoc(doc(db, "tickets", ticket.id), {
        status: "confirmed",
        confirmedAt: new Date().toISOString()
      });
      alert(`O bilhete #${ticket.ticketNumber.toString().padStart(3, "0")} de ${ticket.userName} foi aprovado com sucesso!`);
    } catch (err: any) {
      alert("Erro ao aprovar bilhete: " + err.message);
    }
  };

  const handleDeclineSingleTicket = async (ticket: Ticket) => {
    if (window.confirm(`Deseja realmente recusar e liberar a cota #${ticket.ticketNumber.toString().padStart(3, "0")} de ${ticket.userName}? Isso devolverá o número ao sorteio.`)) {
      try {
        await deleteDoc(doc(db, "tickets", ticket.id));
        alert(`O bilhete #${ticket.ticketNumber.toString().padStart(3, "0")} foi cancelado e está livre.`);
      } catch (err: any) {
        alert("Erro ao liberar bilhete: " + err.message);
      }
    }
  };

  const handleDeleteRaffle = (raffleId: string) => {
    setConfirmDialog({
      title: "Excluir Sorteio",
      description: "Atenção! Deseja realmente excluir permanentemente este sorteio? Todas as reservas e bilhetes vinculados a ele também serão deletados de forma irreversível.",
      onConfirm: async () => {
        try {
          setCreatingLoading(true);
          
          // 1. Delete associated tickets from Firestore
          const relatedTickets = allTickets.filter(t => t.raffleId === raffleId);
          for (const ticket of relatedTickets) {
            await deleteDoc(doc(db, "tickets", ticket.id)).catch(err => {
              console.warn(`Failed to delete ticket ${ticket.id}:`, err);
            });
          }

          // 2. Delete the raffle document
          await deleteDoc(doc(db, "raffles", raffleId));
          
          alert("Sorteio e bilhetes associados excluídos com sucesso!");
          setSelectedRaffleToManage(null);
        } catch (err: any) {
          alert("Erro ao excluir sorteio: " + err.message);
        } finally {
          setCreatingLoading(false);
        }
      }
    });
  };

  // Perform Winner Draw
  const handleWinnerDrawPhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const compressedStr = await compressImage(file, 500, 0.45);
      setDrawnWinnerPhoto(compressedStr);
    } catch {
      alert("Falha ao compactar foto.");
    }
  };

  const handleInitialDrawExecute = () => {
    if (!selectedRaffleToManage) return;
    setDrawError("");
    setDrawSuccess("");
    setDrawnWinnerTicket(null);

    const confirmeds = selectedRaffleTickets.filter(t => t.status === "confirmed");
    if (confirmeds.length === 0) {
      setDrawError("Nenhuma cota foi marcada como 'Paga e Confirmada' neste sorteio ainda! Não é possível sortear.");
      return;
    }

    if (drawMethod === "system") {
      setIsSpinning(true);
      let ticks = 0;
      const interval = setInterval(() => {
        const rand = Math.floor(Math.random() * selectedRaffleToManage.totalNumbers);
        setSpinNum(rand);
        ticks++;
        if (ticks >= 25) {
          clearInterval(interval);
          const idx = Math.floor(Math.random() * confirmeds.length);
          const winT = confirmeds[idx];
          setDrawnWinnerTicket(winT);
          setSpinNum(winT.ticketNumber);
          setIsSpinning(false);
          setDrawSuccess(`🏆 Número #${winT.ticketNumber.toString().padStart(3, "0")} foi sorteado com base nos registros pagos!`);
        }
      }, 80);
    } else {
      // Manual Search
      const manualNum = Number(manualWinningNum);
      if (isNaN(manualNum) || manualNum < 0 || manualNum >= selectedRaffleToManage.totalNumbers) {
        setDrawError(`Digite uma cota válida de 00 a ${selectedRaffleToManage.totalNumbers - 1}.`);
        return;
      }
      const foundConfirmed = confirmeds.find(c => c.ticketNumber === manualNum);
      if (foundConfirmed) {
        setDrawnWinnerTicket(foundConfirmed);
        setDrawSuccess(`Cota #${manualNum.toString().padStart(3, "0")} confirmada e vinculada ao comprador ${foundConfirmed.userName}!`);
      } else {
        setDrawError(`Atenção: A cota #${manualNum} não possui confirmação paga e certificada no banco de dados.`);
      }
    }
  };

  const handleSaveAndPublishDraw = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRaffleToManage || !drawnWinnerTicket) return;

    setSavingDrawLoading(true);
    const winId = "winner_" + Math.random().toString(36).substring(2, 11);

    const finalWinnerPayload: Winner = {
      id: winId,
      raffleId: selectedRaffleToManage.id,
      raffleTitle: selectedRaffleToManage.title,
      userName: drawnWinnerTicket.userName,
      userCpf: drawnWinnerTicket.userCpf,
      winningNumber: drawnWinnerTicket.ticketNumber,
      award: selectedRaffleToManage.award || selectedRaffleToManage.title,
      prizePhoto: drawnWinnerPhoto || selectedRaffleToManage.image,
      announcedAt: new Date().toISOString()
    };

    try {
      // 1. Mark Raffle as finished
      await updateDoc(doc(db, "raffles", selectedRaffleToManage.id), {
        status: "finished"
      });

      // 2. Insert winner Wall record
      await setDoc(doc(db, "winners", winId), finalWinnerPayload);

      alert(`Sorteio ${selectedRaffleToManage.title} finalizado com sucesso!`);
      setShowDrawModal(false);
      setSelectedRaffleToManage(null);
      setDrawnWinnerTicket(null);
      setDrawnWinnerPhoto("");
      setManualWinningNum("");
      setCurrentTab("home");
    } catch (err: any) {
      alert("Erro ao salvar resultado: " + err.message);
    } finally {
      setSavingDrawLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans antialiased text-slate-800 flex flex-col justify-between selection:bg-blue-600 selection:text-white relative">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,rgba(59,130,246,0.05),transparent_50%)] pointer-events-none" />
      
      {/* 1. HEADER BRAND BAR */}
      <div>
        <nav className="border-b border-zinc-200 bg-white/90 backdrop-blur-md sticky top-0 z-30 px-4 select-none shadow-xs">
          <div className="max-w-7xl mx-auto flex h-16 items-center justify-between">
            {/* Minimal Brand Title */}
            <div className="flex items-center space-x-2.5 cursor-pointer group" onClick={() => setCurrentTab("home")}>
              <div className="p-2 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white shadow-[0_4px_12px_rgba(37,99,235,0.25)]">
                <Clover className="animate-spin text-white hover:rotate-45 transition-transform" size={20} />
              </div>
              <span className="font-extrabold text-base uppercase tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-500">
                LuckyNeon
              </span>
            </div>

            {/* Middle Nav Option Labels for Tablet & Desktops */}
            <div className="hidden md:flex items-center space-x-6 text-[11px] font-black uppercase tracking-wider text-zinc-500">
              <button 
                onClick={() => { setCurrentTab("home"); setListFilter("ativos"); }}
                className={`hover:text-blue-600 transition cursor-pointer flex items-center space-x-1.5 ${currentTab === "home" ? "text-blue-600 font-extrabold" : ""}`}
              >
                <Clover size={14} />
                <span>Sorteios Ativos</span>
              </button>
              
              <button 
                onClick={() => setCurrentTab("ranking")}
                className={`hover:text-blue-600 transition cursor-pointer flex items-center space-x-1.5 ${currentTab === "ranking" ? "text-blue-600 font-extrabold" : ""}`}
              >
                <Award size={14} />
                <span>Ranking</span>
              </button>

              {profile && !profile.isAdmin && !profile.isCreator && (
                <button 
                  onClick={() => setCurrentTab("tickets")}
                  className={`hover:text-blue-600 transition cursor-pointer flex items-center space-x-1.5 ${currentTab === "tickets" ? "text-blue-600 font-extrabold" : ""}`}
                >
                  <TicketIcon size={14} />
                  <span>Meus Bilhetes</span>
                </button>
              )}

              {profile && profile.isAdmin && (
                <button 
                  onClick={() => {
                    setAdminPanelDefaultTab("afiliados");
                    setShowAdminPanel(true);
                  }}
                  className="hover:text-blue-600 transition cursor-pointer flex items-center space-x-1.5"
                >
                  <Users size={14} />
                  <span>Afiliados</span>
                </button>
              )}

              {profile && profile.isCreator && (
                <button 
                  onClick={() => setShowCreatorPanel(true)}
                  className="hover:text-blue-600 transition cursor-pointer bg-blue-50 hover:bg-blue-100 px-3 py-1.5 rounded-lg border border-blue-200/60 text-blue-600 flex items-center space-x-1.5"
                >
                  <Sparkles size={14} />
                  <span>Painel Afiliado</span>
                </button>
              )}
            </div>

            {/* Profile Avatar custom photo/name dropdown */}
            <div className="flex items-center space-x-2">
              <button 
                onClick={() => setShowTermsModal(true)}
                className="hidden sm:inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-xl border border-zinc-200 bg-white text-[10px] text-zinc-500 font-extrabold uppercase hover:text-zinc-800 hover:bg-zinc-50 transition-colors cursor-pointer mr-2 shadow-xs"
              >
                <FileText size={12} />
                <span>Regulamento</span>
              </button>

              {isAdmin && (
                <button 
                  onClick={() => setShowAdminPanel(true)}
                  className="bg-blue-600 text-white hover:bg-blue-700 shadow-[0_2px_8px_rgba(37,99,235,0.25)] px-3 py-1.5 rounded-xl text-[10px] tracking-wider uppercase font-black cursor-pointer transition active:scale-95 mr-2"
                >
                  Painel Adm
                </button>
              )}

              {profile ? (
                <div className="relative">
                  <button 
                    onClick={() => setShowProfileDropdown(!showProfileDropdown)}
                    className="flex items-center space-x-2 bg-white hover:bg-slate-50 border border-zinc-200 p-1.5 pr-4 rounded-full select-none shadow-xs cursor-pointer transition active:scale-95"
                  >
                    {profile.photo ? (
                      <img 
                        src={profile.photo} 
                        alt={profile.name} 
                        className="h-7 w-7 rounded-full object-cover border border-zinc-200 shadow-sm"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="h-7 w-7 bg-blue-600 rounded-full flex items-center justify-center text-white text-[11px] font-black uppercase">
                        {profile.name.charAt(0)}
                      </div>
                    )}
                    <span className="font-extrabold text-zinc-800 text-xs truncate max-w-[80px] sm:max-w-[120px] leading-none">
                      {profile.name.split(" ")[0]}
                    </span>
                    <ChevronDown size={14} className="text-zinc-500" />
                  </button>

                  <AnimatePresence>
                    {showProfileDropdown && (
                      <>
                        <div 
                          className="fixed inset-0 z-40 bg-transparent" 
                          onClick={() => setShowProfileDropdown(false)}
                        />
                        <motion.div 
                          initial={{ opacity: 0, scale: 0.95, y: 10 }}
                          animate={{ opacity: 1, scale: 1, y: 0 }}
                          exit={{ opacity: 0, scale: 0.95, y: 10 }}
                          className="absolute right-0 mt-2 w-72 bg-white border border-zinc-200 rounded-2xl p-5 shadow-2xl z-50 text-left"
                        >
                          <div className="flex flex-col items-center border-b border-zinc-100 pb-4 text-center">
                            {profile.photo ? (
                              <img 
                                src={profile.photo} 
                                alt={profile.name} 
                                className="h-16 w-16 rounded-full object-cover border-2 border-blue-600 shadow-md mb-2.5"
                                referrerPolicy="no-referrer"
                              />
                            ) : (
                              <div className="h-16 w-16 bg-blue-600 rounded-full flex items-center justify-center text-white text-2xl font-black uppercase mb-2.5">
                                {profile.name.charAt(0)}
                              </div>
                            )}
                            <h3 className="font-extrabold text-sm text-zinc-800 leading-tight">{profile.name}</h3>
                            <p className="text-[10px] uppercase tracking-widest text-blue-600 font-black mt-1">
                              {profile.isAdmin ? "Administrador Geral" : "Participante"}
                            </p>
                          </div>

                          <div className="space-y-3 py-4 text-xs font-medium text-zinc-650">
                            <div>
                              <span className="text-[9px] uppercase font-black text-zinc-400 block mb-0.5">CPF / Identificador</span>
                              <p className="font-bold text-zinc-850 font-mono tracking-wide">{profile.cpf}</p>
                            </div>
                            <div>
                              <span className="text-[9px] uppercase font-black text-zinc-400 block mb-0.5">Telefone</span>
                              <p className="font-bold text-zinc-850">{profile.phone}</p>
                            </div>
                          </div>

                          <div className="border-t border-zinc-150 pt-3 flex justify-between items-center bg-slate-50/50 -mx-5 -mb-5 p-4 rounded-b-2xl">
                            <button
                              onClick={() => {
                                localStorage.removeItem("lucky_user_cpf");
                                setProfile(null);
                                setIsAdmin(false);
                                setUser(null);
                                setShowProfileDropdown(false);
                                setCurrentTab("home");
                              }}
                              className="w-full flex items-center justify-center space-x-1.5 bg-red-50 hover:bg-red-100 text-red-650 text-xs font-extrabold tracking-wider uppercase px-4 py-2.5 rounded-xl transition cursor-pointer"
                            >
                              <LogOut size={14} />
                              <span>Sair da Conta</span>
                            </button>
                          </div>
                        </motion.div>
                      </>
                    )}
                  </AnimatePresence>
                </div>
              ) : (
                <button 
                  onClick={() => setShowAuthModal(true)}
                  className="inline-flex items-center space-x-1.5 bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-[11px] uppercase tracking-wider px-4.5 py-2.5 rounded-xl text-center active:scale-95 transition shadow-sm cursor-pointer"
                >
                  <LogIn size={13} className="stroke-[3]" />
                  <span>Entrar</span>
                </button>
              )}
            </div>
          </div>
        </nav>

        {/* Global Loading Bar */}
        {loading && (
          <div className="flex items-center justify-center py-12 text-blue-600 gap-2">
            <Loader2 className="animate-spin text-blue-600" size={20} />
            <span className="text-[10px] uppercase font-black tracking-widest leading-none text-blue-600">Conectando ao cofre central...</span>
          </div>
        )}
      </div>

        {/* 2. DYNAMIC WORKSPACE BODY CONTAINER */}
        <div className="max-w-7xl mx-auto px-4 md:px-6 py-6 md:py-8">
          
          {isQuotaExceeded && (
            <div className="mb-6 p-6 rounded-[24px] bg-red-50 border border-red-200 text-left relative overflow-hidden shadow-xs">
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_left,rgba(239,68,68,0.03),transparent_40%)] pointer-events-none" />
              <div className="flex flex-col lg:flex-row gap-5 items-start lg:items-center justify-between">
                <div className="flex gap-4 items-start">
                  <div className="p-3.5 rounded-2xl bg-red-100 text-red-650 shrink-0 shadow-xs">
                    <AlertTriangle size={24} className="stroke-[2.5]" />
                  </div>
                  <div>
                    <h2 className="text-base font-black tracking-tight text-red-900 uppercase">
                      Aviso Importante: Limite de Acesso Diário Excedido (Firebase Quota)
                    </h2>
                    <p className="text-xs text-red-800 mt-2 leading-relaxed max-w-4xl font-semibold">
                      Seus sorteios, bilhetes e dados do aplicativo <span className="text-red-950 font-black underline">estão 100% seguros e NENHUM dado foi excluído</span>. O banco de dados está intacto! O que ocorreu é que o limite gratuito diário de leitura (50.000 leituras no plano Spark do Google Firebase) foi temporariamente superado.
                    </p>
                    <p className="text-xs text-red-750 mt-1.5 leading-relaxed max-w-4xl">
                      Para evitar cobranças, o Google bloqueia novas consultas gratuitas até o reset da quota diária (geralmente à meia-noite do fuso horário da conta). Você pode aguardar até o próximo ciclo ou, caso deseje reativar seu aplicativo imediatamente, acesse seu console do Firebase abaixo para ativar a cobrança (Plano Blaze/Pay-As-You-Go) e estender as quotas.
                    </p>
                  </div>
                </div>
                <div className="shrink-0 w-full lg:w-auto flex flex-col sm:flex-row lg:flex-col gap-2 pt-2 lg:pt-0">
                  <a
                    href="https://console.firebase.google.com/project/grafica-pvd/firestore/databases/ai-studio-002849e7-bfd5-4647-b27c-1b4f9ae1592c/data?openUpgradeDialog=true"
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center justify-center gap-2 bg-red-650 hover:bg-red-750 text-white font-extrabold text-[11px] uppercase tracking-wider px-4.5 py-3 rounded-xl text-center active:scale-95 transition shadow-sm cursor-pointer whitespace-nowrap"
                  >
                    <span>Configurar Cobrança no Firebase</span>
                    <ExternalLink size={12} className="stroke-[2.5]" />
                  </a>
                  <a
                    href="https://firebase.google.com/pricing#cloud-firestore"
                    target="_blank"
                    rel="noreferrer"
                    className="text-center text-[10px] text-red-700 hover:underline hover:text-red-900 font-extrabold uppercase tracking-widest pt-1"
                  >
                    Tabela de Preços do Firebase
                  </a>
                </div>
              </div>
            </div>
          )}
          
          {/* TAB 1: DASHBOARD VIEW (HOME) */}
          {currentTab === "home" && (
            <div className="space-y-8">
              
              {/* WELCOME BANNER AND REAL TIME STATISTICS (Renter SaaS Model) */}
              {profile && (
                <div className="p-6 rounded-[22px] bg-white border border-zinc-200 shadow-sm text-left relative overflow-hidden">
                  <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_left,rgba(37,99,235,0.03),transparent_40%)] pointer-events-none" />
                  
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                    <div>
                      <h1 className="text-xl md:text-2xl font-black tracking-tight text-zinc-850 flex items-center gap-2">
                        Olá, {profile.name} <span className="animate-pulse">👋</span>
                      </h1>
                      <p className="text-[11px] text-zinc-550 mt-1">
                        Sua carteira de investimentos e rifas alugadas na LuckyNeon.
                      </p>
                    </div>

                    <p className="text-[9px] bg-slate-50 border border-zinc-200 text-zinc-600 px-3 py-1.5 rounded-xl uppercase tracking-widest font-black leading-none font-mono">
                      Conta Tipo: <span className="text-blue-600 font-extrabold">{profile.isAdmin ? "Administrador Geral" : profile.isCreator ? "Afiliado / Criador" : "Participante"}</span>
                    </p>
                  </div>
                </div>
              )}

              {/* BANDEIRA DE ESPAÇO CONCORRENTE FOCADO / MULTI-TENANT ISOLATION BAR */}
              {(isolatedRaffleId || isolatedCreatorUid) && (
                <div className="p-4 rounded-xl bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200/60 flex items-center justify-between gap-3 text-left">
                  <div className="flex gap-2.5 items-center">
                     <div className="p-1.5 rounded-lg bg-blue-100 text-blue-600">
                       <Sparkles size={14} className="animate-spin text-blue-600" />
                     </div>
                     <div>
                       <p className="text-xs font-black text-blue-900 uppercase tracking-wide">Página do Parceiro Homologado</p>
                       <p className="text-[10px] text-zinc-650 mt-0.5">
                         Você está na vitrine exclusiva e protegida de <span className="text-blue-600 font-black underline">{isolatedCreatorName}</span>.
                       </p>
                     </div>
                  </div>
                </div>
              )}

              {/* LIST HEADER */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-left border-b border-zinc-150 pb-4">
                <div>
                  <h2 className="text-xl font-black text-zinc-805 tracking-tight flex items-center gap-1.5">
                    <Flame size={18} className="text-blue-600 animate-pulse" /> Sorteios Ativos
                  </h2>
                  <p className="text-[11px] text-zinc-550 mt-1">
                    Selecione um sorteio ativo, adquira suas cotas por PIX imediato e concorra!
                  </p>
                </div>
              </div>

              {/* GRID COSTA LIST SPAS */}
              <div className="mt-6">
                {activeRaffles.length === 0 ? (
                  <div className="text-center py-16 rounded-[22px] border border-zinc-200 border-dashed text-zinc-400 font-extrabold uppercase text-[10px] tracking-wider bg-white">
                    Não há nenhuma campanha ativa no momento.
                  </div>
                ) : activeRaffles.length === 1 ? (
                  /* Center-aligned single large card */
                  <div className="flex justify-center py-6">
                    {(() => {
                      const r = activeRaffles[0];
                      const isHot = r.id === hottestRaffleId;
                      const isUserCreator = profile?.isCreator || profile?.isAdmin;
                      return (
                        <div 
                          key={r.id}
                          className={`w-full max-w-md group bg-white border rounded-[22px] overflow-hidden transition-all duration-300 ease-out flex flex-col cursor-pointer text-left shadow-lg hover:border-blue-400 ${
                            isHot 
                              ? "border-blue-400 shadow-[0_8px_32px_rgba(37,99,235,0.12)] bg-white" 
                              : "border-zinc-200"
                          }`}
                        >
                          {/* Rich clickable Cover aspect ratio */}
                          <div 
                            onClick={() => {
                              if (isUserCreator) {
                                setSelectedRaffleToManage(r);
                                setCurrentTab("manage");
                              } else {
                                setSelectedRaffle(r);
                              }
                            }}
                            className="relative bg-slate-50 flex items-center justify-center p-3 border-b border-zinc-100 cursor-pointer overflow-hidden h-56"
                          >
                            <img 
                              src={r.image} 
                              alt={r.title} 
                              className="max-h-full max-w-full object-contain rounded-xl duration-500 group-hover:scale-105"
                              referrerPolicy="no-referrer"
                            />

                            <span className="absolute bottom-4 left-4 px-3.5 py-1.5 rounded-xl bg-white/95 border border-zinc-100 text-xs font-black text-blue-600 shadow-sm">
                              R$ {r.pricePerTicket.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                            </span>

                            {isHot && (
                              <div className="absolute top-4 right-4 bg-gradient-to-r from-amber-500 to-orange-600 text-white font-black text-[9px] uppercase tracking-wider px-3 py-1 rounded shadow-md animate-pulse flex items-center gap-1.5">
                                <Flame size={12} className="fill-white" />
                                <span>Mais Desejado</span>
                              </div>
                            )}
                          </div>

                          {/* Info Body */}
                          <div className="p-6 flex-1 flex flex-col justify-between space-y-5">
                            <div className="space-y-1.5">
                              <h3 
                                className="font-extrabold text-sm sm:text-base text-zinc-800 leading-snug group-hover:text-blue-600 transition-colors" 
                                onClick={() => {
                                  if (isUserCreator) {
                                    setSelectedRaffleToManage(r);
                                    setCurrentTab("manage");
                                  } else {
                                    setSelectedRaffle(r);
                                  }
                                }}
                              >
                                {r.title}
                              </h3>
                              <p className="text-[10px] text-zinc-400 uppercase tracking-wider font-bold">
                                Locador: {r.creatorName || "Indefinido"}
                              </p>
                              {r.description && (
                                <p className="text-zinc-500 text-xs leading-relaxed line-clamp-3 mt-2 pr-2">
                                  {r.description}
                                </p>
                              )}
                            </div>

                            <div className="pt-2">
                              <RaffleProgress 
                                raffleId={r.id} 
                                totalNumbers={r.totalNumbers} 
                                allTicketsList={allTickets}
                                isQuotaExceeded={isQuotaExceeded}
                              />
                            </div>

                            <div className="flex gap-2.5 pt-2" onClick={(e) => e.stopPropagation()}>
                              {isUserCreator ? (
                                <button 
                                  onClick={() => {
                                    const shareLink = `${window.location.origin}/?r=${r.id}`;
                                    navigator.clipboard.writeText(shareLink);
                                    alert("Link do sorteio copiado com sucesso para divulgação!");
                                  }}
                                  className="flex-1 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-black text-xs uppercase tracking-wider cursor-pointer transition active:scale-95 text-center shadow-md shadow-blue-600/10 flex items-center justify-center gap-1.5"
                                >
                                  <Copy size={13} /> Compartilhar Link
                                </button>
                              ) : (
                                <button 
                                  onClick={() => setSelectedRaffle(r)}
                                  className="flex-1 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-black text-xs uppercase tracking-wider cursor-pointer transition active:scale-95 text-center shadow-md shadow-blue-600/10"
                                >
                                  Adquirir Bilhete e Participar
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })()}
                  </div>
                ) : (
                  /* Standard grid of active campaigns */
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                    {activeRaffles.map((r) => {
                      const isHot = r.id === hottestRaffleId;
                      const isUserCreator = profile?.isCreator || profile?.isAdmin;
                      return (
                        <div 
                          key={r.id}
                          className={`group bg-white border rounded-[22px] overflow-hidden transition-all duration-300 ease-out flex flex-col cursor-pointer text-left hover:-translate-y-1.5 shadow-xs ${
                            isHot 
                              ? "border-blue-400 shadow-[0_4px_20px_rgba(37,99,235,0.08)] bg-white" 
                              : "border-zinc-200 hover:border-blue-400/60"
                          }`}
                          onClick={() => {
                            if (isUserCreator) {
                              setSelectedRaffleToManage(r);
                              setCurrentTab("manage");
                            } else {
                              setSelectedRaffle(r);
                            }
                          }}
                        >
                          {/* Clickable Image Section */}
                          <div className="relative aspect-[4/3] bg-slate-50/50 flex items-center justify-center p-3 border-b border-zinc-100 cursor-pointer overflow-hidden">
                            <img 
                              src={r.image} 
                              alt={r.title} 
                              className="max-w-full max-h-full object-contain rounded-xl duration-500 group-hover:scale-105"
                              referrerPolicy="no-referrer"
                            />

                            <span className="absolute bottom-2 left-2 px-2.5 py-1 rounded-lg bg-white/95 border border-zinc-100 text-[10px] font-black text-blue-600 shadow-xs">
                              R$ {r.pricePerTicket.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                            </span>

                            {isHot && (
                              <div className="absolute top-2 right-2 bg-gradient-to-r from-amber-500 to-orange-600 text-white font-black text-[8px] uppercase tracking-wider px-2 py-0.5 rounded shadow-xs animate-pulse flex items-center gap-1">
                                <Flame size={10} className="fill-white" />
                                <span>Popular</span>
                              </div>
                            )}
                          </div>

                          {/* Info Body */}
                          <div className="p-4 flex-1 flex flex-col justify-between space-y-4">
                            <div className="space-y-1">
                              <h4 className="font-extrabold text-xs text-zinc-800 line-clamp-1 leading-tight group-hover:text-blue-600 transition-colors">
                                {r.title}
                              </h4>
                              <p className="text-[9px] text-zinc-400 line-clamp-1 uppercase tracking-wider font-bold">
                                Locador: {r.creatorName || "Indefinido"}
                              </p>
                            </div>

                            <RaffleProgress 
                              raffleId={r.id} 
                              totalNumbers={r.totalNumbers} 
                              allTicketsList={allTickets}
                              isQuotaExceeded={isQuotaExceeded}
                            />

                            <div className="flex gap-2.5 pt-1.5" onClick={(e) => e.stopPropagation()}>
                              {isUserCreator ? (
                                <button 
                                  onClick={() => {
                                    const shareLink = `${window.location.origin}/?r=${r.id}`;
                                    navigator.clipboard.writeText(shareLink);
                                    alert("Link do sorteio copiado com sucesso para divulgação!");
                                  }}
                                  className="flex-1 py-1.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-black text-[9px] uppercase tracking-wider cursor-pointer transition active:scale-95 text-center shadow-xs flex items-center justify-center gap-1"
                                >
                                  <Copy size={10} /> Compartilhar Link
                                </button>
                              ) : (
                                <button 
                                  onClick={() => setSelectedRaffle(r)}
                                  className="flex-1 py-1.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-black text-[9px] uppercase tracking-wider cursor-pointer transition active:scale-95 text-center shadow-xs"
                                >
                                  Adquirir Bilhete
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* MURAL DE GANHADORES */}
              {filteredWinners.length > 0 && (
                <div className="mt-12 bg-white p-6 rounded-[22px] border border-zinc-200 text-left shadow-sm">
                  <div className="flex items-center space-x-2 border-b border-zinc-100 pb-3.5 mb-4">
                    <Award className="text-blue-600 animate-pulse" size={18} />
                    <h3 className="text-xs uppercase font-black tracking-widest text-zinc-800">Mural de Ganhadores Recentes</h3>
                  </div>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                    {filteredWinners.map((win) => (
                      <div key={win.id} className="bg-slate-50/50 p-3.5 rounded-xl border border-zinc-200 flex space-x-3 items-center hover:border-blue-200 hover:bg-slate-100 transition-all duration-300">
                        <img 
                          src={win.prizePhoto} 
                          className="h-12 w-16 object-cover rounded shadow border border-zinc-100 flex-shrink-0" 
                          alt="Prêmio entregue" 
                        />
                        <div className="overflow-hidden space-y-0.5 leading-tight">
                          <p className="font-extrabold text-xs text-zinc-850 truncate">{win.userName}</p>
                          <p className="text-[10px] text-blue-600 font-extrabold">Cota Sorteada: #{win.winningNumber.toString().padStart(3, "0")}</p>
                          <p className="text-[10px] text-zinc-450 truncate uppercase font-mono max-w-[150px]">{win.raffleTitle}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {currentTab === "historico" && (
            <div className="max-w-4xl mx-auto space-y-6 text-left">
              <div className="bg-white rounded-[26px] border border-zinc-200 p-6 sm:p-8 shadow-sm relative overflow-hidden">
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(147,51,234,0.02),transparent_40%)] pointer-events-none" />
                
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-zinc-100 pb-4 mb-6">
                  <div>
                    <h2 className="text-lg font-black uppercase tracking-widest text-zinc-800 flex items-center gap-2">
                      <Clock className="text-purple-600" size={18} /> Histórico de Vendas & Clientes
                    </h2>
                    <p className="text-[11px] text-zinc-500 mt-1 leading-relaxed">
                      Visualize a lista de todos os compradores das suas rifas e os respectivos números adquiridos.
                    </p>
                  </div>
                  
                  {/* Search Bar */}
                  <div className="relative w-full sm:w-64">
                    <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-zinc-400">
                      <Search size={14} />
                    </span>
                    <input 
                      type="text" 
                      placeholder="Buscar por nome ou CPF..."
                      value={clientSearch}
                      onChange={(e) => setClientSearch(e.target.value)}
                      className="w-full bg-slate-50 border border-zinc-200 rounded-xl py-2 pl-9 pr-4 text-xs focus:outline-none focus:border-purple-500 text-zinc-805 placeholder-zinc-400 hover:bg-slate-50/50 transition-colors"
                    />
                  </div>
                </div>

                {(() => {
                  const affiliateRaffleIds = new Set(raffles.filter(r => r.creatorUid === profile?.uid).map(r => r.id));
                  const affiliateTickets = allTickets.filter(t => affiliateRaffleIds.has(t.raffleId));
                  
                  const customerMap: {[cpf: string]: {
                    name: string;
                    cpf: string;
                    phone: string;
                    tickets: Ticket[];
                  }} = {};

                  affiliateTickets.forEach(t => {
                    const cleanCpf = t.userCpf.replace(/\D/g, "");
                    if (!customerMap[cleanCpf]) {
                      customerMap[cleanCpf] = {
                        name: t.userName,
                        cpf: t.userCpf,
                        phone: t.userPhone,
                        tickets: []
                      };
                    }
                    customerMap[cleanCpf].tickets.push(t);
                  });

                  const customersList = Object.values(customerMap);
                  const filteredCustomers = customersList.filter(c => 
                    c.name.toLowerCase().includes(clientSearch.toLowerCase()) || 
                    c.cpf.replace(/\D/g, "").includes(clientSearch.replace(/\D/g, ""))
                  );

                  if (filteredCustomers.length === 0) {
                    return (
                      <div className="text-center py-12 text-zinc-450 uppercase font-black tracking-widest text-[10px] bg-slate-50/50 rounded-2xl border border-dashed border-zinc-200">
                        Nenhum comprador ou cota encontrada para as suas campanhas.
                      </div>
                    );
                  }

                  return (
                    <div className="space-y-4">
                      {filteredCustomers.map((c) => {
                        const totalTickets = c.tickets.length;
                        const paidTickets = c.tickets.filter(t => t.status === "confirmed").length;
                        const pendingTickets = c.tickets.filter(t => t.status === "pending").length;
                        const whatsappUrl = `https://wa.me/55${c.phone.replace(/\D/g, "")}`;
                        
                        return (
                          <div 
                            key={c.cpf} 
                            className="bg-slate-50/40 border border-zinc-250/70 p-5 rounded-2xl flex flex-col md:flex-row gap-5 justify-between md:items-start hover:border-purple-200 transition-all duration-250"
                          >
                            <div className="space-y-3 flex-grow">
                              {/* Header Card */}
                              <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                                <span className="font-extrabold text-[13px] text-zinc-800 uppercase tracking-tight">{c.name}</span>
                                <span className="text-zinc-400 text-[10px] font-mono">({formatCPF(c.cpf)})</span>
                                <a 
                                  href={whatsappUrl} 
                                  target="_blank" 
                                  rel="noreferrer" 
                                  className="ml-auto md:ml-2 inline-flex items-center space-x-1 px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-700 text-[9px] uppercase font-black tracking-wide rounded-md transition"
                                >
                                  <span>WhatsApp</span>
                                </a>
                              </div>

                              <div className="flex flex-wrap gap-x-5 gap-y-2 text-xs">
                                <div className="text-zinc-550">
                                  Celular: <strong className="text-zinc-800 font-extrabold">{c.phone}</strong>
                                </div>
                                <div className="text-zinc-550">
                                  Cotas Reservadas: <strong className="text-purple-700 font-extrabold">{totalTickets} {totalTickets === 1 ? 'cota' : 'cotas'}</strong>
                                </div>
                                <div className="text-zinc-550">
                                  Pagos: <strong className="text-emerald-600 font-extrabold">{paidTickets}</strong>
                                </div>
                                {pendingTickets > 0 && (
                                  <div className="text-zinc-550">
                                    Pendentes: <strong className="text-amber-600 font-extrabold animate-pulse">{pendingTickets}</strong>
                                  </div>
                                )}
                              </div>

                              {/* Tickets detail block */}
                              <div className="pt-2 border-t border-zinc-200/50 space-y-1.5">
                                <span className="text-[9px] uppercase font-black tracking-widest text-zinc-400 block mb-1">Cotas Selecionadas</span>
                                <div className="flex flex-wrap gap-2 text-[10px]">
                                  {c.tickets.map((t) => {
                                    const rf = raffles.find(r => r.id === t.raffleId);
                                    return (
                                      <div 
                                        key={t.id} 
                                        className={`px-3 py-1.5 rounded-xl border flex items-center gap-1.5 font-medium ${
                                          t.status === "confirmed" 
                                            ? "bg-emerald-50/60 text-emerald-800 border-emerald-200/60" 
                                            : t.status === "cancelled"
                                              ? "bg-zinc-50 text-zinc-500 border-zinc-200"
                                              : "bg-amber-50/60 text-amber-800 border-amber-200/60 animate-pulse"
                                        }`}
                                      >
                                        <span className="font-mono font-extrabold">
                                          #{t.ticketNumber.toString().padStart(rf?.totalNumbers === 1000 ? 3 : 2, "0")}
                                        </span>
                                        <span className="text-zinc-400">•</span>
                                        <span className="truncate max-w-[120px] uppercase font-bold text-zinc-700 leading-none">{rf?.title || "Campanha deletada"}</span>
                                        <span className="text-zinc-400">•</span>
                                        <span className="uppercase font-extrabold text-[8px] tracking-wider">
                                          {t.status === "confirmed" ? "Pago ✔" : t.status === "cancelled" ? "Cancelado" : "Pendente"}
                                        </span>
                                      </div>
                                    );
                                  })}
                                </div>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  );
                })()}
              </div>
            </div>
          )}
          {currentTab === "create" && (
            <div className="max-w-2xl mx-auto bg-white rounded-[26px] border border-zinc-200 p-6 sm:p-8 text-left shadow-sm relative">
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(37,99,235,0.02),transparent_40%)] pointer-events-none" />
              
              <div className="border-b border-zinc-100 pb-4 mb-6">
                <h2 className="text-lg font-black uppercase tracking-widest text-zinc-800 flex items-center gap-1.5">
                  <Plus size={18} className="text-blue-600" /> Cadastrar Meu Sorteio Rascunhado
                </h2>
                <p className="text-[11px] text-zinc-500 mt-1 leading-relaxed">
                  Realize sua própria rifa cobrando pelas cotas sob um regulamento seguro LuckyNeon. Os pagamentos PIX serão aglutinados em nome da sua chave cadastral direta!
                </p>
              </div>

              {createError && (
                <div className="mb-4 bg-red-50 border border-red-200 rounded-xl p-3.5 text-xs text-red-655 font-bold leading-normal">
                  ⚠️ {createError}
                </div>
              )}

              <form onSubmit={handleCreateRaffleSubmit} className="space-y-4">
                
                {/* Title and Prize */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[9px] uppercase tracking-widest font-black text-blue-600 mb-1.5">Nome do Sorteio (Ex: iPhone 15 Pro)</label>
                    <input 
                      type="text"
                      required
                      placeholder="Ex: Rifle Gol Quadrado Turbo"
                      value={newTitle}
                      onChange={(e) => setNewTitle(e.target.value)}
                      className="w-full rounded-xl bg-slate-50 border border-zinc-200 text-xs px-3.5 py-3 text-zinc-800 placeholder-zinc-400 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 hover:bg-slate-50/50"
                    />
                  </div>
                  <div>
                    <label className="block text-[9px] uppercase tracking-widest font-black text-blue-600 mb-1.5">Prêmio Principal do Ganhador</label>
                    <input 
                      type="text"
                      required
                      placeholder="Ex: Carro Físico + R$ 2.000,00 no PIX"
                      value={newAward}
                      onChange={(e) => setNewAward(e.target.value)}
                      className="w-full rounded-xl bg-slate-50 border border-zinc-200 text-xs px-3.5 py-3 text-zinc-800 placeholder-zinc-400 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 hover:bg-slate-50/50"
                    />
                  </div>
                </div>

                {/* Description */}
                <div>
                  <label className="block text-[9px] uppercase tracking-widest font-black text-blue-600 mb-1.5">Descrição detalhada do Sorteio / Benefício</label>
                  <textarea 
                    placeholder="Especifique os termos de entrega, detalhes de fabricação, etc."
                    value={newDescription}
                    onChange={(e) => setNewDescription(e.target.value)}
                    rows={2.5}
                    className="w-full rounded-xl bg-slate-50 border border-zinc-200 text-xs px-3.5 py-3 text-zinc-800 placeholder-zinc-400 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 hover:bg-slate-50/50"
                  />
                </div>

                {/* Pricing and Quota amounts */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-[9px] uppercase tracking-widest font-black text-blue-600 mb-1.5">Preço por Cota (BRL)</label>
                    <input 
                      type="number"
                      step="0.01"
                      required
                      value={newPrice}
                      onChange={(e) => setNewPrice(e.target.value)}
                      className="w-full rounded-xl bg-slate-50 border border-zinc-200 text-xs px-3.5 py-3 text-zinc-800 placeholder-zinc-400 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 hover:bg-slate-50/50"
                    />
                  </div>
                  <div>
                    <label className="block text-[9px] uppercase tracking-widest font-black text-blue-600 mb-1.5">Quantidade de Números</label>
                    <select 
                      value={newNumbersAmount}
                      onChange={(e) => setNewNumbersAmount(Number(e.target.value) as 100 | 1000)}
                      className="w-full rounded-xl bg-slate-50 border border-zinc-200 text-xs px-3.5 py-3 text-zinc-805 focus:outline-none focus:border-blue-505 focus:ring-1 focus:ring-blue-505"
                    >
                      <option value={100}>100 Números (00 a 99)</option>
                      <option value={1000}>1000 Números (000 a 999)</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-[9px] uppercase tracking-widest font-black text-blue-600 mb-1.5">Data de Encerramento Previsto</label>
                    <input 
                      type="date"
                      value={newDrawDate}
                      onChange={(e) => setNewDrawDate(e.target.value)}
                      className="w-full rounded-xl bg-slate-50 border border-zinc-200 text-xs px-3.5 py-3 text-zinc-805 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                    />
                  </div>
                </div>

                {/* Pix custom routing */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[9px] uppercase tracking-widest font-black text-blue-600 mb-1.5">Sua Chave PIX Recebedor (Chave Celular/CPF/Email)</label>
                    <input 
                      type="text"
                      required
                      placeholder="Para onde compradores farão o Pix"
                      value={newPixKey}
                      onChange={(e) => setNewPixKey(e.target.value)}
                      className="w-full rounded-xl bg-slate-50 border border-zinc-200 text-xs px-3.5 py-3 text-zinc-800 placeholder-zinc-400 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 hover:bg-slate-50/50"
                    />
                  </div>
                  <div>
                    <label className="block text-[9px] uppercase tracking-widest font-black text-blue-600 mb-1.5">Nome Completo do Recebedor PIX (Igual no Banco)</label>
                    <input 
                      type="text"
                      required
                      placeholder="Ex: João da Silva Santos"
                      value={newPixName}
                      onChange={(e) => setNewPixName(e.target.value)}
                      className="w-full rounded-xl bg-slate-50 border border-zinc-200 text-xs px-3.5 py-3 text-zinc-800 placeholder-zinc-400 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 hover:bg-slate-50/50"
                    />
                  </div>
                </div>

                {/* Image Upload cover preview */}
                <div>
                  <label className="block text-[9px] uppercase tracking-widest font-black text-blue-600 mb-2">Foto de Apresentação da Rifa</label>
                  <div 
                    onClick={() => fileInputRef.current?.click()}
                    className="border-2 border-dashed border-zinc-200 hover:border-blue-500 bg-slate-50/50 p-6 rounded-2xl flex flex-col items-center justify-center cursor-pointer text-center group transition-colors"
                  >
                    <input 
                      type="file"
                      ref={fileInputRef}
                      className="hidden"
                      accept="image/*"
                      onChange={handleRafflePhotoUpload}
                    />

                    {newImageBase64 ? (
                      <div className="flex flex-col items-center space-y-3">
                        <img 
                          src={newImageBase64} 
                          className="h-28 max-w-full object-contain rounded-xl border border-zinc-200 shadow-xs" 
                          alt="Cover upload" 
                        />
                        <span className="text-[10px] text-blue-600 font-extrabold uppercase">Trocar imagem cover</span>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        <div className="p-3 bg-slate-100 text-zinc-400 rounded-full inline-block group-hover:text-blue-600 transition-colors">
                          <Upload size={20} />
                        </div>
                        <div>
                          <p className="text-xs text-zinc-750 font-extrabold">Carregar Foto Local do Produto</p>
                          <p className="text-[10px] text-zinc-450 mt-1">Imagens JPEG/PNG compactadas de até 10MB</p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                <div className="pt-6 border-t border-zinc-100 flex justify-end">
                  <button 
                    type="submit"
                    disabled={creatingLoading}
                    className="relative flex items-center justify-center space-x-2 px-8 py-3.5 bg-gradient-to-tr from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 disabled:opacity-45 disabled:cursor-not-allowed text-white text-xs uppercase font-black tracking-widest rounded-xl transition active:scale-95 cursor-pointer shadow-sm shadow-blue-500/10"
                  >
                    {creatingLoading ? (
                      <Loader2 className="animate-spin text-white" size={16} />
                    ) : (
                      <>
                        <Check size={16} className="stroke-[3]" />
                        <span>Publicar Meu Sorteio</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* TAB 3: MANAGE SYSTEM WORKSPACE (COGNITIVE DASHBOARD & BATCH) */}
          {currentTab === "manage" && (
            <div className="space-y-6">
              
              {/* SELECT ACTIVE CAMPAIGN SELECTOR */}
              <div className="p-5 rounded-2xl bg-white border border-zinc-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4 text-left">
                <div>
                  <h3 className="text-sm uppercase font-black tracking-wider text-blue-600">Escolha o Sorteio Locado para Gerenciar</h3>
                  <p className="text-[11px] text-zinc-550 mt-1 font-medium">Monitore bilhetes vendidos, aprovações, alteração em lote ou declare o vencedor.</p>
                </div>

                <div className="flex items-center gap-2 w-full md:w-auto shrink-0 max-w-sm">
                  <select 
                    value={selectedRaffleToManage?.id || ""}
                    onChange={(e) => {
                      const matched = raffles.find(r => r.id === e.target.value);
                      setSelectedRaffleToManage(matched || null);
                    }}
                    className="w-full bg-slate-50 border border-zinc-200 hover:border-zinc-350 text-xs px-4 py-3 rounded-xl focus:outline-none focus:ring-1 focus:ring-blue-500 text-zinc-800 font-extrabold cursor-pointer"
                  >
                    <option value="">-- Selecione uma campanha --</option>
                    {filteredManagedRaffles.map(r => (
                      <option key={r.id} value={r.id}>{r.title} ({r.status === "finished" ? "Concluído" : "Ativo"})</option>
                    ))}
                  </select>

                  {selectedRaffleToManage && (
                    <button
                      type="button"
                      onClick={() => handleDeleteRaffle(selectedRaffleToManage.id)}
                      className="px-4 py-3 bg-red-50 hover:bg-red-500 text-red-600 hover:text-white border border-red-250 cursor-pointer text-xs font-black uppercase rounded-xl transition flex items-center justify-center gap-1.5 shrink-0"
                      title="Excluir Sorteio"
                    >
                      <Trash size={14} />
                      <span className="hidden sm:inline">Excluir</span>
                    </button>
                  )}
                </div>
              </div>

              {selectedRaffleToManage ? (
                <div className="space-y-6 text-left">
                  
                  {/* WORKSPACE DETAILED METRICS GRID */}
                  <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
                    <div className="bg-slate-50/50 p-4 rounded-xl border border-zinc-200 shadow-xs">
                      <p className="text-[9px] text-zinc-400 uppercase font-black">Preço Unitário</p>
                      <p className="font-sans font-black text-blue-600 text-lg mt-1">R$ {selectedRaffleToManage.pricePerTicket.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</p>
                    </div>
                    <div className="bg-slate-50/50 p-4 rounded-xl border border-zinc-200 shadow-xs">
                      <p className="text-[9px] text-zinc-400 uppercase font-black">Faturamento Total</p>
                      <p className="font-sans font-black text-emerald-600 text-lg mt-1">R$ {managedTicketsStatistics.totalRevenue.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</p>
                    </div>
                    <div className="bg-slate-50/50 p-4 rounded-xl border border-zinc-200 shadow-xs">
                      <p className="text-[9px] text-zinc-400 uppercase font-black">Cotas Disponíveis</p>
                      <p className="font-sans font-black text-zinc-800 text-lg mt-1">{managedTicketsStatistics.free} unidades</p>
                    </div>
                    <div className="bg-slate-50/50 p-4 rounded-xl border border-zinc-200 shadow-xs">
                      <p className="text-[9px] text-zinc-400 uppercase font-black">Aprovação Pendente</p>
                      <p className="font-sans font-black text-amber-600 text-lg mt-1 animate-pulse">{managedTicketsStatistics.pending} pendentes</p>
                    </div>
                    <div className="bg-slate-50/50 p-4 rounded-xl border border-zinc-200 shadow-xs col-span-2 lg:col-span-1">
                      <p className="text-[9px] text-zinc-400 uppercase font-black">Declarar Ganhador</p>
                      <button 
                        onClick={() => {
                          setDrawError("");
                          setDrawSuccess("");
                          setDrawnWinnerTicket(null);
                          setShowDrawModal(true);
                        }}
                        disabled={selectedRaffleToManage.status === "finished"}
                        className="w-full mt-1 px-3 py-2 rounded-lg bg-gradient-to-tr from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-black text-[10px] uppercase tracking-wider transition active:scale-95 cursor-pointer flex items-center justify-center space-x-1 disabled:opacity-40 disabled:cursor-not-allowed"
                      >
                        <Play size={10} />
                        <span>Realizar Sorteio</span>
                      </button>
                    </div>
                  </div>

                  {/* EXCLUSIVE SALES SHARE LINKS (MULTI-TENANCY SaaS TOOL) */}
                  <div className="bg-white p-6 rounded-[22px] border border-zinc-200 text-left relative overflow-hidden shadow-sm">
                    <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(37,99,235,0.02),transparent_40%)] pointer-events-none" />
                    <div className="flex items-center space-x-2 border-b border-zinc-100 pb-3 mb-4">
                      <Sparkles className="text-blue-600 animate-pulse" size={16} />
                      <div>
                        <h4 className="text-xs uppercase font-black tracking-widest text-zinc-800">Divulgação de Links Exclusivos</h4>
                        <p className="text-[10px] text-zinc-500 mt-0.5 font-medium">Use estes links para que seus clientes vejam APENAS as suas campanhas de forma isolada.</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {/* CARD 1: SINGLE RAFFLE LINK */}
                      <div className="bg-slate-50/50 p-4 rounded-xl border border-zinc-200 hover:border-blue-400/20 transition-all duration-300">
                        <p className="text-[9px] uppercase font-black text-blue-600">Link Direto Deste Sorteio</p>
                        <p className="text-[10px] text-zinc-500 mt-1">Leva os compradores diretamente para a página focal deste sorteio único.</p>
                        
                        <div className="mt-3.5 flex items-center justify-between gap-2.5 bg-white border border-zinc-200 p-2 rounded-xl">
                          <input 
                            type="text" 
                            readOnly
                            value={`${window.location.origin}/?r=${selectedRaffleToManage.id}`}
                            className="bg-transparent border-none text-[10px] text-zinc-650 select-all font-mono focus:outline-none w-full truncate"
                          />
                          <button 
                            type="button"
                            onClick={() => {
                              const text = `${window.location.origin}/?r=${selectedRaffleToManage.id}`;
                              navigator.clipboard.writeText(text);
                              setCopiedType("single");
                              setTimeout(() => setCopiedType(null), 2000);
                            }}
                            className={`px-3 py-1.5 rounded-lg text-[9px] font-black uppercase flex items-center gap-1.5 transition whitespace-nowrap cursor-pointer ${copiedType === "single" ? "bg-emerald-600 text-white" : "bg-slate-100 hover:bg-slate-200 text-zinc-650 hover:text-zinc-800 border border-zinc-200"}`}
                          >
                            <Copy size={11} />
                            <span>{copiedType === "single" ? "Copiado!" : "Copiar"}</span>
                          </button>
                        </div>
                      </div>

                      {/* CARD 2: CREATOR STOREFRONT LINK */}
                      <div className="bg-slate-50/50 p-4 rounded-xl border border-zinc-200 hover:border-blue-400/20 transition-all duration-300">
                        <p className="text-[9px] uppercase font-black text-indigo-600">Sua Vitrine Completa</p>
                        <p className="text-[10px] text-zinc-500 mt-1">Leva os compradores para a sua vitrine personalizada mostrando todos os seus sorteios ativos.</p>
                        
                        <div className="mt-3.5 flex items-center justify-between gap-2.5 bg-white border border-zinc-200 p-2 rounded-xl">
                          <input 
                            type="text" 
                            readOnly
                            value={`${window.location.origin}/?c=${profile?.uid}`}
                            className="bg-transparent border-none text-[10px] text-zinc-650 select-all font-mono focus:outline-none w-full truncate"
                          />
                          <button 
                            type="button"
                            onClick={() => {
                              const text = `${window.location.origin}/?c=${profile?.uid}`;
                              navigator.clipboard.writeText(text);
                              setCopiedType("vitrine");
                              setTimeout(() => setCopiedType(null), 2000);
                            }}
                            className={`px-3 py-1.5 rounded-lg text-[9px] font-black uppercase flex items-center gap-1.5 transition whitespace-nowrap cursor-pointer ${copiedType === "vitrine" ? "bg-emerald-600 text-white" : "bg-slate-100 hover:bg-slate-200 text-zinc-650 hover:text-zinc-805 border border-zinc-200"}`}
                          >
                            <Copy size={11} />
                            <span>{copiedType === "vitrine" ? "Copiado!" : "Copiar"}</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* PENDING APPROVAL RESCUE LIST (Direct response to user requirement) */}
                  <div className="bg-white p-6 rounded-[22px] border border-zinc-200 text-left relative overflow-hidden shadow-sm">
                    <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(245,158,11,0.02),transparent_40%)] pointer-events-none" />
                    <div className="flex items-center space-x-2 border-b border-zinc-100 pb-3 mb-4">
                      <Clock className="text-amber-500 animate-pulse" size={16} />
                      <div>
                        <h4 className="text-xs uppercase font-black tracking-widest text-zinc-800">Aprovar Bilhetes Pendentes</h4>
                        <p className="text-[10px] text-zinc-500 mt-0.5 font-medium">Aceite ou cancele as solicitações de reserva pendentes de pagamento PIX para este sorteio.</p>
                      </div>
                    </div>

                    {selectedRaffleTickets.filter(t => t.status === "pending").length === 0 ? (
                      <div className="text-center py-6 text-zinc-400 font-extrabold uppercase text-[10px] tracking-wider bg-slate-50/50 rounded-xl border border-dashed border-zinc-200">
                        Nenhum bilhete aguardando aprovação para este sorteio.
                      </div>
                    ) : (
                      <div className="space-y-3 max-h-72 overflow-y-auto pr-1">
                        {selectedRaffleTickets.filter(t => t.status === "pending").map((ticket) => {
                          const whatsappUrl = `https://wa.me/55${ticket.userPhone.replace(/\D/g, "")}`;
                          const formattedCpf = formatCPF(ticket.userCpf);
                          return (
                            <div 
                              key={ticket.id} 
                              className="bg-slate-50/55 p-3 rounded-xl border border-zinc-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                            >
                              <div className="space-y-1">
                                <div className="flex items-center gap-2">
                                  <span className="font-extrabold text-zinc-800 uppercase tracking-tight">{ticket.userName}</span>
                                  <span className="text-zinc-400 text-[10px]">({formattedCpf})</span>
                                </div>
                                <div className="flex whitespace-nowrap items-center gap-x-2 text-zinc-500 text-[11px] font-medium">
                                  <span className="text-blue-600 font-bold">Cota: <strong className="font-mono text-zinc-805">#{ticket.ticketNumber.toString().padStart(selectedRaffleToManage.totalNumbers > 100 ? 3 : 2, "0")}</strong></span>
                                  <span>•</span>
                                  <span>Celular: {ticket.userPhone}</span>
                                </div>
                              </div>

                              <div className="flex items-center gap-1.5 self-end sm:grid sm:grid-cols-3 sm:gap-2">
                                {/* WA redirect */}
                                <a 
                                  href={whatsappUrl} 
                                  target="_blank" 
                                  rel="noreferrer" 
                                  className="px-2 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 hover:text-emerald-850 font-black rounded-lg text-[9px] uppercase border border-emerald-250 text-center transition"
                                >
                                  WhatsApp
                                </a>

                                {/* Approve check */}
                                <button
                                  type="button"
                                  onClick={() => handleApproveSingleTicket(ticket)}
                                  className="px-2 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black rounded-lg text-[9px] uppercase transition cursor-pointer text-center"
                                >
                                  Aprovar
                                </button>

                                {/* Decline cross */}
                                <button
                                  type="button"
                                  onClick={() => handleDeclineSingleTicket(ticket)}
                                  className="px-2 py-1.5 bg-red-50 hover:bg-red-100 text-red-600 hover:text-red-700 font-black rounded-lg text-[9px] uppercase border border-red-200 transition cursor-pointer text-center"
                                >
                                  Liberar
                                </button>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>

                  {/* ACTIVE TICKET MULTI SELECT CONTROL AREA */}
                  <div className="bg-white p-5 rounded-[22px] border border-zinc-200 space-y-4 shadow-sm">
                    
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-zinc-100 pb-4">
                      
                      <div className="flex flex-wrap items-center gap-3">
                        <div className="relative">
                          <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-zinc-400">
                            <Search size={14} />
                          </span>
                          <input 
                            type="text" 
                            placeholder="Buscar cota ou nome..."
                            value={quotaGridSearch}
                            onChange={(e) => setQuotaGridSearch(e.target.value)}
                            className="bg-slate-50 border border-zinc-200 rounded-xl py-2 pl-9 pr-4 text-xs focus:outline-none focus:border-blue-500 text-zinc-800 placeholder-zinc-400 w-44 hover:bg-slate-50/55"
                          />
                        </div>

                        <div className="flex rounded-lg bg-slate-100 border border-zinc-200 p-0.5">
                          <button 
                            type="button"
                            onClick={() => setQuotaFilter("all")}
                            className={`px-3 py-1.5 rounded-md text-[9px] font-black uppercase tracking-wider transition ${quotaFilter === "all" ? "bg-white text-zinc-800 border border-zinc-200 shadow-xs" : "text-zinc-500 hover:text-zinc-800"}`}
                          >
                            Todos
                          </button>
                          <button 
                            type="button"
                            onClick={() => setQuotaFilter("free")}
                            className={`px-3 py-1.5 rounded-md text-[9px] font-black uppercase tracking-wider transition ${quotaFilter === "free" ? "bg-white text-zinc-800 border border-zinc-200 shadow-xs" : "text-zinc-500 hover:text-zinc-800"}`}
                          >
                            Livres
                          </button>
                          <button 
                            type="button"
                            onClick={() => setQuotaFilter("pending")}
                            className={`px-3 py-1.5 rounded-md text-[9px] font-black uppercase tracking-wider transition ${quotaFilter === "pending" ? "bg-white text-zinc-800 border border-zinc-200 shadow-xs" : "text-zinc-500 hover:text-zinc-800"}`}
                          >
                            Reservas
                          </button>
                          <button 
                            type="button"
                            onClick={() => setQuotaFilter("confirmed")}
                            className={`px-3 py-1.5 rounded-md text-[9px] font-black uppercase tracking-wider transition ${quotaFilter === "confirmed" ? "bg-white text-zinc-800 border border-zinc-200 shadow-xs" : "text-zinc-500 hover:text-zinc-800"}`}
                          >
                            Pagos
                          </button>
                        </div>
                      </div>

                      {/* Toggle Multi-selection checkbox Mode */}
                      <button 
                        type="button"
                        onClick={() => {
                          setMultiSelectEnabled(!multiSelectEnabled);
                          setSelectedQuotasForBatch([]);
                        }}
                        className={`inline-flex items-center space-x-1.5 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-wider transition cursor-pointer ${multiSelectEnabled ? "bg-blue-600 text-white shadow-sm" : "bg-slate-50 text-zinc-650 border border-zinc-200 hover:bg-slate-100"}`}
                      >
                        {multiSelectEnabled ? <CheckSquare size={13} /> : <Square size={13} />}
                        <span>{multiSelectEnabled ? "Sair Editar em Lote" : "Habilitar Alterar Lote"}</span>
                      </button>
                    </div>

                    {/* Pagination range for 1000 items */}
                    {selectedRaffleToManage.totalNumbers > 200 && (
                      <div className="flex flex-wrap gap-1 justify-center py-2 bg-slate-50 border-y border-zinc-150 transition">
                        {Array.from({ length: Math.ceil(selectedRaffleToManage.totalNumbers / 200) }).map((_, idx) => {
                          const start = idx * 200;
                          const end = Math.min(selectedRaffleToManage.totalNumbers - 1, (idx + 1) * 200 - 1);
                          const isActive = gridPaginationRange.start === start;
                          return (
                            <button 
                              key={idx}
                              type="button"
                              onClick={() => setGridPaginationRange({ start, end })}
                              className={`px-3 py-1.5 rounded-lg border text-[9px] font-black transition cursor-pointer leading-none ${isActive ? "bg-blue-600 text-white border-blue-600 shadow-xs" : "bg-white border-zinc-200 text-zinc-500 hover:bg-slate-100"}`}
                            >
                              {start.toString().padStart(3, "0")} - {end.toString().padStart(3, "0")}
                            </button>
                          );
                        })}
                      </div>
                    )}

                    {/* INTERACTIVE COMPRESSED GRID */}
                    <div className="max-h-[300px] overflow-y-auto pr-1">
                      <div className="grid grid-cols-5 sm:grid-cols-10 md:grid-cols-12 gap-1.5 font-mono text-[10px]">
                        {computedGridNumbers
                          .filter(item => item.number >= gridPaginationRange.start && item.number <= gridPaginationRange.end)
                          .map((item) => {
                            const isSelected = selectedQuotasForBatch.includes(item.number);
                            const t = item.ticket;

                            // Custom rules: FREE/Disponivel has FLAT WHITE BACKGROUND, Reserved YELLOW border, Paid GREEN border with pulsing light
                            let statusClass = "bg-white text-zinc-800 border border-zinc-200 hover:border-zinc-400 transition hover:shadow-xs";
                            let indicatorPulse = null;

                            if (t) {
                              if (t.status === "confirmed") {
                                statusClass = "bg-white text-zinc-900 border-2 border-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.08)] font-bold relative";
                                indicatorPulse = <span className="absolute top-1 right-1 h-3.5 w-1.5 bg-emerald-500 rounded-full animate-ping" />;
                              } else if (t.status === "pending") {
                                statusClass = "bg-white text-zinc-900 border-2 border-amber-400 shadow-[0_0_10px_rgba(245,158,11,0.05)] font-medium";
                              }
                            }

                            if (isSelected) {
                              statusClass = "bg-blue-600 text-white border-2 border-blue-400 shadow-[0_0_12px_rgba(37,99,235,0.3)] scale-102 font-black transition-all";
                              indicatorPulse = null;
                            }

                            return (
                              <button 
                                key={item.number}
                                type="button"
                                onClick={() => handleQuotaClickOnManage(item.number, !!t, t)}
                                className={`h-11 rounded-xl flex flex-col items-center justify-center cursor-pointer select-none leading-none tracking-tight gap-0.5 ${statusClass}`}
                              >
                                <span className="text-[11px] font-black">{item.number.toString().padStart(selectedRaffleToManage.totalNumbers > 100 ? 3 : 2, "0")}</span>
                                <span className="text-[7px] uppercase font-sans font-extrabold opacity-60">
                                  {t ? (t.status === "confirmed" ? "PAGO" : "PEND") : "LIVRE"}
                                </span>
                                {indicatorPulse}
                              </button>
                            );
                          })}
                      </div>
                    </div>

                    {/* FLOATING BATCH SETTING SLATE */}
                    {multiSelectEnabled && selectedQuotasForBatch.length > 0 && (
                      <div className="bg-blue-50 border border-blue-200 p-4 rounded-xl space-y-4 shadow-sm text-left animate-pulse-subtle">
                        <div className="flex items-center justify-between">
                          <p className="text-xs font-black text-blue-900 uppercase">
                            🔧 Alterar em Lote ({selectedQuotasForBatch.length} cotas selecionadas)
                          </p>
                          <button 
                            type="button" 
                            onClick={() => setSelectedQuotasForBatch([])}
                            className="text-zinc-500 hover:text-blue-700 text-xs uppercase font-extrabold"
                          >
                            Limpar Seleção
                          </button>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                          <div>
                            <label className="block text-[8px] uppercase font-black text-blue-800 mb-1">Mudar Status para</label>
                            <select 
                              value={batchActionType}
                              onChange={(e) => setBatchActionType(e.target.value as "free" | "pending" | "confirmed")}
                              className="w-full bg-white border border-zinc-200 text-xs px-2.5 py-2 text-zinc-800 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
                            >
                              <option value="confirmed">Confirmado / Pago ✔</option>
                              <option value="pending">Reservado / Pendente ⏰</option>
                              <option value="free">Livre / Liberar Número ❌</option>
                            </select>
                          </div>

                          {batchActionType !== "free" && (
                            <>
                              <div>
                                <label className="block text-[8px] uppercase font-black text-blue-800 mb-1">Nome do Comprador (Atribuição)</label>
                                <input 
                                  type="text" 
                                  placeholder="Nome rápido do cliente"
                                  value={batchBuyerName}
                                  onChange={(e) => setBatchBuyerName(e.target.value)}
                                  className="w-full bg-white border border-zinc-200 text-xs px-2.5 py-2 text-zinc-800 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 hover:bg-slate-50/50"
                                />
                              </div>
                              <div>
                                <label className="block text-[8px] uppercase font-black text-blue-800 mb-1">Telefone WhatsApp</label>
                                <input 
                                  type="text" 
                                  placeholder="Whats rápido"
                                  value={batchBuyerPhone}
                                  onChange={(e) => setBatchBuyerPhone(e.target.value)}
                                  className="w-full bg-white border border-zinc-200 text-xs px-2.5 py-2 text-zinc-800 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 hover:bg-slate-50/50"
                                />
                              </div>
                            </>
                          )}

                          <div className="flex items-end">
                            <button 
                              type="button"
                              onClick={handleBatchAlterSubmit}
                              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-black text-xs uppercase py-2 rounded-lg cursor-pointer transition shadow hover:scale-101"
                            >
                              {batchSubmitLoading ? "Sincronizando..." : "Aplicar em Lote"}
                            </button>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                <div className="text-center py-16 rounded-[22px] border border-zinc-200 border-dashed text-zinc-400 font-extrabold uppercase text-[10px] tracking-wider bg-white">
                  Por favor, escolha uma de suas campanhas acima para iniciar o cockpit de gestão.
                </div>
              )}
            </div>
          )}

          {/* TAB 3.5: RANKING VIEW */}
          {currentTab === "ranking" && (
            <div className="max-w-2xl mx-auto space-y-6 text-left">
              <div>
                <h2 className="text-xl font-black uppercase tracking-tight text-zinc-800 flex items-center gap-2">
                  <Trophy size={20} className="text-amber-500 animate-bounce" /> Ranking de Compras
                </h2>
                <p className="text-[11px] text-zinc-550 mt-1 leading-relaxed">
                  Confira em tempo real os participantes que adquiriram a maior quantidade de cotas pagas e confirmadas para cada sorteio ativo.
                </p>
                {selectedRankingRaffleId && (
                  <div className="mt-3 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 border border-blue-200/60 text-[10px] font-black uppercase tracking-wider text-blue-700">
                    <span className="w-1.5 h-1.5 rounded-full bg-blue-600 animate-pulse"></span>
                    Sorteio: {raffles.find(r => r.id === selectedRankingRaffleId)?.title || "Selecione"}
                  </div>
                )}
              </div>

              {/* Raffle Selection Dropdown - Shown only if the user has credentials for multiple raffle groups */}
              {userActiveRafflesWithTickets.length > 1 && (
                <div className="bg-white p-4.5 rounded-2xl border border-zinc-200 shadow-xs space-y-2">
                  <label className="block text-[9px] uppercase tracking-wider font-extrabold text-blue-600">Selecione o Sorteio</label>
                  <select
                    value={selectedRankingRaffleId}
                    onChange={(e) => setSelectedRankingRaffleId(e.target.value)}
                    className="w-full bg-white border border-zinc-200 rounded-xl px-3.5 py-3 text-xs font-bold text-zinc-850 focus:outline-none focus:ring-2 focus:ring-blue-600/40 focus:border-blue-600 transition cursor-pointer"
                  >
                    {userActiveRafflesWithTickets.map((r) => (
                      <option key={r.id} value={r.id}>
                        {r.title} — R$ {r.pricePerTicket.toFixed(2)} / cota
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {/* Ranking Grid */}
              <div className="bg-white rounded-[22px] border border-zinc-205 overflow-hidden shadow-xs">
                <div className="bg-slate-50/50 px-5 py-4 border-b border-zinc-150 flex justify-between items-center">
                  <span className="text-[10px] uppercase font-black tracking-widest text-zinc-400">Participante</span>
                  <span className="text-[10px] uppercase font-black tracking-widest text-zinc-400">Cotas Confirmadas</span>
                </div>

                {!profile ? (
                  <div className="text-center py-12 px-6">
                    <ShieldAlert className="mx-auto text-amber-500 mb-2.5" size={24} />
                    <p className="text-xs font-bold text-zinc-700 uppercase tracking-wide leading-none">Autenticação Necessária</p>
                    <p className="text-[11px] text-zinc-500 mt-2 max-w-sm mx-auto mb-4 leading-relaxed">
                      É preciso fazer login para visualizar o ranking de competidores ou participar das premiações.
                    </p>
                    <button
                      type="button"
                      onClick={() => setShowAuthModal(true)}
                      className="bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-[10px] uppercase tracking-wider px-4.5 py-2.5 rounded-xl cursor-pointer"
                    >
                      Fazer Login
                    </button>
                  </div>
                ) : !hasPurchasedForSelectedRaffle ? (
                  <div className="text-center py-14 px-6">
                    <ShieldAlert className="mx-auto text-amber-500 mb-3 animate-pulse" size={26} />
                    <p className="text-xs font-bold text-zinc-700 uppercase tracking-wide leading-none">Visualização Reservada</p>
                    <p className="text-[11px] text-zinc-550 mt-2.5 max-w-sm mx-auto leading-relaxed">
                      Você só poderá ver o ranking deste sorteio específico quando comprar pelo menos 1 bilhete nele! Ao concluir sua compra, você entrará na disputa e poderá ver os demais competidores em tempo real.
                    </p>
                  </div>
                ) : rankingList.length === 0 ? (
                  <div className="text-center py-16 text-zinc-400 font-extrabold uppercase text-[10px] tracking-wider leading-relaxed">
                    Nenhuma cota paga foi confirmada para este sorteio ainda.
                  </div>
                ) : (
                  <div className="divide-y divide-zinc-100">
                    {rankingList.map((entry, index) => {
                      const isTop3 = index < 3;
                      const placeColors = [
                        "bg-amber-100 text-amber-700 border-amber-250", // 1st
                        "bg-slate-100 text-slate-700 border-zinc-300",  // 2nd
                        "bg-orange-50 text-orange-700 border-orange-200" // 3rd
                      ];

                      return (
                        <div 
                          key={entry.cpf} 
                          className="px-5 py-4 flex items-center justify-between hover:bg-slate-50/50 transition duration-150"
                        >
                          <div className="flex items-center space-x-3 overflow-hidden">
                            {/* Position badge */}
                            {isTop3 ? (
                              <div className={`h-7 w-7 rounded-lg border flex items-center justify-center font-black text-xs ${placeColors[index]}`}>
                                {index + 1}
                              </div>
                            ) : (
                              <div className="h-7 w-7 rounded-lg bg-zinc-50 border border-zinc-150 flex items-center justify-center text-zinc-500 font-bold text-xs">
                                {index + 1}
                              </div>
                            )}

                            <div className="truncate">
                              <p className="font-extrabold text-xs text-zinc-800 leading-tight truncate">
                                {entry.name}
                              </p>
                              <p className="text-[8px] text-zinc-400 font-mono mt-0.5 tracking-wider leading-none">
                                CPF: ***.{entry.cpf.replace(/\D/g, "").substring(3, 6)}.{entry.cpf.replace(/\D/g, "").substring(6, 9)}-**
                              </p>
                            </div>
                          </div>

                          <div className="flex items-center space-x-2 shrink-0">
                            <span className="text-xs bg-blue-50 text-blue-600 font-black px-3.5 py-1.5 rounded-full border border-blue-200/60 shadow-xs">
                              {entry.count} {entry.count === 1 ? "cota" : "cotas"}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 4: MY TICKETS VIEW (Com fundo escuro e tickets em branco com número escuro!) */}
          {currentTab === "tickets" && (
            <div className="max-w-xl mx-auto bg-zinc-900 border border-zinc-800 p-6 md:p-8 rounded-[32px] text-white shadow-xl space-y-6 text-left">
              <div>
                <h2 className="text-lg font-black uppercase tracking-widest text-zinc-100 flex items-center gap-1.5">
                  <TicketIcon size={18} className="text-blue-400" /> Meus Bilhetes Adquiridos
                </h2>
                <p className="text-[11px] text-zinc-400 mt-1">
                  Seus bilhetes abaixo são indexados pelo seu CPF <span className="font-extrabold text-blue-400 font-mono">({profile?.cpf})</span>.
                </p>
              </div>

              {myTickets.length === 0 ? (
                <div className="text-center py-16 rounded-[22px] border border-zinc-800 border-dashed text-zinc-500 font-extrabold uppercase text-[10px] tracking-wider bg-zinc-950 shadow-sm">
                  Você ainda não possui nenhum bilhete reservado neste PWA.
                </div>
              ) : (
                <div className="space-y-4">
                  {myTickets.map((t) => {
                    const r = raffles.find((raffle) => raffle.id === t.raffleId);
                    const w = winners.find((win) => win.raffleId === t.raffleId);
                    const isRaffleFinished = r?.status === "finished";
                    const isWinnerTicket = w && w.winningNumber === t.ticketNumber;

                    return (
                      <div 
                        key={t.id} 
                        className={`relative rounded-[22px] overflow-hidden flex flex-row items-stretch min-h-[110px] transition-all duration-300 bg-white border ${
                          isWinnerTicket 
                            ? "border-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.25)]" 
                            : "border-zinc-200 shadow-sm"
                        }`}
                      >
                        {/* Info details coupon left side */}
                        <div className="flex-1 p-4 flex items-start gap-3.5 min-w-0 bg-white">
                          <div className="relative w-14 h-14 bg-slate-50 rounded-xl overflow-hidden flex-shrink-0 border border-zinc-200 flex items-center justify-center p-0.5">
                            {r?.image ? (
                              <img 
                                src={r.image} 
                                className="w-full h-full object-cover rounded-lg" 
                                alt={r.title}
                                referrerPolicy="no-referrer"
                              />
                            ) : (
                              <TicketIcon size={20} className="text-zinc-400" />
                            )}
                          </div>

                          <div className="min-w-0 flex-1 space-y-1">
                            <h4 className="font-extrabold text-sm text-zinc-900 truncate leading-tight">
                              {r?.title || "Campanha Sorteio"}
                            </h4>
                            <p className="text-[9px] text-zinc-500 font-black uppercase tracking-wider">
                              Locado em: {new Date(t.reservedAt).toLocaleDateString("pt-BR")}
                            </p>

                            {isRaffleFinished ? (
                              <div className="mt-1.5 p-1 bg-slate-50 rounded-lg border border-zinc-200/50 font-bold text-[10px] leading-tight text-zinc-600">
                                {isWinnerTicket ? (
                                  <span className="text-amber-600 animate-pulse flex items-center gap-1 font-black leading-none">
                                    🏆 PARABÉNS! Cota Vencedora!
                                  </span>
                                ) : w ? (
                                  <span className="text-zinc-500 text-[9px]">
                                    Sorteado: <span className="font-black text-zinc-700">{w.userName}</span> (Cota #{w.winningNumber.toString().padStart(3, "0")})
                                  </span>
                                ) : (
                                  <span className="text-zinc-400 italic">Sorteio finalizado</span>
                                )}
                              </div>
                            ) : (
                              <div className="mt-1.5 flex items-center gap-1">
                                <span className="inline-block w-1.5 h-1.5 bg-blue-500 rounded-full animate-pulse" />
                                <span className="text-[9px] text-blue-600 font-extrabold uppercase tracking-widest leading-none">Aguardando Sorteio Central</span>
                              </div>
                            )}
                          </div>
                        </div>

                        {/* Perforation line divide */}
                        <div className="relative w-px flex flex-col items-center justify-between py-2 flex-shrink-0 z-10 bg-white">
                          <div className="absolute -top-3.5 -left-1.5 w-3 h-3 bg-zinc-900 rounded-full border border-zinc-200" />
                          <div className="w-px h-full border-l border-dashed border-zinc-200" />
                          <div className="absolute -bottom-3.5 -left-1.5 w-3 h-3 bg-zinc-900 rounded-full border border-zinc-200" />
                        </div>

                        {/* Coupon voucher right side is ALSO white background */}
                        <div className={`w-28 flex flex-col items-center justify-center p-3 text-center flex-shrink-0 bg-white`}>
                          <span className="text-[8px] font-black text-zinc-400 uppercase tracking-widest leading-none">Bilhete</span>
                          <span className="text-xl font-mono leading-none my-1 font-extrabold tracking-tighter text-zinc-900">
                            #{t.ticketNumber.toString().padStart(selectedRaffle?.totalNumbers === 1000 ? 3 : 2, "0")}
                          </span>

                          {isWinnerTicket ? (
                            <span className="bg-amber-400 text-white font-black text-[7px] uppercase px-1 py-0.5 rounded shadow-xs">
                              Prêmio!
                            </span>
                          ) : t.status === "confirmed" ? (
                            <span className="bg-emerald-50 border border-emerald-200 text-emerald-600 font-black text-[7px] uppercase px-1.5 py-0.5 rounded leading-none shadow-xs">
                              Pago ✔
                            </span>
                          ) : (
                            <span className="bg-amber-50 border border-amber-200 text-amber-600 font-extrabold text-[7px] uppercase px-1.5 py-0.5 rounded leading-none shadow-xs">
                              Pendente ⏰
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </div>

          {/* 3. MOBILE GLASSMORPHIC BOTTOM NAVIGATION (Floating) */}
      <div className="md:hidden fixed bottom-4 inset-x-4 z-40 select-none">
        <div className="bg-white/90 backdrop-blur-lg border border-zinc-200 p-1.5 pr-2.5 rounded-full flex items-center justify-around shadow-lg shadow-zinc-300/30 max-w-sm mx-auto">
          <button 
            type="button"
            onClick={() => setCurrentTab("home")}
            className={`flex flex-col items-center justify-center p-2.5 rounded-full transition-all cursor-pointer ${currentTab === "home" ? "bg-blue-600 text-white shadow-xs" : "text-zinc-500"}`}
          >
            <Clock size={16} />
            <span className="text-[7px] uppercase font-black tracking-widest mt-0.5">Início</span>
          </button>
          
          {profile && profile.isCreator && (
            <button 
              type="button"
              onClick={() => setShowCreatorPanel(true)}
              className="flex flex-col items-center justify-center p-2.5 rounded-full transition-all cursor-pointer text-blue-600"
            >
              <Sparkles size={16} />
              <span className="text-[7px] uppercase font-black tracking-widest mt-0.5">Afiliado</span>
            </button>
          )}

          {profile && !profile.isAdmin && !profile.isCreator && (
            <button 
              type="button"
              onClick={() => setCurrentTab("tickets")}
              className={`flex flex-col items-center justify-center p-2.5 rounded-full transition-all cursor-pointer ${currentTab === "tickets" ? "bg-blue-600 text-white shadow-xs" : "text-zinc-500"}`}
            >
              <TicketIcon size={16} />
              <span className="text-[7px] uppercase font-black tracking-widest mt-0.5">Meus Bilhetes</span>
            </button>
          )}

          {profile && profile.isAdmin && (
            <button 
              type="button"
              onClick={() => {
                setAdminPanelDefaultTab("afiliados");
                setShowAdminPanel(true);
              }}
              className="flex flex-col items-center justify-center p-2.5 rounded-full transition-all cursor-pointer text-zinc-500"
            >
              <Users size={16} />
              <span className="text-[7px] uppercase font-black tracking-widest mt-0.5">Afiliados</span>
            </button>
          )}

          <button 
            type="button"
            onClick={() => setCurrentTab("ranking")}
            className={`flex flex-col items-center justify-center p-2.5 rounded-full transition-all cursor-pointer ${currentTab === "ranking" ? "bg-blue-600 text-white shadow-xs" : "text-zinc-500"}`}
          >
            <Award size={16} />
            <span className="text-[7px] uppercase font-black tracking-widest mt-0.5">Ranking</span>
          </button>
        </div>
      </div>

      {/* 4. FOOTER COPY */}
      <footer className="py-8 bg-slate-50 border-t border-zinc-200 text-center select-none text-[11px] text-zinc-500 mt-16 pb-28 md:pb-8">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="font-extrabold flex items-center text-zinc-700 uppercase tracking-wider text-[11px]">
            <Clover className="text-blue-600 mr-1 animate-pulse" size={14} /> LuckyNeon Rental SaaS
          </p>
          <p className="text-zinc-550">© 2026. Todos os direitos reservados. Sorteios validados e homologados.</p>
          <button 
            onClick={() => setShowTermsModal(true)} 
            className="hover:underline text-blue-600 font-extrabold cursor-pointer uppercase text-[10px]"
          >
            Regulamento de Uso
          </button>
        </div>
      </footer>

      {/* --- ALL OVERLAY MODALS & PORTALS --- */}



      {/* Custom Auth Modal overlay */}
      <AnimatePresence>
        {showAuthModal && (
          <CustomAuthModal 
            onClose={() => setShowAuthModal(false)} 
            onLoginSuccess={(prof) => {
              setProfile(prof);
              setShowAuthModal(false);
              if (prof.isCreator && !prof.isAdmin) {
                setShowCreatorPanel(true);
              } else if (prof.isAdmin) {
                setShowAdminPanel(true);
              }
            }} 
          />
        )}
      </AnimatePresence>

      {/* 2. Sorteio Checkout Interactive Selection Modal */}
      <AnimatePresence>
        {selectedRaffle && (
          <RaffleDetailModal 
            raffle={selectedRaffle}
            profile={profile}
            onClose={() => setSelectedRaffle(null)}
            onLoginPrompt={handleLoginPromptWithWarning}
            isQuotaExceeded={isQuotaExceeded}
            allTicketsList={allTickets}
            onReserveLocalTickets={(newTickets) => {
              setAllTickets(prev => [...prev, ...newTickets]);
              if (profile) {
                setMyTickets(prev => [...newTickets, ...prev]);
              }
            }}
          />
        )}
      </AnimatePresence>

      {/* 3. Global Terms overlay */}
      <AnimatePresence>
        {showTermsModal && (
          <TermsModal onClose={() => setShowTermsModal(false)} />
        )}
      </AnimatePresence>

      {/* 4. Root administrator transaction workspace overlay */}
      <AnimatePresence>
        {showAdminPanel && isAdmin && profile && (
          <AdminPanel onClose={() => setShowAdminPanel(false)} profile={profile} />
        )}
      </AnimatePresence>

      {/* 4b. Affiliate Creator Panel */}
      <AnimatePresence>
        {showCreatorPanel && profile && profile.isCreator && !profile.isAdmin && (
          <CreatorPanel profile={profile} onClose={() => setShowCreatorPanel(false)} />
        )}
      </AnimatePresence>

      {/* 5. Live Winner Drawing Roll Modal */}
      <AnimatePresence>
        {showDrawModal && selectedRaffleToManage && (
          <div className="fixed inset-0 z-50 bg-zinc-900/60 flex items-center justify-center p-4 backdrop-blur-sm overflow-y-auto">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-md bg-white border border-zinc-200 rounded-[24px] overflow-hidden shadow-2xl text-left"
            >
              <div className="bg-white px-6 py-4 border-b border-zinc-100 flex items-center justify-between">
                <span className="font-extrabold text-xs uppercase tracking-widest text-zinc-800 flex items-center gap-1.5">
                  <Award size={16} className="text-blue-600 animate-pulse" /> Sorteio de Vencedor
                </span>
                <button 
                  onClick={() => setShowDrawModal(false)}
                  className="p-1 text-zinc-400 hover:text-zinc-600 transition cursor-pointer"
                >
                  <X size={18} />
                </button>
              </div>

              <div className="p-6 space-y-4">
                
                {drawError && (
                  <div className="bg-red-50 border border-red-200 rounded-xl p-3 text-xs text-red-700 leading-normal font-bold">
                    ⚠️ {drawError}
                  </div>
                )}
                {drawSuccess && (
                  <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 text-xs text-emerald-800 leading-normal font-black">
                    ✔ {drawSuccess}
                  </div>
                )}

                {/* Method selector */}
                <div className="flex rounded-lg bg-slate-100 border border-zinc-200 p-0.5">
                  <button 
                    type="button"
                    onClick={() => {
                      setDrawMethod("system");
                      setDrawnWinnerTicket(null);
                      setDrawSuccess("");
                      setDrawError("");
                    }}
                    className={`flex-1 py-2 rounded-md text-[10px] font-black uppercase tracking-wider transition cursor-pointer ${drawMethod === "system" ? "bg-white text-zinc-800 border border-zinc-200 shadow-xs" : "text-zinc-500 hover:text-zinc-800"}`}
                  >
                    Aleatório do Sistema
                  </button>
                  <button 
                    type="button"
                    onClick={() => {
                      setDrawMethod("manual");
                      setDrawnWinnerTicket(null);
                      setDrawSuccess("");
                      setDrawError("");
                    }}
                    className={`flex-1 py-2 rounded-md text-[10px] font-black uppercase tracking-wider transition cursor-pointer ${drawMethod === "manual" ? "bg-white text-zinc-800 border border-zinc-200 shadow-xs" : "text-zinc-500 hover:text-zinc-800"}`}
                  >
                    Digitar Número
                  </button>
                </div>

                {isSpinning ? (
                  <div className="py-8 bg-slate-50 border border-zinc-150 rounded-2xl flex flex-col items-center justify-center space-y-3">
                    <p className="text-[10px] text-zinc-500 uppercase tracking-widest font-black animate-pulse">Rodando roleta de pagamentos...</p>
                    <span className="text-4xl font-mono font-black tracking-widest text-blue-600 text-center animate-bounce">
                      #{spinNum.toString().padStart(selectedRaffleToManage.totalNumbers > 100 ? 3 : 2, "0")}
                    </span>
                  </div>
                ) : (
                  <>
                    {drawMethod === "manual" && (
                      <div>
                        <label className="block text-[8px] uppercase tracking-widest font-black text-blue-600 mb-1.5">Insira o Número Vencedor (Validação Pago)</label>
                        <div className="flex gap-2">
                          <input 
                            type="number"
                            placeholder="Ex 45"
                            value={manualWinningNum}
                            onChange={(e) => setManualWinningNum(e.target.value === "" ? "" : Number(e.target.value))}
                            className="bg-white border border-zinc-200 focus:outline-none focus:ring-1 focus:ring-blue-500 rounded-xl px-3.5 py-3 text-xs text-zinc-800 placeholder-zinc-400 w-full"
                          />
                          <button 
                            type="button"
                            onClick={handleInitialDrawExecute}
                            className="px-4 py-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-zinc-700 font-extrabold text-xs uppercase cursor-pointer border border-zinc-200 transition"
                          >
                            Validar
                          </button>
                        </div>
                      </div>
                    )}

                    {drawMethod === "system" && !drawnWinnerTicket && (
                      <button 
                        type="button"
                        onClick={handleInitialDrawExecute}
                        className="w-full py-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs uppercase font-black tracking-widest cursor-pointer shadow-xs transition active:scale-98"
                      >
                        Sortear Cota Vencedora Aleatório
                      </button>
                    )}

                    {/* Show Drawn details & Prize photo submission */}
                    {drawnWinnerTicket && (
                      <form onSubmit={handleSaveAndPublishDraw} className="space-y-4 pt-2 border-t border-zinc-100">
                        <div className="bg-slate-50 p-3.5 rounded-xl border border-zinc-200 space-y-1">
                          <p className="text-[9px] uppercase font-bold text-blue-600">Ganhador Identificado</p>
                          <p className="text-xs font-black text-zinc-850">{drawnWinnerTicket.userName}</p>
                          <p className="text-[10px] text-zinc-500 font-mono">Telefone Whats: {drawnWinnerTicket.userPhone}</p>
                          <p className="text-[10px] text-zinc-500 font-mono">CPF Registrada: {drawnWinnerTicket.userCpf}</p>
                        </div>

                        <div>
                          <label className="block text-[8px] uppercase tracking-widest font-black text-blue-600 mb-1.5">Anexe uma Foto da Entrega do Prêmio (Opcional)</label>
                          <div 
                            onClick={() => fileWinnerRef.current?.click()}
                            className="border border-dashed border-zinc-200 hover:border-blue-500 py-4 rounded-xl bg-slate-50/30 text-center cursor-pointer transition text-zinc-500 text-xs"
                          >
                            <input 
                              type="file" 
                              ref={fileWinnerRef} 
                              accept="image/*" 
                              className="hidden" 
                              onChange={handleWinnerDrawPhotoUpload} 
                            />
                            {drawnWinnerPhoto ? (
                              <p className="text-blue-600 font-extrabold text-[11px]">Foto da entrega carregada! Trocar?</p>
                            ) : (
                              <p className="text-zinc-550 font-bold text-[10px]">Carregar comprovante de entrega do prêmio</p>
                            )}
                          </div>
                        </div>

                        <button 
                          type="submit"
                          disabled={savingDrawLoading}
                          className="w-full relative py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black uppercase tracking-wider rounded-xl cursor-pointer transition shadow"
                        >
                          {savingDrawLoading ? "Homologando resultado..." : "Homologar Sorteio Concluído"}
                        </button>
                      </form>
                    )}
                  </>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* EXQUISITE STATE CONFIRMATION DIALOG MODAL */}
      <AnimatePresence>
        {confirmDialog && (
          <div className="fixed inset-0 z-[120] bg-black/60 flex items-center justify-center p-4 backdrop-blur-xs">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="relative w-full max-w-sm bg-white rounded-2xl border border-zinc-200 overflow-hidden shadow-2xl p-5 flex flex-col text-left"
            >
              <div className="flex items-center gap-2.5 text-red-650 mb-3 border-b border-zinc-100 pb-2.5">
                <ShieldAlert size={20} className="flex-shrink-0 text-red-600" />
                <h3 className="text-zinc-800 font-extrabold text-xs uppercase tracking-wider">{confirmDialog.title}</h3>
              </div>
              <p className="text-xs text-zinc-650 leading-relaxed font-bold mb-5">
                {confirmDialog.description}
              </p>
              <div className="flex items-center justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setConfirmDialog(null)}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-extrabold px-4 py-2.5 rounded-xl text-[10px] uppercase transition cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={() => {
                    confirmDialog.onConfirm();
                    setConfirmDialog(null);
                  }}
                  className="bg-red-600 hover:bg-red-700 text-white font-extrabold px-4 py-2.5 rounded-xl text-[10px] uppercase shadow-sm transition cursor-pointer"
                >
                  Confirmar
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
