/**
 * Compresses an image file on the client side using HTML5 Canvas.
 * It resizes the image so that neither its width nor height exceeds maxWidthOrHeight (default: 800).
 * It then exports the canvas as a Base64-encoded JPEG image with a designated compression quality.
 */
export function compressImage(
  file: File,
  maxWidthOrHeight: number = 800,
  quality: number = 0.7
): Promise<string> {
  return new Promise((resolve, reject) => {
    // If it's not an image file, fail fast
    if (!file.type.startsWith("image/")) {
      reject(new Error("O arquivo selecionado não é uma imagem válida."));
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement("canvas");
        let width = img.width;
        let height = img.height;

        // Resize calculation to keep ratio intact
        if (width > height) {
          if (width > maxWidthOrHeight) {
            height = Math.round((height * maxWidthOrHeight) / width);
            width = maxWidthOrHeight;
          }
        } else {
          if (height > maxWidthOrHeight) {
            width = Math.round((width * maxWidthOrHeight) / height);
            height = maxWidthOrHeight;
          }
        }

        canvas.width = width;
        canvas.height = height;

        const ctx = canvas.getContext("2d");
        if (!ctx) {
          reject(new Error("Falha ao obter contexto 2D do Canvas."));
          return;
        }

        // Draw image onto canvas
        ctx.drawImage(img, 0, 0, width, height);

        // Convert canvas image to Base64 JPEG with the desired custom quality factor
        try {
          const dataUrl = canvas.toDataURL("image/jpeg", quality);
          resolve(dataUrl);
        } catch (e) {
          reject(e);
        }
      };

      img.onerror = () => {
        reject(new Error("Erro ao carregar os dados da imagem."));
      };

      if (typeof event.target?.result === "string") {
        img.src = event.target.result;
      } else {
        reject(new Error("Resultado do FileReader inválido."));
      }
    };

    reader.onerror = () => {
      reject(new Error("Erro ao ler o arquivo."));
    };

    reader.readAsDataURL(file);
  });
}

/**
 * Computes standard CCITT-FALSE CRC16 checksum for BR-Code / EMV PIX specification
 */
export function calculateCRC16(data: string): string {
  let crc = 0xFFFF;
  for (let i = 0; i < data.length; i++) {
    const x = ((crc >> 8) ^ data.charCodeAt(i)) & 0xFF;
    const x2 = x ^ (x >> 4);
    crc = ((crc << 8) ^ (x2 << 12) ^ (x2 << 5) ^ (x2)) & 0xFFFF;
  }
  return crc.toString(16).toUpperCase().padStart(4, "0");
}

/**
 * Dynamically constructs a compliant Pix Copia e Cola / BR-Code string 
 * with exactly calculated transaction amounts and transaction labels.
 */
export function generatePixCopiaECola(
  key: string = "70324615493",
  receiver: string = "Romario Alves do Nascimen",
  amount: number = 0
): string {
  // Clean special characters from key
  const sanitizedKey = key.trim().replace(/[\s\(\)\-\.]/g, "");

  // Format Name: remove special accents, limit length to max 25 characters for safety
  const sanitizedReceiver = receiver
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "") 
    .replace(/[^a-zA-Z0-9 ]/g, "") 
    .substring(0, 25)
    .trim();

  // Payload Format Indicator (00)
  const tag00 = "000201";

  // Merchant Account Info (26)
  const subtag00 = "0014BR.GOV.BCB.PIX";
  const subtag01 = `01${sanitizedKey.length.toString().padStart(2, "0")}${sanitizedKey}`;
  const tag26Val = subtag00 + subtag01;
  const tag26 = `26${tag26Val.length.toString().padStart(2, "0")}${tag26Val}`;

  // Merchant Category Code (52)
  const tag52 = "52040000";

  // Transaction Currency (53): 986 -> BRL
  const tag53 = "5303986";

  // Transaction Amount (54)
  let tag54 = "";
  if (amount > 0) {
    const amtStr = amount.toFixed(2);
    tag54 = `54${amtStr.length.toString().padStart(2, "0")}${amtStr}`;
  }

  // Country Code (58)
  const tag58 = "5802BR";

  // Name (59)
  const tag59 = `59${sanitizedReceiver.length.toString().padStart(2, "0")}${sanitizedReceiver}`;

  // City (60)
  const tag60 = "6009SAO PAULO";

  // Additional Data (62) - TxID standard label
  const subtag05 = "051077i82OLnj5";
  const tag62 = `62${subtag05.length.toString().padStart(2, "0")}${subtag05}`;

  // CRC Placeholder (63)
  const tag63 = "6304";

  const rawPayload = tag00 + tag26 + tag52 + tag53 + tag54 + tag58 + tag59 + tag60 + tag62 + tag63;
  const crc = calculateCRC16(rawPayload);
  
  return rawPayload + crc;
}
