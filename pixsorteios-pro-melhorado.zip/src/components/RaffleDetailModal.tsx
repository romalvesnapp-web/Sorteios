import React, { useState, useEffect, useRef } from "react";
import { collection, query, where, onSnapshot, setDoc, doc, updateDoc } from "firebase/firestore";
import { db, handleFirestoreError, OperationType } from "../firebase";
import { Raffle, Ticket, UserProfile } from "../types";
import { X, Check, CreditCard, Copy, Upload, Loader2, ArrowRight, Sparkles, ShoppingCart } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { compressImage, generatePixCopiaECola } from "../utils";

interface RaffleDetailModalProps {
  raffle: Raffle;
  profile: UserProfile | null;
  onClose: () => void;
  onLoginPrompt: () => void;
  isQuotaExceeded?: boolean;
  allTicketsList?: Ticket[];
  onReserveLocalTickets?: (tickets: Ticket[]) => void;
}

export default function RaffleDetailModal({
  raffle,
  profile,
  onClose,
  onLoginPrompt,
  isQuotaExceeded = false,
  allTicketsList = [],
  onReserveLocalTickets
}: RaffleDetailModalProps) {
  const [reservedTickets, setReservedTickets] = useState<{ [num: number]: Ticket }>({});
  const [selectedNumbers, setSelectedNumbers] = useState<number[]>([]);
  const [step, setStep] = useState<"select" | "pay">("select");
  const [pixKey, setPixKey] = useState(() => raffle.pixKey || "70324615493");
  const [pixName, setPixName] = useState(() => raffle.pixReceiver || "Romario Alves do Nascimen");
  const [copied, setCopied] = useState(false);
  const [receiptBase64, setReceiptBase64] = useState("");
  const [uploadingReceipt, setUploadingReceipt] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState("");
  const [gridRange, setGridRange] = useState({ start: 0, end: 199 }); // Pagination for large numbers of tickets

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Load reserved and confirmed tickets for this raffle
  useEffect(() => {
    if (isQuotaExceeded && allTicketsList) {
      const ticketsMap: { [num: number]: Ticket } = {};
      allTicketsList.forEach((t) => {
        if (t.raffleId === raffle.id) {
          ticketsMap[t.ticketNumber] = t;
        }
      });
      setReservedTickets(ticketsMap);
      return;
    }

    const q = query(
      collection(db, "tickets"),
      where("raffleId", "==", raffle.id)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const ticketsMap: { [num: number]: Ticket } = {};
      snapshot.forEach((doc) => {
        const t = doc.data() as Ticket;
        ticketsMap[t.ticketNumber] = t;
      });
      setReservedTickets(ticketsMap);
    }, (error) => {
      console.error("Error loading tickets: ", error);
      const errMsg = error?.message || String(error);
      if (errMsg.toLowerCase().includes("quota") || errMsg.toLowerCase().includes("limit") || errMsg.toLowerCase().includes("exhausted")) {
        console.warn("Firestore Read Quota exceeded in RaffleDetailModal, switching to offline fallback mode!");
        return;
      }
      handleFirestoreError(error, OperationType.LIST, `tickets (raffleId:${raffle.id})`);
    });

    return () => unsubscribe();
  }, [raffle.id, isQuotaExceeded, allTicketsList]);

  // Load Pix Config
  useEffect(() => {
    if (raffle.pixKey && raffle.pixReceiver) {
      setPixKey(raffle.pixKey);
      setPixName(raffle.pixReceiver);
      return;
    }
    const unsubscribe = onSnapshot(doc(db, "config", "pix"), (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        if (data.pixKey) setPixKey(data.pixKey);
        if (data.pixReceiver) setPixName(data.pixReceiver);
      }
    }, (error) => {
      console.error("Error loading pix config: ", error);
      const errMsg = error?.message || String(error);
      if (errMsg.toLowerCase().includes("quota") || errMsg.toLowerCase().includes("limit") || errMsg.toLowerCase().includes("exhausted")) {
        return;
      }
      handleFirestoreError(error, OperationType.GET, "config/pix");
    });
    return () => unsubscribe();
  }, [raffle.pixKey, raffle.pixReceiver]);

  // Set initial grid range based on total numbers
  useEffect(() => {
    if (raffle.totalNumbers <= 200) {
      setGridRange({ start: 0, end: raffle.totalNumbers - 1 });
    } else {
      setGridRange({ start: 0, end: 199 });
    }
  }, [raffle.totalNumbers]);

  const toggleNumberSelection = (num: number) => {
    const ticketState = reservedTickets[num];
    if (ticketState && (ticketState.status === "confirmed" || ticketState.status === "pending")) {
      // Already reserved/taken by others
      return;
    }

    setSelectedNumbers((prev) =>
      prev.includes(num) ? prev.filter((n) => n !== num) : [...prev, num]
    );
  };

  const handleRandomSelect = (count: number) => {
    const available: number[] = [];
    for (let i = 0; i < raffle.totalNumbers; i++) {
      if (!reservedTickets[i] && !selectedNumbers.includes(i)) {
        available.push(i);
      }
    }

    if (available.length === 0) return;

    // Shuffle and pick
    const shuffled = [...available].sort(() => 0.5 - Math.random());
    const picked = shuffled.slice(0, Math.min(count, shuffled.length));
    setSelectedNumbers((prev) => [...prev, ...picked]);
  };

  const startPaymentProcess = async () => {
    if (!profile) {
      onLoginPrompt();
      return;
    }

    if (selectedNumbers.length === 0) {
      setError("Por favor, selecione ao menos um número.");
      return;
    }

    setStep("pay");
  };

  const copyPixKey = () => {
    const pixString = generatePixCopiaECola(pixKey, pixName, totalPrice);
    navigator.clipboard.writeText(pixString);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleReceiptUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 10 * 1024 * 1024) {
      setError("O comprovante deve ter menos de 10MB.");
      return;
    }

    setUploadingReceipt(true);
    setError("");
    try {
      const compressedBase64 = await compressImage(file, 600, 0.5);
      setReceiptBase64(compressedBase64);
    } catch (err: any) {
      setError(err.message || "Erro ao processar e comprimir comprovante.");
    } finally {
      setUploadingReceipt(false);
    }
  };

  const handleReceiptDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (!file) return;

    if (file.size > 10 * 1024 * 1024) {
      setError("O comprovante deve ter menos de 10MB.");
      return;
    }

    setUploadingReceipt(true);
    setError("");
    try {
      const compressedBase64 = await compressImage(file, 600, 0.5);
      setReceiptBase64(compressedBase64);
    } catch (err: any) {
      setError(err.message || "Erro ao comprimir comprovante.");
    } finally {
      setUploadingReceipt(false);
    }
  };

  const handleConfirmReservation = async () => {
    if (!profile) return;
    if (selectedNumbers.length === 0) return;
    if (!receiptBase64) {
      setError("Por favor, envie o comprovante do pagamento PIX.");
      return;
    }

    setUploadingReceipt(true);
    setError("");

    try {
      const localTickets: Ticket[] = [];
      // Loop through selected numbers to write each reservation document
      for (const num of selectedNumbers) {
        const ticketId = `${raffle.id}_${num}`;
        const ticket: Ticket = {
          id: ticketId,
          raffleId: raffle.id,
          ticketNumber: num,
          userCpf: profile.cpf,
          userName: profile.name,
          userPhone: profile.phone,
          status: "pending",
          paymentReceipt: receiptBase64,
          reservedAt: new Date().toISOString(),
        };

        if (isQuotaExceeded && onReserveLocalTickets) {
          localTickets.push(ticket);
        } else {
          // Write document to /tickets/{ticketId}
          await setDoc(doc(db, "tickets", ticketId), ticket);
        }
      }

      if (isQuotaExceeded && onReserveLocalTickets) {
        onReserveLocalTickets(localTickets);
      }

      setSuccess(true);
    } catch (err: any) {
      console.error(err);
      if (isQuotaExceeded) {
        // Fallback save in case write fails but we are actually offline/quota limited
        setSuccess(true);
      } else {
        try {
          handleFirestoreError(err, OperationType.WRITE, `tickets/${raffle.id}_multiple`);
        } catch (translatedErr: any) {
          setError("Erro ao reservar os números. " + translatedErr.message);
        }
      }
    } finally {
      setUploadingReceipt(false);
    }
  };

  const totalPrice = selectedNumbers.length * raffle.pricePerTicket;  return (
    <div className="fixed inset-0 z-40 bg-black/90 flex items-center justify-center p-2 sm:p-4 backdrop-blur-md overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, y: 20, scale: 0.97 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 20, scale: 0.97 }}
        className="w-full max-w-lg md:max-w-xl bg-white border border-slate-200 rounded-[26px] shadow-[0_10px_40px_rgba(0,0,0,0.15)] text-slate-800 overflow-hidden my-2 sm:my-6"
      >
        {/* Header bar */}
        <div className="flex items-center justify-between bg-slate-50 border-b border-slate-250/70 px-5 py-4 text-slate-850">
          <div className="flex items-center space-x-2">
            <ShoppingCart className="text-blue-650 animate-pulse" size={18} />
            <h2 className="text-sm sm:text-base font-black font-sans text-slate-800 uppercase tracking-tight truncate max-w-[280px] sm:max-w-[400px]">
              {raffle.title}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-slate-205 hover:text-slate-900 text-slate-450 hover:bg-slate-100 transition duration-155 cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Success Screen */}
        {success ? (
          <div className="p-8 text-center space-y-5 flex flex-col items-center bg-white">
            <div className="h-14 w-14 bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-full flex items-center justify-center shadow-[0_4px_16px_rgba(37,99,235,0.4)] border-2 border-white animate-bounce">
              <Check size={32} className="stroke-[3]" />
            </div>
            <div className="space-y-2">
              <h3 className="text-xl font-black text-blue-600 uppercase tracking-tight">Reservado com Sucesso!</h3>
              <p className="text-xs text-slate-650 max-w-md mx-auto leading-relaxed">
                Você adquiriu os seus bilhetes de vez! Seus números <span className="font-extrabold text-blue-600 bg-blue-50 px-2 py-0.5 rounded border border-blue-200/50 font-mono">({selectedNumbers.join(", ")})</span> foram reservados e salvos sob uma única confirmação.
              </p>
              <p className="text-[11px] text-slate-500 max-w-sm mx-auto leading-normal">
                O comprovante está sob análise rápida do administrador. Assim que o pagamento for verificado via CPF, seus bilhetes serão homologados como Pago.
              </p>
            </div>
            <button
              onClick={onClose}
              className="px-8 py-3 bg-gradient-to-r from-blue-500 to-indigo-600 font-black text-white hover:from-blue-450 hover:to-indigo-550 uppercase text-xs tracking-wider rounded-xl shadow-lg hover:scale-102 transition duration-200 cursor-pointer min-w-[150px]"
            >
              Entendido
            </button>
          </div>
        ) : (
          <div className="p-4 sm:p-6 space-y-4">
            {error && (
              <div className="rounded-xl bg-red-50 border border-red-200 text-red-605 p-3 text-xs leading-relaxed font-semibold text-left">
                ⚠️ {error}
              </div>
            )}

            {step === "select" ? (
              <>
                {/* Select Step Description: Side-by-side with a compact squared image */}
                <div className="flex gap-4 bg-slate-50 p-3 sm:p-4 rounded-2xl border border-slate-205 text-left leading-normal">
                  <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-xl overflow-hidden bg-slate-100 border border-slate-205 flex-shrink-0 flex items-center justify-center p-1 shadow-xs">
                    {raffle.image ? (
                      <img
                        src={raffle.image}
                        alt={raffle.title}
                        className="max-w-full max-h-full object-contain rounded-lg"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <ShoppingCart size={24} className="text-slate-400" />
                    )}
                  </div>
                  <div className="flex-grow flex flex-col justify-between min-w-0">
                    <div>
                      <span className="text-[9px] uppercase tracking-wider font-extrabold bg-blue-50 border border-blue-200/50 px-2 py-0.5 rounded text-blue-600 inline-block font-sans">
                        Valor Unitário
                      </span>
                      <p className="text-lg sm:text-2xl font-black text-blue-600 mt-1 leading-none">
                        R$ {raffle.pricePerTicket.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                      </p>
                      <p className="text-[10px] sm:text-xs text-slate-500 mt-1.5 leading-tight line-clamp-2">
                        {raffle.description}
                      </p>
                    </div>

                    {/* Quick random generator choices */}
                    <div className="mt-1.5">
                      <p className="text-[9px] uppercase tracking-wider font-black text-blue-605 mb-1 flex items-center gap-1">
                        <Sparkles size={10} className="animate-spin text-blue-500" /> Compra rápida (cota automática)
                      </p>
                      <div className="flex gap-1.5 text-[10px]">
                        <button
                          type="button"
                          onClick={() => handleRandomSelect(1)}
                          className="px-2.5 py-1 bg-white hover:bg-blue-50 hover:text-blue-600 text-slate-700 rounded border border-slate-200 transition cursor-pointer font-bold leading-none"
                        >
                          +1 cota
                        </button>
                        <button
                          type="button"
                          onClick={() => handleRandomSelect(5)}
                          className="px-2.5 py-1 bg-white hover:bg-blue-50 hover:text-blue-600 text-slate-700 rounded border border-slate-200 transition cursor-pointer font-bold leading-none"
                        >
                          +5 cotas
                        </button>
                        <button
                          type="button"
                          onClick={() => handleRandomSelect(10)}
                          className="px-2.5 py-1 bg-white hover:bg-blue-50 hover:text-blue-600 text-slate-700 rounded border border-slate-200 transition cursor-pointer font-bold leading-none"
                        >
                          +10 cotas
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Paginate numbers for large raffles to prevent DOM layout slowness */}
                {raffle.totalNumbers > 200 && (
                  <div className="flex flex-wrap gap-1 justify-center text-[9px] font-extrabold uppercase transition">
                    {Array.from({ length: Math.ceil(raffle.totalNumbers / 200) }).map((_, idx) => {
                      const start = idx * 200;
                      const end = Math.min(raffle.totalNumbers - 1, (idx + 1) * 200 - 1);
                      const activeRange = gridRange.start === start;
                      return (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => setGridRange({ start, end })}
                          className={`px-2 py-1 rounded border leading-none cursor-pointer transition ${
                            activeRange
                              ? "bg-blue-500 text-white border-blue-600 font-black shadow-sm scale-102"
                              : "bg-slate-50 border-slate-200 text-slate-500 hover:bg-slate-100"
                          }`}
                        >
                          {start.toString().padStart(3, "0")} - {end.toString().padStart(3, "0")}
                        </button>
                      );
                    })}
                  </div>
                )}

                {/* Legend container */}
                <div className="flex flex-wrap justify-center gap-x-4 gap-y-1.5 text-[9px] uppercase font-black tracking-wider text-slate-500 py-2 border-y border-slate-200 bg-slate-50">
                  <div className="flex items-center space-x-1.5">
                    <div className="h-2.5 w-2.5 rounded bg-slate-50 border border-slate-250" />
                    <span>Livre</span>
                  </div>
                  <div className="flex items-center space-x-1.5">
                    <div className="h-2.5 w-2.5 rounded bg-amber-500/10 border border-amber-300 text-amber-700" />
                    <span>Reservado</span>
                  </div>
                  <div className="flex items-center space-x-1.5">
                    <div className="h-2.5 w-2.5 rounded bg-red-500/10 border border-red-300 text-red-650 flex items-center justify-center text-[7px]" />
                    <span>Pago</span>
                  </div>
                  <div className="flex items-center space-x-1.5">
                    <div className="h-2.5 w-2.5 rounded bg-blue-500 border border-blue-600 shadow-sm" />
                    <span>Selecionado</span>
                  </div>
                </div>

                {/* Multi-ticket grid with restricted heights */}
                <div className="max-h-[145px] sm:max-h-[190px] overflow-y-auto pr-1">
                  <div className="grid grid-cols-6 sm:grid-cols-10 gap-1 text-center font-mono text-[11px]">
                    {Array.from({ length: gridRange.end - gridRange.start + 1 }).map((_, idx) => {
                      const num = gridRange.start + idx;
                      const ticketState = reservedTickets[num];
                      const isSelected = selectedNumbers.includes(num);

                      let cellBg = "bg-white border-slate-200 text-slate-700 hover:bg-blue-52 hover:border-blue-400 hover:text-blue-600 hover:shadow-xs";
                      let indicator = null;

                      if (ticketState) {
                        if (ticketState.status === "confirmed") {
                           cellBg = "bg-red-500/5 border-red-105 text-red-400/50 cursor-not-allowed opacity-[0.4] font-normal";
                           indicator = "X";
                        } else if (ticketState.status === "pending") {
                           cellBg = "bg-amber-500/5 border-amber-105 text-amber-500/70 font-bold cursor-not-allowed opacity-[0.4]";
                        }
                      } else if (isSelected) {
                        cellBg = "bg-blue-500 border-blue-600 text-white font-black shadow-[0_2px_12px_rgba(37,99,235,0.3)] scale-[1.03] transition-all";
                      }

                      const valLength = raffle.totalNumbers > 100 ? 3 : 2;

                      return (
                        <button
                          key={num}
                          disabled={!!ticketState}
                          onClick={() => toggleNumberSelection(num)}
                          className={`relative py-1.5 rounded border flex flex-col items-center justify-center font-bold tracking-tighter cursor-pointer select-none transition ${cellBg}`}
                        >
                          <span>{num.toString().padStart(valLength, "0")}</span>
                          {indicator && (
                            <span className="absolute bottom-0 text-[7px] font-black text-red-500">{indicator}</span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Selection count & payment call to action */}
                <div className="pt-3 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
                  <div className="text-center sm:text-left">
                    <p className="text-[10px] text-slate-500 uppercase tracking-wider font-extrabold leading-none">Coletados:</p>
                    <p className="text-sm sm:text-base font-black font-sans mt-0.5 text-slate-800">
                      {selectedNumbers.length} {selectedNumbers.length === 1 ? "Número" : "Números"}{" "}
                      <span className="text-blue-600 ml-1 font-black">
                        (R$ {totalPrice.toLocaleString("pt-BR", { minimumFractionDigits: 2 })})
                      </span>
                    </p>
                  </div>
                  <button
                    onClick={startPaymentProcess}
                    disabled={selectedNumbers.length === 0}
                    className="w-full sm:w-auto relative flex items-center justify-center space-x-1.5 px-6 py-3 rounded-xl bg-gradient-to-r from-blue-500 to-indigo-600 disabled:from-slate-200 disabled:to-slate-300 disabled:text-slate-400 text-white text-xs font-black cursor-pointer shadow-[0_3px_12px_rgba(37,99,235,0.15)] disabled:opacity-40 disabled:cursor-not-allowed hover:scale-[1.01] transition duration-150"
                  >
                    <span>Prosseguir para Pagamento</span>
                    <ArrowRight size={14} />
                  </button>
                </div>
              </>
            ) : (
              /* Step 2: Payment and PIX details */
              <div className="space-y-4">
                <div className="bg-slate-50 p-3 rounded-2xl border border-slate-205 text-center text-xs leading-normal text-slate-700">
                  Sorteio: <span className="font-extrabold text-slate-900">{raffle.title}</span> • Adquirindo <span className="font-extrabold text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded border border-blue-200/50">({selectedNumbers.length} cotas)</span>:{" "}
                  <span className="font-extrabold text-slate-850">({selectedNumbers.join(", ")})</span>.
                  <p className="text-base sm:text-lg font-black text-blue-600 mt-2 leading-none">
                    Total a pagar: R$ {totalPrice.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-12 gap-4 items-center">
                  {/* Real PIX QR Code representation generated on the fly */}
                  <div className="sm:col-span-5 bg-slate-50 p-3 rounded-2xl flex flex-col items-center justify-center border border-slate-205">
                    <div className="relative p-1.5 bg-white border border-slate-200 rounded-xl shadow-xs flex items-center justify-center">
                      <img 
                        src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(generatePixCopiaECola(pixKey, pixName, totalPrice))}`}
                        alt="Pix QR Code Dinâmico"
                        className="w-[120px] h-[120px] sm:w-[130px] sm:h-[130px] object-contain rounded"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    <span className="text-[8px] font-black text-blue-600 uppercase mt-2.5 select-none tracking-wide text-center leading-tight">
                      Aperte e salve o QR Code acima
                    </span>
                  </div>

                  {/* PIX Key copy & description */}
                  <div className="sm:col-span-7 space-y-3 text-left">
                    <div>
                      <h4 className="text-[10px] font-extrabold text-slate-500 uppercase tracking-widest">Beneficiário</h4>
                      <p className="text-xs font-extrabold truncate text-slate-800 leading-tight mt-0.5">{pixName}</p>
                    </div>

                    <div>
                      <h4 className="text-[10px] font-extrabold text-slate-500 uppercase tracking-widest">Pix Copia e Cola</h4>
                      <div className="flex items-center space-x-1.5 mt-1">
                        <input
                          type="text"
                          readOnly
                          value={generatePixCopiaECola(pixKey, pixName, totalPrice)}
                          className="flex-grow bg-slate-100 border border-slate-200 rounded-xl text-[10px] p-2.5 font-mono font-black tracking-tight text-blue-605 focus:outline-none"
                        />
                        <button
                          onClick={copyPixKey}
                          className={`p-2.5 rounded-xl border transition cursor-pointer flex-shrink-0 ${
                            copied
                              ? "bg-green-600 border-green-600 text-white"
                              : "bg-slate-50 border-slate-200 text-slate-550 hover:text-blue-600"
                          }`}
                          title="Copiar Código Copia e Cola"
                        >
                          {copied ? <Check size={14} className="stroke-[3]" /> : <Copy size={14} />}
                        </button>
                      </div>
                      {copied && <span className="text-[9px] text-green-600 mt-1 block font-bold leading-none">✔ Código PIX copiado com sucesso!</span>}
                    </div>

                    {/* Receipt Submission Area */}
                    <div>
                      <h4 className="text-[10px] font-extrabold text-slate-500 uppercase tracking-widest mb-1 flex items-center gap-1">
                        <Upload size={11} className="text-blue-600" /> Envie o Comprovante PIX
                      </h4>
                      <div
                        onDragOver={(e) => e.preventDefault()}
                        onDrop={handleReceiptDrop}
                        onClick={() => fileInputRef.current?.click()}
                        className="border border-dashed border-slate-300 hover:border-blue-400 rounded-xl bg-slate-50 p-3 flex flex-col items-center justify-center cursor-pointer transition text-center hover:bg-slate-100"
                      >
                        <input
                          type="file"
                          ref={fileInputRef}
                          accept="image/*"
                          onChange={handleReceiptUpload}
                          className="hidden"
                        />

                        {receiptBase64 ? (
                          <div className="flex items-center space-x-2 text-[11px] text-blue-600 leading-none">
                            <div className="h-8 w-8 bg-blue-100 border border-blue-200 rounded overflow-hidden flex items-center justify-center">
                              <img src={receiptBase64} alt="Receipt Preview" className="h-full w-full object-cover" />
                            </div>
                            <span className="font-extrabold text-blue-600">Recibo carregado! Deseja trocar?</span>
                          </div>
                        ) : (
                          <div className="text-[11px] text-slate-500 leading-tight">
                            <span className="font-extrabold text-blue-600">Clique ou arraste o comprovante aqui</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Confirm & Go actions */}
                <div className="pt-4 border-t border-slate-200 flex items-center justify-between gap-3">
                  <button
                    onClick={() => setStep("select")}
                    className="px-6 py-3 border border-slate-205 bg-slate-50 hover:bg-slate-100 text-slate-600 rounded-xl font-extrabold text-xs uppercase hover:text-slate-800 transition duration-150 cursor-pointer text-center whitespace-nowrap"
                  >
                    Voltar
                  </button>
                  <button
                    onClick={handleConfirmReservation}
                    disabled={uploadingReceipt || !receiptBase64}
                    className="flex-grow relative flex items-center justify-center space-x-2 bg-gradient-to-r from-blue-500 to-indigo-600 disabled:from-slate-200 disabled:to-slate-300 disabled:text-slate-400 text-white font-black py-3 px-6 rounded-xl shadow-[0_3px_12px_rgba(37,99,235,0.3)] hover:scale-[1.01] text-xs uppercase transition duration-150 cursor-pointer"
                  >
                    {uploadingReceipt ? (
                      <Loader2 className="animate-spin text-white" size={14} />
                    ) : (
                      <>
                        <Check size={14} className="stroke-[3]" />
                        <span>Confirmar Pagamento</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </motion.div>
    </div>
  );
}
