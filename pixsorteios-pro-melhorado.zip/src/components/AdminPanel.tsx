import React, { useState, useEffect, useRef } from "react";
import { collection, onSnapshot, setDoc, doc, updateDoc, deleteDoc, getDoc, getDocs, query, where } from "firebase/firestore";
import { db, handleFirestoreError, OperationType } from "../firebase";
import { Raffle, Ticket, UserProfile, PixConfig, Winner, AffiliateProfile } from "../types";
import {
  Plus, Trash, Check, X, Upload, Coins, Image, Users, ClipboardCheck, Loader2,
  Award, Clock, Copy, Trophy, Search, Shuffle, RefreshCw, SlidersHorizontal,
  ShieldCheck, Pencil, Pause, Play, UserPlus, AlertCircle, Link, ExternalLink,
  ChevronDown, ChevronUp, Eye, EyeOff, Settings, BarChart2, LogOut, Phone,
  Key, Hash, CheckCircle, XCircle, Banknote, QrCode, ToggleLeft, ToggleRight, ShieldAlert
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { compressImage } from "../utils";

type AdminTab = "dashboard" | "afiliados" | "sorteios_adm" | "transacoes" | "ganhadores" | "config";

interface AdminPanelProps {
  onClose: () => void;
  profile: UserProfile;
}

const formatCPF = (val: string) => {
  const n = val.replace(/\D/g, "");
  if (n.length <= 3) return n;
  if (n.length <= 6) return `${n.slice(0, 3)}.${n.slice(3)}`;
  if (n.length <= 9) return `${n.slice(0, 3)}.${n.slice(3, 6)}.${n.slice(6)}`;
  return `${n.slice(0, 3)}.${n.slice(3, 6)}.${n.slice(6, 9)}-${n.slice(9, 11)}`;
};

const formatPhone = (val: string) => {
  let c = val.replace(/\D/g, "");
  if (c.length > 11) c = c.slice(0, 11);
  if (c.length > 10) return c.replace(/^(\d{2})(\d{5})(\d{4})$/, "($1) $2-$3");
  if (c.length > 6) return c.replace(/^(\d{2})(\d{4})(\d{0,4})$/, "($1) $2-$3");
  if (c.length > 2) return c.replace(/^(\d{2})(\d{1,4})$/, "($1) $2");
  return c.length > 0 ? `(${c}` : c;
};

const fmtDate = (iso: string) => {
  const d = new Date(iso);
  if (isNaN(d.getTime())) return "—";
  return d.toLocaleDateString("pt-BR") + " " + d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
};

export default function AdminPanel({ onClose, profile }: AdminPanelProps) {
  const [tab, setTab] = useState<AdminTab>("dashboard");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [loading, setLoading] = useState(false);

  // Data
  const [raffles, setRaffles] = useState<Raffle[]>([]);
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [affiliates, setAffiliates] = useState<any[]>([]);
  const [winners, setWinners] = useState<Winner[]>([]);
  const [users, setUsers] = useState<UserProfile[]>([]);

  // Config
  const [pixKey, setPixKey] = useState("");
  const [pixReceiver, setPixReceiver] = useState("");
  const [termsText, setTermsText] = useState("");

  // Affiliate form
  const [affCpf, setAffCpf] = useState("");
  const [affName, setAffName] = useState("");
  const [affPhone, setAffPhone] = useState("");
  const [affPass, setAffPass] = useState("");
  const [affMaxRaffles, setAffMaxRaffles] = useState(1);
  const [affPixKey, setAffPixKey] = useState("");
  const [affPixReceiver, setAffPixReceiver] = useState("");
  const [editingAff, setEditingAff] = useState<any | null>(null);
  const [showAffForm, setShowAffForm] = useState(false);
  const [showPassMap, setShowPassMap] = useState<Record<string, boolean>>({});
  const [affSearch, setAffSearch] = useState("");
  const [expandedAff, setExpandedAff] = useState<string | null>(null);

  // Raffle management
  const [managingRaffle, setManagingRaffle] = useState<Raffle | null>(null);

  // Draw
  const [drawingRaffle, setDrawingRaffle] = useState<Raffle | null>(null);
  const [drawMethod, setDrawMethod] = useState<"system" | "manual">("system");
  const [manualNum, setManualNum] = useState<number | "">("");
  const [drawnTicket, setDrawnTicket] = useState<Ticket | null>(null);
  const [drawnPhoto, setDrawnPhoto] = useState("");
  const [drawError, setDrawError] = useState("");
  const [drawSuccess, setDrawSuccess] = useState("");
  const [isSpinning, setIsSpinning] = useState(false);
  const [spinNum, setSpinNum] = useState(0);
  const fileDrawRef = useRef<HTMLInputElement>(null);

  // Raffle create form (admin)
  const [rTitle, setRTitle] = useState("");
  const [rDesc, setRDesc] = useState("");
  const [rAward, setRAward] = useState("");
  const [rPrice, setRPrice] = useState(10);
  const [rTotal, setRTotal] = useState(100);
  const [rImage, setRImage] = useState("");
  const [rCreatorUid, setRCreatorUid] = useState("");
  const [showCreateRaffle, setShowCreateRaffle] = useState(false);
  const fileRaffleRef = useRef<HTMLInputElement>(null);

  // Banners
  const [banners, setBanners] = useState<any[]>([]);
  const [newBannerImg, setNewBannerImg] = useState("");
  const [newBannerLink, setNewBannerLink] = useState("");
  const fileBannerRef = useRef<HTMLInputElement>(null);

  const [zoomReceipt, setZoomReceipt] = useState<string | null>(null);
  const [confirmDialog, setConfirmDialog] = useState<{ title: string; description: string; onConfirm: () => void } | null>(null);
  const [searchTrans, setSearchTrans] = useState("");
  const [copiedLink, setCopiedLink] = useState<string | null>(null);

  // ── Realtime listeners ──────────────────────────────────────────
  useEffect(() => {
    const unsubs: (() => void)[] = [];

    unsubs.push(onSnapshot(collection(db, "raffles"), snap => {
      const list: Raffle[] = [];
      snap.forEach(d => list.push({ id: d.id, ...d.data() } as Raffle));
      setRaffles(list.sort((a, b) => b.createdAt.localeCompare(a.createdAt)));
    }, err => console.warn("raffles sub:", err)));

    unsubs.push(onSnapshot(collection(db, "tickets"), snap => {
      const list: Ticket[] = [];
      snap.forEach(d => list.push({ id: d.id, ...d.data() } as Ticket));
      setTickets(list.sort((a, b) => b.reservedAt.localeCompare(a.reservedAt)));
    }, err => console.warn("tickets sub:", err)));

    unsubs.push(onSnapshot(collection(db, "affiliates"), snap => {
      const list: any[] = [];
      snap.forEach(d => list.push({ cpf: d.id, ...d.data() }));
      setAffiliates(list.sort((a, b) => b.createdAt.localeCompare(a.createdAt)));
    }, err => console.warn("affiliates sub:", err)));

    unsubs.push(onSnapshot(collection(db, "winners"), snap => {
      const list: Winner[] = [];
      snap.forEach(d => list.push({ id: d.id, ...d.data() } as Winner));
      setWinners(list.sort((a, b) => b.announcedAt.localeCompare(a.announcedAt)));
    }, err => console.warn("winners sub:", err)));

    unsubs.push(onSnapshot(collection(db, "users"), snap => {
      const list: UserProfile[] = [];
      snap.forEach(d => list.push({ uid: d.id, ...d.data() } as UserProfile));
      setUsers(list);
    }, err => console.warn("users sub:", err)));

    unsubs.push(onSnapshot(collection(db, "banners"), snap => {
      const list: any[] = [];
      snap.forEach(d => list.push({ id: d.id, ...d.data() }));
      setBanners(list);
    }, err => console.warn("banners sub:", err)));

    unsubs.push(onSnapshot(doc(db, "config", "pix"), snap => {
      if (snap.exists()) { setPixKey(snap.data().pixKey || ""); setPixReceiver(snap.data().pixReceiver || ""); }
    }, err => console.warn("pix config:", err)));

    unsubs.push(onSnapshot(doc(db, "config", "terms"), snap => {
      if (snap.exists()) setTermsText(snap.data().content || "");
    }, err => console.warn("terms:", err)));

    return () => unsubs.forEach(u => u());
  }, []);

  const clearMsgs = () => { setError(""); setSuccess(""); };

  // ── Affiliate CRUD ──────────────────────────────────────────────
  const handleSaveAffiliate = async (e: React.FormEvent) => {
    e.preventDefault();
    clearMsgs();
    const cleanCpf = affCpf.replace(/\D/g, "");
    if (cleanCpf.length !== 11) { setError("CPF inválido."); return; }
    if (!affPass.trim()) { setError("Defina uma senha."); return; }
    if (!affName.trim()) { setError("Informe o nome do afiliado."); return; }

    setLoading(true);
    try {
      const affData: AffiliateProfile = {
        cpf: cleanCpf,
        name: affName.trim(),
        password: affPass.trim(),
        maxRaffles: Number(affMaxRaffles) || 1,
        status: editingAff ? (editingAff.status || "active") : "active",
        createdAt: editingAff ? editingAff.createdAt : new Date().toISOString(),
        phone: affPhone.trim(),
        pixKey: affPixKey.trim(),
        pixReceiver: affPixReceiver.trim(),
      };

      await setDoc(doc(db, "affiliates", cleanCpf), affData);

      // Sync user doc
      const userRef = doc(db, "users", cleanCpf);
      const userSnap = await getDoc(userRef);
      const userPayload = {
        isCreator: true,
        password: affPass.trim(),
        maxRaffles: Number(affMaxRaffles) || 1,
        name: affName.trim(),
        phone: affPhone.trim() || "",
        status: affData.status,
      };
      if (userSnap.exists()) {
        await updateDoc(userRef, userPayload);
      } else {
        await setDoc(userRef, {
          uid: cleanCpf,
          cpf: cleanCpf,
          name: affName.trim(),
          phone: affPhone.trim() || "",
          birthDate: "1995-01-01",
          photo: "",
          email: `${cleanCpf}@pixsorteios.com`,
          isAdmin: false,
          isCreator: true,
          password: affPass.trim(),
          maxRaffles: Number(affMaxRaffles) || 1,
          status: "active",
          createdAt: new Date().toISOString(),
        });
      }

      setSuccess(editingAff ? `Afiliado ${affName} atualizado!` : `Afiliado ${affName} cadastrado com sucesso!`);
      resetAffForm();
    } catch (err: any) {
      setError("Erro: " + err.message);
    } finally { setLoading(false); }
  };

  const resetAffForm = () => {
    setEditingAff(null); setAffCpf(""); setAffName(""); setAffPhone(""); setAffPass("");
    setAffMaxRaffles(1); setAffPixKey(""); setAffPixReceiver(""); setShowAffForm(false);
  };

  const handleEditAffiliate = (aff: any) => {
    setEditingAff(aff);
    setAffCpf(formatCPF(aff.cpf));
    setAffName(aff.name || "");
    setAffPhone(aff.phone || "");
    setAffPass(aff.password || "");
    setAffMaxRaffles(aff.maxRaffles || 1);
    setAffPixKey(aff.pixKey || "");
    setAffPixReceiver(aff.pixReceiver || "");
    setShowAffForm(true);
    setExpandedAff(null);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleToggleAffStatus = async (aff: any) => {
    const next = aff.status === "paused" ? "active" : "paused";
    setLoading(true); clearMsgs();
    try {
      await updateDoc(doc(db, "affiliates", aff.cpf), { status: next });
      await updateDoc(doc(db, "users", aff.cpf), { status: next }).catch(() => {});
      setSuccess(`Afiliado ${aff.name} ${next === "active" ? "reativado" : "suspenso"}.`);
    } catch (err: any) { setError("Erro: " + err.message); }
    finally { setLoading(false); }
  };

  const handleDeleteAffiliate = (aff: any) => {
    const hasActive = raffles.some(r => r.creatorUid === aff.cpf && r.status === "active");
    if (hasActive) { setError("Afiliado possui sorteios ativos. Finalize-os antes."); return; }
    setConfirmDialog({
      title: "Remover Afiliado",
      description: `Remover ${aff.name} (${formatCPF(aff.cpf)})? Ele perderá acesso à plataforma.`,
      onConfirm: async () => {
        setLoading(true); clearMsgs();
        try {
          await deleteDoc(doc(db, "affiliates", aff.cpf));
          await updateDoc(doc(db, "users", aff.cpf), { isCreator: false, status: "paused" }).catch(() => {});
          setSuccess("Afiliado removido.");
        } catch (err: any) { setError("Erro: " + err.message); }
        finally { setLoading(false); }
      }
    });
  };

  const getAffiliateLink = (aff: any) => {
    return `${window.location.origin}${window.location.pathname}?c=${aff.cpf}`;
  };

  const copyAffiliateLink = (aff: any) => {
    const link = getAffiliateLink(aff);
    navigator.clipboard.writeText(link).then(() => {
      setCopiedLink(aff.cpf);
      setTimeout(() => setCopiedLink(null), 2000);
    });
  };

  // ── Create Raffle (Admin) ───────────────────────────────────────
  const parseImg = async (e: React.ChangeEvent<HTMLInputElement>, cb: (s: string) => void) => {
    const file = e.target.files?.[0]; if (!file) return;
    try { cb(await compressImage(file, 800, 0.7)); } catch (err: any) { setError("Erro ao carregar imagem."); }
  };

  const handleCreateRaffle = async (e: React.FormEvent) => {
    e.preventDefault(); clearMsgs();
    if (!rTitle.trim() || !rAward.trim() || !rImage) { setError("Preencha título, prêmio e imagem."); return; }
    setLoading(true);
    const id = "raffle_" + Math.random().toString(36).substring(2, 11);
    const creator = rCreatorUid ? affiliates.find(a => a.cpf === rCreatorUid) : null;

    // Use creator's pix if available
    const rafflePixKey = creator?.pixKey || pixKey;
    const rafflePixReceiver = creator?.pixReceiver || pixReceiver;

    try {
      const raffle: Raffle = {
        id, title: rTitle.trim(), description: rDesc.trim(), image: rImage,
        pricePerTicket: Number(rPrice), totalNumbers: Number(rTotal),
        status: "active", award: rAward.trim(), createdAt: new Date().toISOString(),
        creatorUid: rCreatorUid || "admicarlos",
        creatorName: creator ? creator.name : profile.name,
        pixKey: rafflePixKey,
        pixReceiver: rafflePixReceiver,
      };
      await setDoc(doc(db, "raffles", id), raffle);
      setSuccess("Sorteio criado!");
      setRTitle(""); setRDesc(""); setRAward(""); setRPrice(10); setRImage(""); setRCreatorUid(""); setShowCreateRaffle(false);
    } catch (err: any) { setError("Erro: " + err.message); }
    finally { setLoading(false); }
  };

  const handleDeleteRaffle = (raffle: Raffle) => {
    setConfirmDialog({
      title: "Excluir Sorteio",
      description: `Excluir o sorteio "${raffle.title}"? Todos os bilhetes serão removidos.`,
      onConfirm: async () => {
        setLoading(true); clearMsgs();
        try {
          // Delete all tickets
          const q = query(collection(db, "tickets"), where("raffleId", "==", raffle.id));
          const snap = await getDocs(q);
          for (const d of snap.docs) await deleteDoc(d.ref);
          await deleteDoc(doc(db, "raffles", raffle.id));
          setSuccess("Sorteio e bilhetes removidos.");
        } catch (err: any) { setError("Erro: " + err.message); }
        finally { setLoading(false); }
      }
    });
  };

  // ── Approve / Reject Tickets ────────────────────────────────────
  const approveTickets = async (ts: Ticket[]) => {
    clearMsgs(); setLoading(true);
    try {
      for (const t of ts) {
        await updateDoc(doc(db, "tickets", t.id), { status: "confirmed", confirmedAt: new Date().toISOString() });
      }
      setSuccess(`${ts.length} bilhete(s) aprovado(s)!`);
    } catch (err: any) { setError("Erro ao aprovar: " + err.message); }
    finally { setLoading(false); }
  };

  const declineTickets = async (ts: Ticket[]) => {
    clearMsgs(); setLoading(true);
    try {
      for (const t of ts) await deleteDoc(doc(db, "tickets", t.id));
      setSuccess(`${ts.length} reserva(s) recusada(s).`);
    } catch (err: any) { setError("Erro: " + err.message); }
    finally { setLoading(false); }
  };

  // ── Draw ────────────────────────────────────────────────────────
  const handleDraw = async () => {
    if (!drawingRaffle) return;
    setDrawError(""); setDrawSuccess("");
    const confirmed = tickets.filter(t => t.raffleId === drawingRaffle.id && t.status === "confirmed");
    if (confirmed.length === 0) { setDrawError("Nenhum bilhete confirmado para sortear."); return; }

    if (drawMethod === "system") {
      setIsSpinning(true);
      let count = 0;
      const interval = setInterval(() => {
        setSpinNum(confirmed[Math.floor(Math.random() * confirmed.length)].ticketNumber);
        count++;
        if (count > 25) {
          clearInterval(interval);
          const winner = confirmed[Math.floor(Math.random() * confirmed.length)];
          setDrawnTicket(winner);
          setSpinNum(winner.ticketNumber);
          setIsSpinning(false);
          setDrawSuccess(`🎉 Cota #${winner.ticketNumber.toString().padStart(3, "0")} sorteada!`);
        }
      }, 80);
    } else {
      const numVal = Number(manualNum);
      const found = confirmed.find(t => t.ticketNumber === numVal);
      if (!found) { setDrawError(`Número ${manualNum} não encontrado entre os confirmados.`); return; }
      setDrawnTicket(found);
      setDrawSuccess(`Cota #${found.ticketNumber.toString().padStart(3, "0")} selecionada.`);
    }
  };

  const handlePublishWinner = async () => {
    if (!drawingRaffle || !drawnTicket) return;
    try {
      const wid = "winner_" + Math.random().toString(36).substring(2, 11);
      await setDoc(doc(db, "winners", wid), {
        id: wid, raffleId: drawingRaffle.id, raffleTitle: drawingRaffle.title,
        userName: drawnTicket.userName, userCpf: drawnTicket.userCpf,
        winningNumber: drawnTicket.ticketNumber, award: drawingRaffle.award,
        prizePhoto: drawnPhoto || drawingRaffle.image,
        announcedAt: new Date().toISOString()
      });
      await updateDoc(doc(db, "raffles", drawingRaffle.id), { status: "finished" });
      setSuccess(`Ganhador publicado! Sorteio "${drawingRaffle.title}" encerrado.`);
      setDrawingRaffle(null); setDrawnTicket(null); setDrawnPhoto("");
    } catch (err: any) { setDrawError("Erro: " + err.message); }
  };

  // ── Banners ─────────────────────────────────────────────────────
  const handleAddBanner = async () => {
    if (!newBannerImg) { setError("Faça upload de uma imagem."); return; }
    setLoading(true); clearMsgs();
    try {
      const bid = "banner_" + Math.random().toString(36).substring(2, 9);
      await setDoc(doc(db, "banners", bid), {
        id: bid, image: newBannerImg, link: newBannerLink || "#", active: true, updatedAt: new Date().toISOString()
      });
      setNewBannerImg(""); setNewBannerLink("");
      setSuccess("Banner adicionado!");
    } catch (err: any) { setError("Erro: " + err.message); }
    finally { setLoading(false); }
  };

  const handleToggleBanner = async (b: any) => {
    try { await updateDoc(doc(db, "banners", b.id), { active: !b.active }); } catch (err: any) { setError("Erro: " + err.message); }
  };

  const handleDeleteBanner = async (bid: string) => {
    try { await deleteDoc(doc(db, "banners", bid)); setSuccess("Banner removido."); } catch (err: any) { setError("Erro: " + err.message); }
  };

  // ── Config Save ──────────────────────────────────────────────────
  const handleSaveConfig = async () => {
    clearMsgs(); setLoading(true);
    try {
      await setDoc(doc(db, "config", "pix"), { pixKey: pixKey.trim(), pixReceiver: pixReceiver.trim() });
      await setDoc(doc(db, "config", "terms"), { content: termsText });
      setSuccess("Configurações salvas!");
    } catch (err: any) { setError("Erro: " + err.message); }
    finally { setLoading(false); }
  };

  // ── Computed ────────────────────────────────────────────────────
  const pending = tickets.filter(t => t.status === "pending");
  const confirmed = tickets.filter(t => t.status === "confirmed");

  const groupedPending = React.useMemo(() => {
    const map = new Map<string, { key: string; userName: string; userCpf: string; userPhone: string; raffleTitle: string; raffleId: string; tickets: Ticket[]; receipts: string[] }>();
    pending.forEach(t => {
      const raffle = raffles.find(r => r.id === t.raffleId);
      const key = `${t.userCpf}_${t.raffleId}`;
      if (!map.has(key)) map.set(key, { key, userName: t.userName, userCpf: t.userCpf, userPhone: t.userPhone, raffleTitle: raffle?.title || t.raffleId, raffleId: t.raffleId, tickets: [], receipts: [] });
      const g = map.get(key)!;
      g.tickets.push(t);
      if (t.paymentReceipt) g.receipts.push(t.paymentReceipt);
    });
    return Array.from(map.values());
  }, [pending, raffles]);

  const filteredPending = searchTrans
    ? groupedPending.filter(g => g.userName.toLowerCase().includes(searchTrans.toLowerCase()) || g.userCpf.includes(searchTrans) || g.userPhone.includes(searchTrans))
    : groupedPending;

  const filteredAffiliates = affSearch
    ? affiliates.filter(a => a.name?.toLowerCase().includes(affSearch.toLowerCase()) || a.cpf?.includes(affSearch.replace(/\D/g, "")))
    : affiliates;

  const totalRevenue = confirmed.reduce((acc, t) => {
    const r = raffles.find(rf => rf.id === t.raffleId);
    return acc + (r?.pricePerTicket || 0);
  }, 0);

  // ── UI helpers ──────────────────────────────────────────────────
  const tabs: { id: AdminTab; label: string; icon: React.ReactNode; badge?: number }[] = [
    { id: "dashboard", label: "Dashboard", icon: <BarChart2 size={14} /> },
    { id: "afiliados", label: "Afiliados", icon: <Users size={14} />, badge: affiliates.length },
    { id: "sorteios_adm", label: "Sorteios", icon: <Trophy size={14} />, badge: raffles.filter(r => r.status === "active").length },
    { id: "transacoes", label: "Transações", icon: <ClipboardCheck size={14} />, badge: pending.length || undefined },
    { id: "ganhadores", label: "Ganhadores", icon: <Award size={14} /> },
    { id: "config", label: "Config", icon: <Settings size={14} /> },
  ];

  const inputCls = "w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2.5 text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-600 focus:border-blue-600";
  const labelCls = "block text-[9px] uppercase font-black text-slate-500 mb-1";

  return (
    <div className="fixed inset-0 z-50 bg-slate-100 flex flex-col overflow-hidden">
      {/* Top bar */}
      <div className="bg-white border-b border-slate-200 px-4 py-3 flex items-center justify-between shadow-sm flex-shrink-0">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-blue-600 rounded-xl">
            <ShieldCheck size={18} className="text-white" />
          </div>
          <div>
            <h1 className="font-black text-sm text-slate-800 uppercase tracking-tight">Painel Admin Master</h1>
            <p className="text-[10px] text-slate-500 font-bold">PIX Sorteios — {profile.name}</p>
          </div>
        </div>
        <button onClick={onClose} className="flex items-center gap-1.5 text-xs font-bold text-slate-500 hover:text-red-600 transition cursor-pointer px-3 py-2 rounded-lg hover:bg-red-50">
          <LogOut size={14} /> Sair
        </button>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <div className="w-48 bg-white border-r border-slate-200 flex flex-col py-3 gap-0.5 flex-shrink-0 hidden md:flex">
          {tabs.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`flex items-center gap-2.5 px-4 py-2.5 text-[11px] font-black uppercase tracking-wider transition cursor-pointer relative ${tab === t.id ? "bg-blue-600 text-white" : "text-slate-500 hover:bg-slate-50 hover:text-slate-800"}`}>
              {t.icon}
              <span className="flex-1 text-left">{t.label}</span>
              {t.badge !== undefined && t.badge > 0 && (
                <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-black ${tab === t.id ? "bg-white/20 text-white" : "bg-red-500 text-white"}`}>
                  {t.badge}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Mobile tab bar */}
        <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 flex z-10">
          {tabs.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`flex-1 flex flex-col items-center py-2 gap-0.5 text-[8px] font-black uppercase relative transition cursor-pointer ${tab === t.id ? "text-blue-600" : "text-slate-400"}`}>
              {t.icon}
              <span>{t.label}</span>
              {t.badge !== undefined && t.badge > 0 && (
                <span className="absolute top-1 right-2 bg-red-500 text-white text-[7px] px-1 rounded-full">{t.badge}</span>
              )}
            </button>
          ))}
        </div>

        {/* Main content */}
        <div className="flex-1 overflow-y-auto p-4 md:p-6 pb-20 md:pb-6">
          {error && <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-xl text-xs font-bold text-red-700 flex gap-2"><AlertCircle size={14} className="shrink-0 mt-0.5" />{error}</div>}
          {success && <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs font-bold text-emerald-700 flex gap-2"><CheckCircle size={14} className="shrink-0 mt-0.5" />{success}</div>}

          {/* ── DASHBOARD ─────────────────────────────────────────── */}
          {tab === "dashboard" && (
            <div className="space-y-6">
              <h2 className="text-xl font-black text-slate-800">Dashboard</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
                  { label: "Afiliados Ativos", value: affiliates.filter(a => a.status !== "paused").length, color: "blue", icon: <Users size={20} /> },
                  { label: "Sorteios Ativos", value: raffles.filter(r => r.status === "active").length, color: "emerald", icon: <Trophy size={20} /> },
                  { label: "Pagamentos Pend.", value: pending.length, color: "amber", icon: <Clock size={20} /> },
                  { label: "Receita Total", value: `R$ ${totalRevenue.toFixed(0)}`, color: "violet", icon: <Coins size={20} /> },
                ].map(({ label, value, color, icon }) => (
                  <div key={label} className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
                    <div className={`text-${color}-600 mb-2`}>{icon}</div>
                    <p className="text-2xl font-black text-slate-800">{value}</p>
                    <p className="text-[10px] text-slate-500 font-bold uppercase mt-0.5">{label}</p>
                  </div>
                ))}
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                {/* Recent affiliates */}
                <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5">
                  <h3 className="font-black text-sm text-slate-800 uppercase tracking-wider mb-3 flex items-center justify-between">
                    Últimos Afiliados
                    <button onClick={() => setTab("afiliados")} className="text-[10px] text-blue-600 font-black hover:underline cursor-pointer">Ver todos →</button>
                  </h3>
                  <div className="space-y-2">
                    {affiliates.slice(0, 5).map(aff => (
                      <div key={aff.cpf} className="flex items-center justify-between py-2 border-b border-slate-50 last:border-0">
                        <div>
                          <p className="text-xs font-extrabold text-slate-800">{aff.name}</p>
                          <p className="text-[10px] text-slate-400 font-mono">{formatCPF(aff.cpf)}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-[9px] text-slate-400">{raffles.filter(r => r.creatorUid === aff.cpf && r.status === "active").length} sorteio(s)</span>
                          <span className={`text-[9px] px-2 py-0.5 rounded-full font-black ${aff.status === "paused" ? "bg-red-100 text-red-700" : "bg-emerald-100 text-emerald-700"}`}>
                            {aff.status === "paused" ? "Suspenso" : "Ativo"}
                          </span>
                        </div>
                      </div>
                    ))}
                    {affiliates.length === 0 && <p className="text-xs text-slate-400 text-center py-4">Nenhum afiliado cadastrado.</p>}
                  </div>
                </div>

                {/* Pending payments */}
                <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5">
                  <h3 className="font-black text-sm text-slate-800 uppercase tracking-wider mb-3 flex items-center justify-between">
                    Pagamentos Pendentes
                    <button onClick={() => setTab("transacoes")} className="text-[10px] text-blue-600 font-black hover:underline cursor-pointer">Analisar →</button>
                  </h3>
                  {groupedPending.length === 0 ? (
                    <p className="text-xs text-slate-400 text-center py-4">Nenhum pagamento pendente.</p>
                  ) : (
                    <div className="space-y-2">
                      {groupedPending.slice(0, 5).map(g => (
                        <div key={g.key} className="flex items-center justify-between py-2 border-b border-slate-50 last:border-0">
                          <div>
                            <p className="text-xs font-extrabold text-slate-800">{g.userName}</p>
                            <p className="text-[10px] text-slate-400">{g.raffleTitle} · {g.tickets.length} cota(s)</p>
                          </div>
                          <span className="text-[9px] px-2 py-0.5 rounded-full bg-amber-100 text-amber-700 font-black">Pendente</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* ── AFILIADOS ─────────────────────────────────────────── */}
          {tab === "afiliados" && (
            <div className="space-y-5">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-black text-slate-800">Gerenciar Afiliados</h2>
                <button onClick={() => { resetAffForm(); setShowAffForm(true); }}
                  className="flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl text-xs font-black uppercase transition cursor-pointer shadow-sm">
                  <Plus size={14} /> Novo Afiliado
                </button>
              </div>

              {/* Form */}
              <AnimatePresence>
                {showAffForm && (
                  <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}
                    className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-black text-sm uppercase text-blue-700 flex items-center gap-2">
                        <UserPlus size={16} />{editingAff ? "Editar Afiliado" : "Cadastrar Novo Afiliado"}
                      </h3>
                      <button onClick={resetAffForm} className="text-slate-400 hover:text-slate-600 cursor-pointer"><X size={16} /></button>
                    </div>
                    <form onSubmit={handleSaveAffiliate} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className={labelCls}>CPF do Afiliado</label>
                        <input type="text" required disabled={!!editingAff} placeholder="000.000.000-00"
                          value={affCpf} onChange={e => setAffCpf(formatCPF(e.target.value))} maxLength={14}
                          className={inputCls + (editingAff ? " opacity-60 cursor-not-allowed" : "")} />
                      </div>
                      <div>
                        <label className={labelCls}>Nome Completo</label>
                        <input type="text" required placeholder="Ex: João Silva" value={affName}
                          onChange={e => setAffName(e.target.value)} className={inputCls} />
                      </div>
                      <div>
                        <label className={labelCls}>WhatsApp / Telefone</label>
                        <input type="text" placeholder="(00) 00000-0000" value={affPhone}
                          onChange={e => setAffPhone(formatPhone(e.target.value))} className={inputCls} />
                      </div>
                      <div>
                        <label className={labelCls}>Senha de Acesso</label>
                        <div className="flex gap-2">
                          <input type="text" required placeholder="Ex: 123456" value={affPass}
                            onChange={e => setAffPass(e.target.value)} className={inputCls} />
                          <button type="button"
                            onClick={() => setAffPass(Math.random().toString(36).substring(2, 8))}
                            className="px-3 bg-slate-100 hover:bg-slate-200 border border-slate-300 text-[10px] font-black uppercase text-slate-700 rounded-lg transition cursor-pointer whitespace-nowrap">
                            Gerar
                          </button>
                        </div>
                      </div>
                      <div>
                        <label className={labelCls}>Chave PIX do Afiliado</label>
                        <input type="text" placeholder="CPF, e-mail, telefone ou chave aleatória" value={affPixKey}
                          onChange={e => setAffPixKey(e.target.value)} className={inputCls} />
                      </div>
                      <div>
                        <label className={labelCls}>Nome Beneficiário PIX</label>
                        <input type="text" placeholder="Nome do titular da conta PIX" value={affPixReceiver}
                          onChange={e => setAffPixReceiver(e.target.value)} className={inputCls} />
                      </div>
                      <div>
                        <label className={labelCls}>Máx. Sorteios Simultâneos</label>
                        <select value={affMaxRaffles} onChange={e => setAffMaxRaffles(Number(e.target.value))} className={inputCls}>
                          {[1, 2, 3, 5, 10].map(n => <option key={n} value={n}>{n} sorteio(s)</option>)}
                        </select>
                      </div>
                      <div className="md:col-span-2 flex gap-3">
                        <button type="submit" disabled={loading}
                          className="flex-1 flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white py-2.5 rounded-xl text-xs font-black uppercase transition cursor-pointer shadow-sm">
                          {loading ? <Loader2 size={14} className="animate-spin" /> : <Check size={14} />}
                          {editingAff ? "Salvar Alterações" : "Cadastrar Afiliado"}
                        </button>
                        <button type="button" onClick={resetAffForm}
                          className="px-6 bg-slate-100 hover:bg-slate-200 text-slate-600 py-2.5 rounded-xl text-xs font-black uppercase transition cursor-pointer">
                          Cancelar
                        </button>
                      </div>
                    </form>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Search */}
              <div className="relative">
                <Search size={14} className="absolute left-3 top-3 text-slate-400" />
                <input type="text" placeholder="Buscar por nome ou CPF..."
                  value={affSearch} onChange={e => setAffSearch(e.target.value)}
                  className={inputCls + " pl-8"} />
              </div>

              {/* Affiliates list */}
              <div className="space-y-3">
                {filteredAffiliates.length === 0 && (
                  <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center">
                    <Users size={32} className="mx-auto text-slate-300 mb-2" />
                    <p className="text-sm font-bold text-slate-400">Nenhum afiliado encontrado.</p>
                    <p className="text-xs text-slate-300 mt-1">Cadastre afiliados para que possam criar sorteios.</p>
                  </div>
                )}
                {filteredAffiliates.map(aff => {
                  const affRaffles = raffles.filter(r => r.creatorUid === aff.cpf);
                  const activeRaffles = affRaffles.filter(r => r.status === "active");
                  const affTickets = tickets.filter(t => affRaffles.map(r => r.id).includes(t.raffleId));
                  const affRevenue = affTickets.filter(t => t.status === "confirmed").reduce((acc, t) => {
                    const r = affRaffles.find(rf => rf.id === t.raffleId);
                    return acc + (r?.pricePerTicket || 0);
                  }, 0);
                  const isExpanded = expandedAff === aff.cpf;

                  return (
                    <div key={aff.cpf} className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                      <div className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className={`w-9 h-9 rounded-full flex items-center justify-center font-black text-sm ${aff.status === "paused" ? "bg-red-100 text-red-600" : "bg-blue-100 text-blue-600"}`}>
                              {aff.name?.charAt(0).toUpperCase()}
                            </div>
                            <div>
                              <p className="text-xs font-black text-slate-800">{aff.name}</p>
                              <p className="text-[10px] text-slate-400 font-mono">{formatCPF(aff.cpf)}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className={`text-[9px] px-2 py-0.5 rounded-full font-black ${aff.status === "paused" ? "bg-red-100 text-red-700" : "bg-emerald-100 text-emerald-700"}`}>
                              {aff.status === "paused" ? "Suspenso" : "Ativo"}
                            </span>
                            <button onClick={() => setExpandedAff(isExpanded ? null : aff.cpf)}
                              className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition cursor-pointer">
                              {isExpanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                            </button>
                          </div>
                        </div>

                        {/* Stats row */}
                        <div className="mt-3 grid grid-cols-3 gap-2">
                          <div className="bg-slate-50 rounded-lg p-2 text-center">
                            <p className="text-sm font-black text-blue-600">{activeRaffles.length}</p>
                            <p className="text-[8px] text-slate-400 font-bold uppercase">Sorteios Ativos</p>
                          </div>
                          <div className="bg-slate-50 rounded-lg p-2 text-center">
                            <p className="text-sm font-black text-amber-600">{affTickets.filter(t => t.status === "pending").length}</p>
                            <p className="text-[8px] text-slate-400 font-bold uppercase">Pend. Pag.</p>
                          </div>
                          <div className="bg-slate-50 rounded-lg p-2 text-center">
                            <p className="text-sm font-black text-emerald-600">R${affRevenue.toFixed(0)}</p>
                            <p className="text-[8px] text-slate-400 font-bold uppercase">Receita</p>
                          </div>
                        </div>

                        {/* Link do afiliado */}
                        <div className="mt-3 flex items-center gap-2 p-2 bg-blue-50 rounded-lg border border-blue-100">
                          <Link size={11} className="text-blue-500 shrink-0" />
                          <span className="text-[9px] text-blue-600 font-mono flex-1 truncate">{getAffiliateLink(aff)}</span>
                          <button onClick={() => copyAffiliateLink(aff)}
                            className="shrink-0 p-1 rounded bg-blue-100 hover:bg-blue-200 transition cursor-pointer">
                            {copiedLink === aff.cpf ? <Check size={11} className="text-emerald-600" /> : <Copy size={11} className="text-blue-600" />}
                          </button>
                        </div>
                      </div>

                      {/* Expanded details */}
                      <AnimatePresence>
                        {isExpanded && (
                          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }}
                            className="border-t border-slate-100 px-4 py-4 bg-slate-50 space-y-3">
                            <div className="grid grid-cols-2 gap-3 text-xs">
                              <div>
                                <p className="text-[9px] text-slate-400 uppercase font-black">Telefone</p>
                                <p className="font-bold text-slate-700">{aff.phone || "—"}</p>
                              </div>
                              <div>
                                <p className="text-[9px] text-slate-400 uppercase font-black">Máx. Sorteios</p>
                                <p className="font-bold text-slate-700">{aff.maxRaffles || 1}</p>
                              </div>
                              <div>
                                <p className="text-[9px] text-slate-400 uppercase font-black">Chave PIX</p>
                                <p className="font-bold text-slate-700 truncate">{aff.pixKey || "—"}</p>
                              </div>
                              <div>
                                <p className="text-[9px] text-slate-400 uppercase font-black">Beneficiário PIX</p>
                                <p className="font-bold text-slate-700 truncate">{aff.pixReceiver || "—"}</p>
                              </div>
                              <div>
                                <p className="text-[9px] text-slate-400 uppercase font-black">Senha</p>
                                <div className="flex items-center gap-1">
                                  <p className="font-mono font-bold text-slate-700">{showPassMap[aff.cpf] ? aff.password : "••••••"}</p>
                                  <button onClick={() => setShowPassMap(p => ({ ...p, [aff.cpf]: !p[aff.cpf] }))}
                                    className="text-slate-400 hover:text-slate-600 cursor-pointer">
                                    {showPassMap[aff.cpf] ? <EyeOff size={11} /> : <Eye size={11} />}
                                  </button>
                                </div>
                              </div>
                              <div>
                                <p className="text-[9px] text-slate-400 uppercase font-black">Cadastrado em</p>
                                <p className="font-bold text-slate-700">{fmtDate(aff.createdAt)}</p>
                              </div>
                            </div>

                            {/* Sorteios do afiliado */}
                            {affRaffles.length > 0 && (
                              <div>
                                <p className="text-[9px] text-slate-400 uppercase font-black mb-1">Sorteios</p>
                                <div className="space-y-1">
                                  {affRaffles.map(r => (
                                    <div key={r.id} className="flex items-center justify-between bg-white rounded-lg px-3 py-2 border border-slate-100">
                                      <span className="text-xs font-bold text-slate-700 truncate">{r.title}</span>
                                      <span className={`text-[9px] px-2 py-0.5 rounded-full font-black ${r.status === "active" ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-500"}`}>
                                        {r.status === "active" ? "Ativo" : "Encerrado"}
                                      </span>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}

                            {/* Actions */}
                            <div className="flex gap-2 pt-1">
                              <button onClick={() => handleEditAffiliate(aff)}
                                className="flex-1 flex items-center justify-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-xl text-[10px] font-black uppercase transition cursor-pointer">
                                <Pencil size={11} /> Editar
                              </button>
                              <button onClick={() => handleToggleAffStatus(aff)}
                                className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl text-[10px] font-black uppercase transition cursor-pointer ${aff.status === "paused" ? "bg-emerald-100 hover:bg-emerald-200 text-emerald-700" : "bg-amber-100 hover:bg-amber-200 text-amber-700"}`}>
                                {aff.status === "paused" ? <><Play size={11} /> Reativar</> : <><Pause size={11} /> Suspender</>}
                              </button>
                              <button onClick={() => handleDeleteAffiliate(aff)}
                                className="px-3 flex items-center justify-center bg-red-50 hover:bg-red-100 text-red-600 py-2 rounded-xl text-[10px] font-black uppercase transition cursor-pointer">
                                <Trash size={11} />
                              </button>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* ── SORTEIOS ADM ───────────────────────────────────────── */}
          {tab === "sorteios_adm" && (
            <div className="space-y-5">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-black text-slate-800">Gerenciar Sorteios</h2>
                <button onClick={() => setShowCreateRaffle(true)}
                  className="flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl text-xs font-black uppercase transition cursor-pointer shadow-sm">
                  <Plus size={14} /> Criar Sorteio
                </button>
              </div>

              {/* Create Raffle Form */}
              <AnimatePresence>
                {showCreateRaffle && (
                  <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}
                    className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-black text-sm uppercase text-blue-700">Criar Novo Sorteio</h3>
                      <button onClick={() => setShowCreateRaffle(false)} className="text-slate-400 hover:text-slate-600 cursor-pointer"><X size={16} /></button>
                    </div>
                    <form onSubmit={handleCreateRaffle} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className={labelCls}>Título do Sorteio</label>
                        <input type="text" required placeholder="Ex: iPhone 15 Pro" value={rTitle} onChange={e => setRTitle(e.target.value)} className={inputCls} />
                      </div>
                      <div>
                        <label className={labelCls}>Prêmio</label>
                        <input type="text" required placeholder="Ex: iPhone 15 Pro Max 256GB" value={rAward} onChange={e => setRAward(e.target.value)} className={inputCls} />
                      </div>
                      <div className="md:col-span-2">
                        <label className={labelCls}>Descrição</label>
                        <textarea placeholder="Descreva o sorteio..." value={rDesc} onChange={e => setRDesc(e.target.value)} rows={2} className={inputCls} />
                      </div>
                      <div>
                        <label className={labelCls}>Preço por Cota (R$)</label>
                        <input type="number" min={1} step={0.5} value={rPrice} onChange={e => setRPrice(Number(e.target.value))} className={inputCls} />
                      </div>
                      <div>
                        <label className={labelCls}>Total de Cotas</label>
                        <select value={rTotal} onChange={e => setRTotal(Number(e.target.value))} className={inputCls}>
                          {[50, 100, 200, 300, 500, 1000].map(n => <option key={n} value={n}>{n} cotas</option>)}
                        </select>
                      </div>
                      <div>
                        <label className={labelCls}>Afiliado Responsável</label>
                        <select value={rCreatorUid} onChange={e => setRCreatorUid(e.target.value)} className={inputCls}>
                          <option value="">Admin Master (Eu)</option>
                          {affiliates.filter(a => a.status !== "paused").map(a => (
                            <option key={a.cpf} value={a.cpf}>{a.name}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className={labelCls}>Imagem do Prêmio</label>
                        <div onClick={() => fileRaffleRef.current?.click()}
                          className="border-2 border-dashed border-slate-200 hover:border-blue-400 rounded-xl p-3 cursor-pointer transition text-center bg-slate-50">
                          <input type="file" ref={fileRaffleRef} accept="image/*" className="hidden" onChange={e => parseImg(e, setRImage)} />
                          {rImage ? <img src={rImage} className="h-12 mx-auto rounded object-cover" alt="preview" /> : <p className="text-[10px] text-slate-400 font-bold">Clique para carregar imagem</p>}
                        </div>
                      </div>
                      <div className="md:col-span-2 flex gap-3">
                        <button type="submit" disabled={loading}
                          className="flex-1 flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white py-2.5 rounded-xl text-xs font-black uppercase transition cursor-pointer">
                          {loading ? <Loader2 size={14} className="animate-spin" /> : <Trophy size={14} />}
                          Criar Sorteio
                        </button>
                        <button type="button" onClick={() => setShowCreateRaffle(false)}
                          className="px-6 bg-slate-100 hover:bg-slate-200 text-slate-600 py-2.5 rounded-xl text-xs font-black uppercase transition cursor-pointer">
                          Cancelar
                        </button>
                      </div>
                    </form>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Raffles list */}
              <div className="space-y-3">
                {raffles.length === 0 && (
                  <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center">
                    <Trophy size={32} className="mx-auto text-slate-300 mb-2" />
                    <p className="text-sm font-bold text-slate-400">Nenhum sorteio criado ainda.</p>
                  </div>
                )}
                {raffles.map(raffle => {
                  const rTickets = tickets.filter(t => t.raffleId === raffle.id);
                  const rConfirmed = rTickets.filter(t => t.status === "confirmed");
                  const rPending = rTickets.filter(t => t.status === "pending");
                  const progress = Math.round((rTickets.filter(t => t.status !== "cancelled").length / raffle.totalNumbers) * 100);
                  const creator = affiliates.find(a => a.cpf === raffle.creatorUid);

                  return (
                    <div key={raffle.id} className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                      <div className="flex items-start gap-4 p-4">
                        <img src={raffle.image} alt={raffle.title} className="w-14 h-14 rounded-xl object-cover border border-slate-100 flex-shrink-0" />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2">
                            <div>
                              <p className="text-sm font-black text-slate-800 truncate">{raffle.title}</p>
                              <p className="text-[10px] text-slate-400">{raffle.creatorName} · R$ {raffle.pricePerTicket}/cota · {raffle.totalNumbers} cotas</p>
                            </div>
                            <span className={`shrink-0 text-[9px] px-2 py-0.5 rounded-full font-black ${raffle.status === "active" ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-500"}`}>
                              {raffle.status === "active" ? "Ativo" : "Encerrado"}
                            </span>
                          </div>
                          <div className="mt-2 w-full bg-slate-100 rounded-full h-1.5">
                            <div className="bg-blue-500 h-1.5 rounded-full transition-all" style={{ width: `${progress}%` }} />
                          </div>
                          <div className="mt-1 flex items-center gap-3 text-[9px] text-slate-400 font-bold">
                            <span className="text-emerald-600">{rConfirmed.length} confirmados</span>
                            <span className="text-amber-600">{rPending.length} pendentes</span>
                            <span>{progress}% vendido</span>
                          </div>
                        </div>
                      </div>
                      {raffle.status === "active" && (
                        <div className="border-t border-slate-100 px-4 py-3 flex gap-2">
                          <button onClick={() => setDrawingRaffle(raffle)}
                            className="flex-1 flex items-center justify-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-xl text-[10px] font-black uppercase transition cursor-pointer">
                            <Shuffle size={11} /> Sortear
                          </button>
                          <button onClick={() => handleDeleteRaffle(raffle)}
                            className="px-4 flex items-center justify-center bg-red-50 hover:bg-red-100 text-red-600 py-2 rounded-xl text-[10px] font-black uppercase transition cursor-pointer">
                            <Trash size={11} />
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* ── TRANSAÇÕES ────────────────────────────────────────── */}
          {tab === "transacoes" && (
            <div className="space-y-5">
              <h2 className="text-xl font-black text-slate-800">Transações & Pagamentos</h2>
              <div className="relative">
                <Search size={14} className="absolute left-3 top-3 text-slate-400" />
                <input type="text" placeholder="Buscar por nome, CPF ou telefone..."
                  value={searchTrans} onChange={e => setSearchTrans(e.target.value)}
                  className={inputCls + " pl-8"} />
              </div>

              {filteredPending.length === 0 ? (
                <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center">
                  <CheckCircle size={32} className="mx-auto text-emerald-300 mb-2" />
                  <p className="text-sm font-bold text-slate-400">Nenhum pagamento pendente.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {filteredPending.map(g => (
                    <div key={g.key} className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5">
                      <div className="flex items-start justify-between gap-3 mb-3">
                        <div>
                          <p className="text-sm font-black text-slate-800">{g.userName}</p>
                          <p className="text-[10px] text-slate-400 font-mono">{formatCPF(g.userCpf)}</p>
                          <p className="text-[10px] text-slate-500 mt-0.5">{g.raffleTitle}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-xs font-black text-blue-600">{g.tickets.length} cota(s)</p>
                          <p className="text-[10px] text-slate-400">Cotas: {g.tickets.map(t => `#${t.ticketNumber.toString().padStart(3, "0")}`).join(", ")}</p>
                        </div>
                      </div>

                      {g.receipts.length > 0 && (
                        <div className="mb-3">
                          <p className="text-[9px] text-slate-400 uppercase font-black mb-1">Comprovante(s)</p>
                          <div className="flex gap-2 flex-wrap">
                            {g.receipts.map((r, i) => (
                              <img key={i} src={r} alt="Comprovante"
                                className="w-16 h-16 rounded-lg object-cover border border-slate-200 cursor-pointer hover:scale-105 transition"
                                onClick={() => setZoomReceipt(r)} />
                            ))}
                          </div>
                        </div>
                      )}

                      <div className="flex gap-2">
                        <button onClick={() => approveTickets(g.tickets)}
                          className="flex-1 flex items-center justify-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white py-2.5 rounded-xl text-[10px] font-black uppercase transition cursor-pointer">
                          <Check size={12} /> Aprovar {g.tickets.length} bilhete(s)
                        </button>
                        <button onClick={() => declineTickets(g.tickets)}
                          className="px-4 flex items-center justify-center bg-red-50 hover:bg-red-100 text-red-600 py-2.5 rounded-xl text-[10px] font-black uppercase transition cursor-pointer">
                          <X size={12} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* ── GANHADORES ────────────────────────────────────────── */}
          {tab === "ganhadores" && (
            <div className="space-y-5">
              <h2 className="text-xl font-black text-slate-800">Ganhadores</h2>
              {winners.length === 0 ? (
                <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center">
                  <Award size={32} className="mx-auto text-slate-300 mb-2" />
                  <p className="text-sm font-bold text-slate-400">Nenhum ganhador publicado ainda.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {winners.map(w => (
                    <div key={w.id} className="bg-white rounded-2xl border border-slate-200 shadow-sm p-4 flex items-center gap-4">
                      <img src={w.prizePhoto} alt={w.raffleTitle} className="w-12 h-12 rounded-xl object-cover border border-slate-100 flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-black text-slate-800">{w.userName}</p>
                        <p className="text-[10px] text-slate-400">{w.raffleTitle}</p>
                        <p className="text-[10px] text-blue-600 font-bold">Cota #{w.winningNumber.toString().padStart(3, "0")} · {w.award}</p>
                        <p className="text-[9px] text-slate-300">{fmtDate(w.announcedAt)}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* ── CONFIG ────────────────────────────────────────────── */}
          {tab === "config" && (
            <div className="space-y-6">
              <h2 className="text-xl font-black text-slate-800">Configurações</h2>

              {/* PIX Config */}
              <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5">
                <h3 className="font-black text-sm text-slate-800 uppercase mb-4 flex items-center gap-2"><QrCode size={16} /> PIX Padrão</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className={labelCls}>Chave PIX</label>
                    <input type="text" placeholder="CPF, e-mail, telefone ou chave aleatória" value={pixKey} onChange={e => setPixKey(e.target.value)} className={inputCls} />
                  </div>
                  <div>
                    <label className={labelCls}>Nome do Beneficiário</label>
                    <input type="text" placeholder="Nome do titular" value={pixReceiver} onChange={e => setPixReceiver(e.target.value)} className={inputCls} />
                  </div>
                </div>
              </div>

              {/* Banners */}
              <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5">
                <h3 className="font-black text-sm text-slate-800 uppercase mb-4 flex items-center gap-2"><Image size={16} /> Banners</h3>
                <div className="space-y-3 mb-4">
                  {banners.map(b => (
                    <div key={b.id} className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl border border-slate-100">
                      <img src={b.image} alt="banner" className="w-12 h-8 object-cover rounded" />
                      <span className="text-[10px] text-slate-500 flex-1 truncate">{b.link}</span>
                      <button onClick={() => handleToggleBanner(b)} className="cursor-pointer">
                        {b.active ? <ToggleRight size={18} className="text-blue-600" /> : <ToggleLeft size={18} className="text-slate-300" />}
                      </button>
                      <button onClick={() => handleDeleteBanner(b.id)} className="text-red-400 hover:text-red-600 cursor-pointer"><Trash size={13} /></button>
                    </div>
                  ))}
                </div>
                <div className="space-y-2">
                  <div onClick={() => fileBannerRef.current?.click()} className="border-2 border-dashed border-slate-200 hover:border-blue-400 rounded-xl p-3 cursor-pointer transition text-center bg-slate-50">
                    <input type="file" ref={fileBannerRef} accept="image/*" className="hidden" onChange={e => parseImg(e, setNewBannerImg)} />
                    {newBannerImg ? <img src={newBannerImg} className="h-12 mx-auto rounded" alt="preview" /> : <p className="text-[10px] text-slate-400 font-bold">Clique para carregar imagem do banner</p>}
                  </div>
                  <input type="text" placeholder="Link do banner (opcional)" value={newBannerLink} onChange={e => setNewBannerLink(e.target.value)} className={inputCls} />
                  <button onClick={handleAddBanner} disabled={loading || !newBannerImg}
                    className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white py-2.5 rounded-xl text-xs font-black uppercase transition cursor-pointer">
                    <Plus size={13} /> Adicionar Banner
                  </button>
                </div>
              </div>

              {/* Terms */}
              <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5">
                <h3 className="font-black text-sm text-slate-800 uppercase mb-4">Regulamento / Termos de Uso</h3>
                <textarea rows={6} placeholder="Digite o regulamento da plataforma..." value={termsText} onChange={e => setTermsText(e.target.value)} className={inputCls} />
              </div>

              <button onClick={handleSaveConfig} disabled={loading}
                className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-xl text-sm font-black uppercase transition cursor-pointer shadow-sm">
                {loading ? <Loader2 size={15} className="animate-spin" /> : <Check size={15} />}
                Salvar Configurações
              </button>
            </div>
          )}
        </div>
      </div>

      {/* ── DRAW MODAL ────────────────────────────────────────────── */}
      <AnimatePresence>
        {drawingRaffle && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-60 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
            <motion.div initial={{ scale: 0.9, y: 20 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.9, y: 20 }}
              className="bg-white rounded-3xl w-full max-w-md shadow-2xl overflow-hidden">
              <div className="bg-gradient-to-br from-blue-600 to-indigo-700 px-6 py-4 flex items-center justify-between">
                <div>
                  <h3 className="font-black text-white text-sm uppercase">Realizar Sorteio</h3>
                  <p className="text-blue-200 text-[10px] mt-0.5">{drawingRaffle.title}</p>
                </div>
                <button onClick={() => { setDrawingRaffle(null); setDrawnTicket(null); setDrawnPhoto(""); setDrawError(""); setDrawSuccess(""); }}
                  className="p-1.5 bg-white/10 hover:bg-white/20 rounded-lg text-white cursor-pointer"><X size={16} /></button>
              </div>

              <div className="p-6 space-y-4">
                {/* Method */}
                <div className="flex gap-2 p-1 bg-slate-100 rounded-xl">
                  {(["system", "manual"] as const).map(m => (
                    <button key={m} onClick={() => { setDrawMethod(m); setDrawnTicket(null); setDrawError(""); setDrawSuccess(""); }}
                      className={`flex-1 py-2 rounded-lg text-[10px] font-black uppercase cursor-pointer transition ${drawMethod === m ? "bg-white text-slate-800 shadow" : "text-slate-400"}`}>
                      {m === "system" ? "Automático" : "Manual"}
                    </button>
                  ))}
                </div>

                {/* Spin number */}
                {(isSpinning || drawnTicket) && (
                  <div className={`rounded-2xl p-6 text-center ${drawnTicket && !isSpinning ? "bg-emerald-50 border border-emerald-200" : "bg-blue-50 border border-blue-200"}`}>
                    <p className={`text-5xl font-black ${drawnTicket && !isSpinning ? "text-emerald-600" : "text-blue-600"} transition-all`}>
                      #{(isSpinning ? spinNum : drawnTicket?.ticketNumber || 0).toString().padStart(3, "0")}
                    </p>
                    {drawnTicket && !isSpinning && (
                      <div className="mt-2">
                        <p className="text-sm font-black text-emerald-700">{drawnTicket.userName}</p>
                        <p className="text-[10px] text-emerald-500">{formatCPF(drawnTicket.userCpf)}</p>
                      </div>
                    )}
                  </div>
                )}

                {drawMethod === "manual" && !drawnTicket && (
                  <div>
                    <label className={labelCls}>Número Vencedor</label>
                    <input type="number" min={1} max={drawingRaffle.totalNumbers} placeholder="Digite o número da cota"
                      value={manualNum} onChange={e => setManualNum(Number(e.target.value))} className={inputCls} />
                  </div>
                )}

                {drawError && <p className="text-xs font-bold text-red-600 bg-red-50 rounded-xl p-3">{drawError}</p>}
                {drawSuccess && <p className="text-xs font-bold text-emerald-700 bg-emerald-50 rounded-xl p-3">{drawSuccess}</p>}

                {drawnTicket && !isSpinning && (
                  <div>
                    <label className={labelCls}>Foto do Prêmio (opcional)</label>
                    <div onClick={() => fileDrawRef.current?.click()} className="border-2 border-dashed border-slate-200 hover:border-blue-400 rounded-xl p-3 cursor-pointer transition text-center bg-slate-50">
                      <input type="file" ref={fileDrawRef} accept="image/*" className="hidden" onChange={e => parseImg(e, setDrawnPhoto)} />
                      {drawnPhoto ? <img src={drawnPhoto} className="h-16 mx-auto rounded object-cover" alt="prize" /> : <p className="text-[10px] text-slate-400">Clique para adicionar foto do prêmio</p>}
                    </div>
                  </div>
                )}

                <div className="flex gap-3">
                  {!drawnTicket ? (
                    <button onClick={handleDraw} disabled={isSpinning}
                      className="flex-1 flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-xl text-xs font-black uppercase transition cursor-pointer">
                      {isSpinning ? <Loader2 size={14} className="animate-spin" /> : <Shuffle size={14} />}
                      {isSpinning ? "Sorteando..." : "Realizar Sorteio"}
                    </button>
                  ) : (
                    <>
                      <button onClick={() => { setDrawnTicket(null); setDrawSuccess(""); setDrawError(""); }}
                        className="px-4 bg-slate-100 hover:bg-slate-200 text-slate-600 py-3 rounded-xl text-xs font-black uppercase transition cursor-pointer">
                        Novo
                      </button>
                      <button onClick={handlePublishWinner}
                        className="flex-1 flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white py-3 rounded-xl text-xs font-black uppercase transition cursor-pointer">
                        <Trophy size={14} /> Publicar Ganhador
                      </button>
                    </>
                  )}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Receipt zoom */}
      <AnimatePresence>
        {zoomReceipt && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-70 bg-black/90 flex items-center justify-center p-4 cursor-pointer"
            onClick={() => setZoomReceipt(null)}>
            <img src={zoomReceipt} alt="Comprovante" className="max-w-full max-h-full rounded-2xl shadow-2xl" />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Confirm Dialog */}
      <AnimatePresence>
        {confirmDialog && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-70 bg-black/60 flex items-center justify-center p-4">
            <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} exit={{ scale: 0.9 }}
              className="bg-white rounded-2xl p-6 w-full max-w-sm shadow-2xl">
              <h3 className="font-black text-sm text-slate-800 mb-2">{confirmDialog.title}</h3>
              <p className="text-xs text-slate-500 mb-5">{confirmDialog.description}</p>
              <div className="flex gap-3">
                <button onClick={() => setConfirmDialog(null)} className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-black uppercase cursor-pointer transition">Cancelar</button>
                <button onClick={() => { confirmDialog.onConfirm(); setConfirmDialog(null); }} className="flex-1 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-black uppercase cursor-pointer transition">Confirmar</button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
