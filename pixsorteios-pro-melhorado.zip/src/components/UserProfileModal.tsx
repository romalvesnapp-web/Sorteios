import React, { useState, useRef } from "react";
import { doc, setDoc } from "firebase/firestore";
import { db, handleFirestoreError, OperationType } from "../firebase";
import { UserProfile } from "../types";
import { User, Phone, Calendar, CreditCard, Upload, Loader2 } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface UserProfileModalProps {
  uid: string;
  email: string;
  onProfileCreated: (profile: UserProfile) => void;
  onCancel: () => void;
}

export default function UserProfileModal({ uid, email, onProfileCreated, onCancel }: UserProfileModalProps) {
  const [name, setName] = useState("");
  const [cpf, setCpf] = useState("");
  const [phone, setPhone] = useState("");
  const [birthDate, setBirthDate] = useState("");
  const [photo, setPhoto] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Masks
  const handleCpfChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let val = e.target.value.replace(/\D/g, "");
    if (val.length > 11) val = val.substring(0, 11);
    
    // Apply CPF mask 999.999.999-99
    if (val.length > 9) {
      val = val.replace(/^(\d{3})(\d{3})(\d{3})(\d{2})$/, "$1.$2.$3-$4");
    } else if (val.length > 6) {
      val = val.replace(/^(\d{3})(\d{3})(\d{1,3})$/, "$1.$2.$3");
    } else if (val.length > 3) {
      val = val.replace(/^(\d{3})(\d{1,3})$/, "$1.$2");
    }
    setCpf(val);
  };

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let val = e.target.value.replace(/\D/g, "");
    if (val.length > 11) val = val.substring(0, 11);

    // Apply Phone mask (99) 99999-9999
    if (val.length > 10) {
      val = val.replace(/^(\d{2})(\d{5})(\d{4})$/, "($1) $2-$3");
    } else if (val.length > 6) {
      val = val.replace(/^(\d{2})(\d{4})(\d{0,4})$/, "($1) $2-$3");
    } else if (val.length > 2) {
      val = val.replace(/^(\d{2})(\d{1,4})$/, "($1) $2");
    } else if (val.length > 0) {
      val = `(${val}`;
    }
    setPhone(val);
  };

  // Convert uploaded image file to compressed Base64
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 1000 * 1024) {
      setError("A imagem deve ter menos de 1MB.");
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === "string") {
        setPhoto(reader.result);
        setError("");
      }
    };
    reader.onerror = () => {
      setError("Erro ao processar imagem.");
    };
    reader.readAsDataURL(file);
  };

  // Drag and drop events
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (!file) return;

    if (file.size > 1000 * 1024) {
      setError("A imagem deve ter menos de 1MB.");
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === "string") {
        setPhoto(reader.result);
        setError("");
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    const cleanCpf = cpf.replace(/\D/g, "");
    if (cleanCpf.length !== 11) {
      setError("Por favor, preencha o CPF completo.");
      return;
    }

    const cleanPhone = phone.replace(/\D/g, "");
    if (cleanPhone.length < 10) {
      setError("Por favor, preencha um número de telefone válido.");
      return;
    }

    if (!name.trim()) {
      setError("Por favor, ensira seu nome.");
      return;
    }

    if (!birthDate) {
      setError("Por favor, ensira sua data de nascimento.");
      return;
    }

    if (!photo) {
      setError("Por favor, envie uma foto de perfil local para exibição.");
      return;
    }

    setLoading(true);

    const userProfile: UserProfile = {
      uid,
      name: name.trim(),
      cpf: cleanCpf,
      phone: phone.trim(),
      birthDate,
      photo,
      email,
      isAdmin: false,
      createdAt: new Date().toISOString(),
    };

    try {
      // Writing to /users/{cleanCpf} as required
      await setDoc(doc(db, "users", cleanCpf), userProfile);
      onProfileCreated(userProfile);
    } catch (err) {
      console.error(err);
      try {
        handleFirestoreError(err, OperationType.WRITE, `users/${cleanCpf}`);
      } catch (translatedErr: any) {
        setError("Erro ao salvar perfil no banco de dados. " + translatedErr.message);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 px-4 backdrop-blur-md" id="profile-modal">
      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="w-full max-w-md overflow-hidden rounded-3xl bg-[#0a0d15] border border-blue-500/15 text-slate-100 shadow-[0_10px_40px_rgba(0,0,0,0.8)]"
      >
        {/* Banner Top */}
        <div className="bg-gradient-to-r from-[#0d111d] to-[#080a10] px-6 py-6 border-b border-blue-500/10 text-white relative">
          <div className="absolute inset-x-0 bottom-0 h-[1px] bg-gradient-to-r from-transparent via-blue-400/20 to-transparent" />
          <h2 className="text-lg font-black font-sans uppercase tracking-tight text-white flex items-center gap-1.5">
            <User size={18} className="text-blue-400 animate-pulse" /> Cadastre seu Perfil
          </h2>
          <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
            Seus dados são necessários para a identificação e confirmação dos seus bilhetes de rifa.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 bg-[#0a0d15]">
          {error && (
            <div className="rounded-xl bg-red-955/50 border border-red-500/30 text-red-400 p-3 text-xs leading-relaxed font-bold">
              ⚠️ {error}
            </div>
          )}

          {/* Name */}
          <div>
            <label className="block text-[10px] font-black text-blue-500 uppercase tracking-widest mb-1.5">Nome Completo</label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-500">
                <User size={16} />
              </span>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Ex. João Silva"
                className="w-full rounded-xl bg-[#121624] border border-blue-500/10 py-2.5 pl-10 pr-4 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-blue-400 focus:ring-1 focus:ring-blue-400"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3.5">
            {/* CPF */}
            <div>
              <label className="block text-[10px] font-black text-blue-500 uppercase tracking-widest mb-1.5">CPF</label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-500">
                  <CreditCard size={16} />
                </span>
                <input
                  type="text"
                  required
                  value={cpf}
                  onChange={handleCpfChange}
                  placeholder="000.000.000-00"
                  className="w-full rounded-xl bg-[#121624] border border-blue-500/10 py-2.5 pl-10 pr-4 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-blue-400 focus:ring-1 focus:ring-blue-400"
                />
              </div>
            </div>

            {/* Birth Date */}
            <div>
              <label className="block text-[10px] font-black text-blue-500 uppercase tracking-widest mb-1.5">Nascimento</label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-500">
                  <Calendar size={16} />
                </span>
                <input
                  type="date"
                  required
                  value={birthDate}
                  onChange={(e) => setBirthDate(e.target.value)}
                  className="w-full rounded-xl bg-[#121624] border border-blue-500/10 py-2.5 pl-10 pr-4 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-blue-400 focus:ring-1 focus:ring-blue-400"
                />
              </div>
            </div>
          </div>

          {/* Phone */}
          <div>
            <label className="block text-[10px] font-black text-blue-500 uppercase tracking-widest mb-1.5">Telefone / WhatsApp</label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-500">
                <Phone size={16} />
              </span>
              <input
                type="text"
                required
                value={phone}
                onChange={handlePhoneChange}
                placeholder="(00) 00000-0000"
                className="w-full rounded-xl bg-[#121624] border border-blue-500/10 py-2.5 pl-10 pr-4 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-blue-400 focus:ring-1 focus:ring-blue-400"
              />
            </div>
          </div>

          {/* Image Drop & Preview */}
          <div>
            <label className="block text-[10px] font-black text-blue-500 uppercase tracking-widest mb-1.5">Sua Foto de Perfil</label>
            <div
              onDragOver={handleDragOver}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className="group relative flex flex-col items-center justify-center border-2 border-dashed border-blue-500/20 rounded-2xl bg-blue-500/5 p-4 transition hover:bg-blue-500/10 hover:border-blue-400 cursor-pointer text-center"
            >
              <input
                type="file"
                ref={fileInputRef}
                accept="image/*"
                onChange={handlePhotoUpload}
                className="hidden"
              />

              {photo ? (
                <div className="flex flex-col items-center space-y-2.5">
                  <img
                    src={photo}
                    alt="Preview"
                    referrerPolicy="no-referrer"
                    className="h-20 w-20 rounded-full object-cover border-2 border-blue-400 shadow-md"
                  />
                  <span className="text-xs text-blue-400 font-extrabold uppercase tracking-wide">Trocar imagem</span>
                </div>
              ) : (
                <div className="flex flex-col items-center space-y-2">
                  <div className="p-3 bg-[#111422] rounded-full text-slate-400 group-hover:text-blue-400 group-hover:scale-105 transition-all">
                    <Upload size={20} />
                  </div>
                  <div className="text-xs">
                    <p className="font-extrabold text-slate-205">Arraste a foto ou clique para buscar</p>
                    <p className="text-slate-500 mt-1">JPEG, PNG de até 1MB</p>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex space-x-3 pt-4 border-t border-blue-500/10">
            <button
              type="button"
              onClick={onCancel}
              className="flex-1 rounded-xl bg-[#111422] hover:bg-slate-900 border border-blue-500/10 text-slate-400 font-extrabold uppercase py-3 transition text-xs tracking-wider cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex-1 relative flex items-center justify-center rounded-xl bg-gradient-to-r from-blue-500 to-indigo-600 text-white font-black uppercase py-3 transition text-xs tracking-wider cursor-pointer shadow-[0_3px_12px_rgba(37,99,235,0.25)] hover:scale-102"
            >
              {loading ? (
                <Loader2 className="animate-spin text-white" size={18} />
              ) : (
                "Salvar Perfil"
              )}
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
}
