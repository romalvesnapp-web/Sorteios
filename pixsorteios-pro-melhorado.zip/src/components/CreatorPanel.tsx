import React, { useState, useEffect, useRef } from "react";
import { collection, query, where, onSnapshot, setDoc, doc, deleteDoc, updateDoc, getDoc } from "firebase/firestore";
import { db } from "../firebase";
import { Raffle, Ticket, UserProfile, Winner } from "../types";
import {
  X, Plus, Upload, Trash, Trophy, Check, Sparkles, AlertCircle, BarChart2,
  Ticket as TicketIcon, Link, Copy, Shuffle, Loader2, Clock, Users, Coins,
  CheckCircle, QrCode, Eye, EyeOff, ChevronDown, ChevronUp, Search, Phone,
  Award, Pause, Play, Settings
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { compressImage, generatePixCopiaECola } from "../utils";

const formatCPF = (val: string) => {
  const parts = val.replace(/\D/g, "");
  if (parts.length !== 11) return val;
  return `${parts.slice(0, 3)}.${parts.slice(3, 6)}.${parts.slice(6, 9)}-${parts.slice(9, 11)}`;
};

interface CreatorPanelProps {
  profile: UserProfile;
  onClose: () => void;
}

type CreatorTab = "meus" | "criar" | "bilhetes" | "historico";

export default function CreatorPanel({ profile, onClose }: CreatorPanelProps) {
  const [activeTab, setActiveTab] = useState<CreatorTab>("meus");
  const [myRaffles, setMyRaffles] = useState<Raffle[]>([]);
  const [allTickets, setAllTickets] = useState<Ticket[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [affiliateData, setAffiliateData] = useState<any>(null);

  // Search & filters
  const [historySearch, setHistorySearch] = useState("");
  const [historyStatusFilter, setHistoryStatusFilter] = useState<"all" | "confirmed" | "pending">("all");
  const [historyRaffleFilter, setHistoryRaffleFilter] = useState<string>("all");
  const [expandedRaffle, setExpandedRaffle] = useState<string | null>(null);

  // Create Raffle
  const [rTitle, setRTitle] = useState("");
  const [rAward, setAward] = useState("");
  const [rDesc, setRDesc] = useState("");
  const [rPrice, setRPrice] = useState(1);
  const [rTotalNumbers, setRTotalNumbers] = useState(100);
  const [rImage, setRImage] = useState("");
  const [rPixKey, setRPixKey] = useState("");
  const [rPixReceiver, setRPixReceiver] = useState("");

  // Draw
  const [drawingRaffle, setDrawingRaffle] = useState<Raffle | null>(null);
  const [drawMethod, setDrawMethod] = useState<"system" | "manual">("system");
  const [manualWinningNum, setManualWinningNum] = useState("");
  const [drawnWinnerTicket, setDrawnWinnerTicket] = useState<Ticket | null>(null);
  const [drawnWinnerPhoto, setDrawnWinnerPhoto] = useState("");
  const [drawError, setDrawError] = useState("");
  const [drawSuccess, setDrawSuccess] = useState("");
  const [isSpinning, setIsSpinning] = useState(false);
  const [spinNum, setSpinNum] = useState(0);

  const [copiedLink, setCopiedLink] = useState<string | null>(null);
  const [confirmDialog, setConfirmDialog] = useState<{ title: string; description: string; onConfirm: () => void } | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const fileAwardRef = useRef<HTMLInputElement>(null);

  // Load affiliate data (pix keys etc)
  useEffect(() => {
    const loadAffData = async () => {
      try {
        const snap = await getDoc(doc(db, "affiliates", profile.cpf));
        if (snap.exists()) {
          const data = snap.data();
          setAffiliateData(data);
          setRPixKey(data.pixKey || profile.phone || "");
          setRPixReceiver(data.pixReceiver || profile.name || "");
        } else {
          setRPixKey(profile.phone || "");
          setRPixReceiver(profile.name || "");
        }
      } catch (e) {
        setRPixKey(profile.phone || "");
        setRPixReceiver(profile.name || "");
      }
    };
    loadAffData();
  }, [profile.cpf]);

  // Load my raffles
  useEffect(() => {
    const q = query(collection(db, "raffles"), where("creatorUid", "==", profile.uid));
    return onSnapshot(q, snap => {
      const list: Raffle[] = [];
      snap.forEach(d => list.push({ id: d.id, ...d.data() } as Raffle));
      setMyRaffles(list.sort((a, b) => b.createdAt.localeCompare(a.createdAt)));
    }, err => console.error("creator raffles:", err));
  }, [profile.uid]);

  // Load all tickets
  useEffect(() => {
    return onSnapshot(collection(db, "tickets"), snap => {
      const list: Ticket[] = [];
      snap.forEach(d => list.push({ id: d.id, ...d.data() } as Ticket));
      setAllTickets(list);
    }, err => console.error("tickets:", err));
  }, []);

  const myRaffleIds = myRaffles.map(r => r.id);
  const myRafflesTickets = allTickets.filter(t => myRaffleIds.includes(t.raffleId));
  const pendingTickets = myRafflesTickets.filter(t => t.status === "pending");

  const filteredHistoryTickets = React.useMemo(() => {
    return myRafflesTickets.filter(t => {
      if (historySearch.trim()) {
        const s = historySearch.toLowerCase();
        if (!t.userName.toLowerCase().includes(s) && !t.userPhone.includes(s) &&
          !t.userCpf.includes(s) && t.ticketNumber.toString() !== s) return false;
      }
      if (historyStatusFilter !== "all" && t.status !== historyStatusFilter) return false;
      if (historyRaffleFilter !== "all" && t.raffleId !== historyRaffleFilter) return false;
      return true;
    });
  }, [myRafflesTickets, historySearch, historyStatusFilter, historyRaffleFilter]);

  const parseImageFile = async (e: React.ChangeEvent<HTMLInputElement>, cb: (s: string) => void) => {
    const file = e.target.files?.[0]; if (!file) return;
    try { cb(await compressImage(file, 640, 0.6)); } catch (err: any) { setError("Erro ao ler imagem: " + err.message); }
  };

  const handleCreateSorteio = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(""); setSuccess("");

    if (!rTitle.trim() || !rAward.trim() || !rImage) {
      setError("Preencha o título, prêmio e faça upload de uma foto."); return;
    }
    if (!rPixKey.trim() || !rPixReceiver.trim()) {
      setError("Defina sua chave PIX e nome do beneficiário para receber pagamentos."); return;
    }

    const maxLimit = profile.maxRaffles || 1;
    const activeCount = myRaffles.filter(r => r.status === "active").length;
    if (activeCount >= maxLimit) {
      setError(`Você atingiu o limite de ${maxLimit} sorteio(s) ativo(s). Encerre um sorteio antes de criar outro.`);
      return;
    }

    setLoading(true);
    try {
      const id = `raffle_${Math.random().toString(36).substring(2, 11)}`;
      const newRaffle: Raffle = {
        id,
        title: rTitle.trim(),
        description: rDesc.trim(),
        image: rImage,
        pricePerTicket: Number(rPrice),
        totalNumbers: Number(rTotalNumbers),
        status: "active",
        award: rAward.trim(),
        createdAt: new Date().toISOString(),
        creatorUid: profile.uid,
        creatorName: profile.name,
        pixKey: rPixKey.trim(),
        pixReceiver: rPixReceiver.trim(),
      };
      await setDoc(doc(db, "raffles", id), newRaffle);
      setSuccess("Sorteio criado com sucesso! Compartilhe o link para vender cotas.");
      setRTitle(""); setAward(""); setRDesc(""); setRPrice(1); setRTotalNumbers(100); setRImage("");
      setActiveTab("meus");
    } catch (err: any) {
      setError("Erro ao criar sorteio: " + err.message);
    } finally { setLoading(false); }
  };

  const handleDeleteRaffle = (raffle: Raffle) => {
    setConfirmDialog({
      title: "Excluir Sorteio",
      description: `Excluir "${raffle.title}"? Todos os bilhetes serão removidos permanentemente.`,
      onConfirm: async () => {
        setLoading(true); setError(""); setSuccess("");
        try {
          const snap = await new Promise<any>((res, rej) => {
            const q = query(collection(db, "tickets"), where("raffleId", "==", raffle.id));
            import("firebase/firestore").then(({ getDocs }) => getDocs(q).then(res).catch(rej));
          });
          for (const d of snap.docs) await deleteDoc(d.ref);
          await deleteDoc(doc(db, "raffles", raffle.id));
          setSuccess("Sorteio excluído.");
        } catch (err: any) { setError("Erro: " + err.message); }
        finally { setLoading(false); }
      }
    });
  };

  // Approve ticket
  const approveTicket = async (ticket: Ticket) => {
    setLoading(true); setError(""); setSuccess("");
    try {
      await updateDoc(doc(db, "tickets", ticket.id), { status: "confirmed", confirmedAt: new Date().toISOString() });
      setSuccess("Bilhete aprovado!");
    } catch (err: any) { setError("Erro: " + err.message); }
    finally { setLoading(false); }
  };

  const declineTicket = async (ticket: Ticket) => {
    setLoading(true); setError(""); setSuccess("");
    try {
      await deleteDoc(doc(db, "tickets", ticket.id));
      setSuccess("Bilhete recusado.");
    } catch (err: any) { setError("Erro: " + err.message); }
    finally { setLoading(false); }
  };

  // Approve all pending for a raffle
  const approveAll = async (raffleId: string) => {
    const toApprove = pendingTickets.filter(t => t.raffleId === raffleId);
    if (toApprove.length === 0) return;
    setLoading(true); setError(""); setSuccess("");
    try {
      for (const t of toApprove) {
        await updateDoc(doc(db, "tickets", t.id), { status: "confirmed", confirmedAt: new Date().toISOString() });
      }
      setSuccess(`${toApprove.length} bilhete(s) aprovado(s)!`);
    } catch (err: any) { setError("Erro: " + err.message); }
    finally { setLoading(false); }
  };

  // Draw
  const handleDraw = () => {
    if (!drawingRaffle) return;
    setDrawError(""); setDrawSuccess("");
    const confirmed = allTickets.filter(t => t.raffleId === drawingRaffle.id && t.status === "confirmed");
    if (confirmed.length === 0) { setDrawError("Nenhum bilhete confirmado para sortear."); return; }

    if (drawMethod === "system") {
      setIsSpinning(true);
      let count = 0;
      const interval = setInterval(() => {
        setSpinNum(confirmed[Math.floor(Math.random() * confirmed.length)].ticketNumber);
        count++;
        if (count > 25) {
          clearInterval(interval);
          const winner = confirmed[Math.floor(Math.random() * confirmed.length)];
          setDrawnWinnerTicket(winner);
          setSpinNum(winner.ticketNumber);
          setIsSpinning(false);
          setDrawSuccess(`🎉 Cota #${winner.ticketNumber.toString().padStart(3, "0")} sorteada!`);
        }
      }, 80);
    } else {
      const num = Number(manualWinningNum);
      const found = confirmed.find(t => t.ticketNumber === num);
      if (!found) { setDrawError(`Cota #${num} não encontrada entre confirmadas.`); return; }
      setDrawnWinnerTicket(found);
      setDrawSuccess(`Cota #${found.ticketNumber.toString().padStart(3, "0")} selecionada.`);
    }
  };

  const handlePublishWinner = async () => {
    if (!drawingRaffle || !drawnWinnerTicket) return;
    try {
      const wid = "winner_" + Math.random().toString(36).substring(2, 11);
      await setDoc(doc(db, "winners", wid), {
        id: wid, raffleId: drawingRaffle.id, raffleTitle: drawingRaffle.title,
        userName: drawnWinnerTicket.userName, userCpf: drawnWinnerTicket.userCpf,
        winningNumber: drawnWinnerTicket.ticketNumber, award: drawingRaffle.award,
        prizePhoto: drawnWinnerPhoto || drawingRaffle.image,
        announcedAt: new Date().toISOString()
      });
      await updateDoc(doc(db, "raffles", drawingRaffle.id), { status: "finished" });
      setSuccess(`Ganhador publicado! Sorteio encerrado.`);
      setDrawingRaffle(null); setDrawnWinnerTicket(null); setDrawnWinnerPhoto("");
    } catch (err: any) { setDrawError("Erro: " + err.message); }
  };

  const getRaffleLink = (raffle: Raffle) => `${window.location.origin}${window.location.pathname}?r=${raffle.id}`;
  const getCreatorLink = () => `${window.location.origin}${window.location.pathname}?c=${profile.uid}`;

  const copyLink = (text: string, key: string) => {
    navigator.clipboard.writeText(text).then(() => {
      setCopiedLink(key);
      setTimeout(() => setCopiedLink(null), 2000);
    });
  };

  const totalRevenue = myRafflesTickets.filter(t => t.status === "confirmed").reduce((acc, t) => {
    const r = myRaffles.find(rf => rf.id === t.raffleId);
    return acc + (r?.pricePerTicket || 0);
  }, 0);

  const inputCls = "w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2.5 text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-600 focus:border-blue-600";
  const labelCls = "block text-[9px] uppercase font-black text-slate-500 mb-1";

  const tabs: { id: CreatorTab; label: string; icon: React.ReactNode; badge?: number }[] = [
    { id: "meus", label: "Meus Sorteios", icon: <Trophy size={14} /> },
    { id: "criar", label: "Criar", icon: <Plus size={14} /> },
    { id: "bilhetes", label: "Bilhetes", icon: <TicketIcon size={14} />, badge: pendingTickets.length || undefined },
    { id: "historico", label: "Histórico", icon: <BarChart2 size={14} /> },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-slate-100 flex flex-col overflow-hidden">
      {/* Header */}
      <div className="bg-white border-b border-slate-200 px-4 py-3 flex items-center justify-between shadow-sm flex-shrink-0">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-blue-600 rounded-xl">
            <Sparkles size={18} className="text-white" />
          </div>
          <div>
            <h1 className="font-black text-sm text-slate-800 uppercase">Painel do Afiliado</h1>
            <p className="text-[10px] text-slate-500">Olá, {profile.name} 👋</p>
          </div>
        </div>
        <button onClick={onClose} className="flex items-center gap-1.5 text-xs font-bold text-slate-500 hover:text-red-600 transition cursor-pointer px-3 py-2 rounded-lg hover:bg-red-50">
          <X size={14} /> Sair
        </button>
      </div>

      {/* Tab bar */}
      <div className="bg-white border-b border-slate-200 flex px-2 gap-0.5 flex-shrink-0">
        {tabs.map(t => (
          <button key={t.id} onClick={() => setActiveTab(t.id)}
            className={`relative flex items-center gap-1.5 px-4 py-3 text-[10px] font-black uppercase tracking-wider transition cursor-pointer border-b-2 ${activeTab === t.id ? "border-blue-600 text-blue-600" : "border-transparent text-slate-400 hover:text-slate-700"}`}>
            {t.icon} {t.label}
            {t.badge !== undefined && t.badge > 0 && (
              <span className="bg-red-500 text-white text-[8px] px-1.5 py-0.5 rounded-full font-black">{t.badge}</span>
            )}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto p-4 md:p-6 pb-6">
        {error && <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-xl text-xs font-bold text-red-700 flex gap-2"><AlertCircle size={14} className="shrink-0 mt-0.5" />{error}</div>}
        {success && <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs font-bold text-emerald-700 flex gap-2"><CheckCircle size={14} className="shrink-0 mt-0.5" />{success}</div>}

        {/* ── MEUS SORTEIOS ────────────────────────────────────── */}
        {activeTab === "meus" && (
          <div className="space-y-5">
            {/* Stats */}
            <div className="grid grid-cols-3 gap-3">
              {[
                { label: "Sorteios Ativos", value: myRaffles.filter(r => r.status === "active").length, color: "blue", icon: <Trophy size={16} /> },
                { label: "Pend. Aprovação", value: pendingTickets.length, color: "amber", icon: <Clock size={16} /> },
                { label: "Receita Total", value: `R$${totalRevenue.toFixed(0)}`, color: "emerald", icon: <Coins size={16} /> },
              ].map(s => (
                <div key={s.label} className="bg-white rounded-2xl border border-slate-200 p-3 text-center shadow-sm">
                  <div className={`text-${s.color}-600 flex justify-center mb-1`}>{s.icon}</div>
                  <p className={`text-lg font-black text-${s.color}-600`}>{s.value}</p>
                  <p className="text-[8px] text-slate-400 font-bold uppercase leading-tight mt-0.5">{s.label}</p>
                </div>
              ))}
            </div>

            {/* Meu link de vitrine */}
            <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4">
              <p className="text-[9px] font-black text-blue-600 uppercase mb-1">Seu Link de Vitrine Pessoal</p>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono text-blue-700 flex-1 truncate bg-white px-2 py-1.5 rounded-lg border border-blue-100">{getCreatorLink()}</span>
                <button onClick={() => copyLink(getCreatorLink(), "vitrine")}
                  className="shrink-0 p-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg cursor-pointer transition">
                  {copiedLink === "vitrine" ? <Check size={13} /> : <Copy size={13} />}
                </button>
              </div>
              <p className="text-[9px] text-blue-500 mt-1.5">Compartilhe este link para seus clientes verem todos os seus sorteios</p>
            </div>

            {myRaffles.length === 0 ? (
              <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center">
                <Trophy size={36} className="mx-auto text-slate-200 mb-3" />
                <p className="font-black text-slate-400 text-sm">Nenhum sorteio criado</p>
                <p className="text-xs text-slate-300 mt-1 mb-4">Crie seu primeiro sorteio para começar a vender!</p>
                <button onClick={() => setActiveTab("criar")}
                  className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-xl text-xs font-black uppercase transition cursor-pointer">
                  <Plus size={13} /> Criar Sorteio
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {myRaffles.map(raffle => {
                  const rTickets = allTickets.filter(t => t.raffleId === raffle.id);
                  const rConfirmed = rTickets.filter(t => t.status === "confirmed");
                  const rPending = rTickets.filter(t => t.status === "pending");
                  const progress = Math.round((rTickets.filter(t => t.status !== "cancelled").length / raffle.totalNumbers) * 100);
                  const revenue = rConfirmed.reduce((acc) => acc + raffle.pricePerTicket, 0);
                  const isExpanded = expandedRaffle === raffle.id;

                  return (
                    <div key={raffle.id} className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                      <div className="p-4">
                        <div className="flex items-start gap-3">
                          <img src={raffle.image} alt={raffle.title} className="w-14 h-14 rounded-xl object-cover border border-slate-100 flex-shrink-0" />
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between gap-2">
                              <p className="text-sm font-black text-slate-800 truncate">{raffle.title}</p>
                              <span className={`shrink-0 text-[9px] px-2 py-0.5 rounded-full font-black ${raffle.status === "active" ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-500"}`}>
                                {raffle.status === "active" ? "Ativo" : "Encerrado"}
                              </span>
                            </div>
                            <p className="text-[10px] text-slate-400">R$ {raffle.pricePerTicket}/cota · {raffle.totalNumbers} cotas</p>

                            <div className="mt-2 w-full bg-slate-100 rounded-full h-1.5">
                              <div className="bg-blue-500 h-1.5 rounded-full transition-all" style={{ width: `${progress}%` }} />
                            </div>
                            <div className="flex gap-3 mt-1 text-[9px] font-bold">
                              <span className="text-emerald-600">{rConfirmed.length} confirmados</span>
                              <span className="text-amber-600">{rPending.length} pendentes</span>
                              <span className="text-slate-400">{progress}%</span>
                              <span className="text-blue-600 ml-auto">R${revenue.toFixed(0)}</span>
                            </div>
                          </div>
                        </div>

                        {/* Link do sorteio */}
                        <div className="mt-3 flex items-center gap-2 p-2 bg-slate-50 rounded-lg border border-slate-100">
                          <Link size={10} className="text-slate-400 shrink-0" />
                          <span className="text-[9px] text-slate-500 font-mono flex-1 truncate">{getRaffleLink(raffle)}</span>
                          <button onClick={() => copyLink(getRaffleLink(raffle), raffle.id)}
                            className="shrink-0 p-1 rounded bg-slate-200 hover:bg-slate-300 transition cursor-pointer">
                            {copiedLink === raffle.id ? <Check size={10} className="text-emerald-600" /> : <Copy size={10} className="text-slate-600" />}
                          </button>
                        </div>

                        <button onClick={() => setExpandedRaffle(isExpanded ? null : raffle.id)}
                          className="mt-2 w-full flex items-center justify-center gap-1 text-[9px] text-slate-400 hover:text-slate-600 cursor-pointer transition py-1">
                          {isExpanded ? <><ChevronUp size={11} /> Menos</> : <><ChevronDown size={11} /> Gerenciar</>}
                        </button>
                      </div>

                      <AnimatePresence>
                        {isExpanded && (
                          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }}
                            className="border-t border-slate-100 bg-slate-50 px-4 py-4 space-y-3">
                            {/* Pending tickets for this raffle */}
                            {rPending.length > 0 && (
                              <div>
                                <div className="flex items-center justify-between mb-2">
                                  <p className="text-[9px] text-amber-600 uppercase font-black">Aguardando Aprovação ({rPending.length})</p>
                                  <button onClick={() => approveAll(raffle.id)}
                                    className="text-[9px] font-black text-emerald-600 hover:underline cursor-pointer">
                                    Aprovar Todos
                                  </button>
                                </div>
                                <div className="space-y-2">
                                  {rPending.slice(0, 5).map(t => (
                                    <div key={t.id} className="bg-white rounded-xl border border-slate-100 p-3">
                                      <div className="flex items-center justify-between">
                                        <div>
                                          <p className="text-xs font-black text-slate-800">{t.userName}</p>
                                          <p className="text-[9px] text-slate-400">Cota #{t.ticketNumber.toString().padStart(3, "0")} · {t.userPhone}</p>
                                        </div>
                                        <div className="flex gap-1.5">
                                          {t.paymentReceipt && (
                                            <img src={t.paymentReceipt} alt="comprovante" className="w-8 h-8 rounded object-cover border border-slate-100 cursor-pointer" />
                                          )}
                                          <button onClick={() => approveTicket(t)} className="p-1.5 bg-emerald-100 hover:bg-emerald-200 text-emerald-700 rounded-lg cursor-pointer"><Check size={11} /></button>
                                          <button onClick={() => declineTicket(t)} className="p-1.5 bg-red-100 hover:bg-red-200 text-red-600 rounded-lg cursor-pointer"><X size={11} /></button>
                                        </div>
                                      </div>
                                    </div>
                                  ))}
                                  {rPending.length > 5 && (
                                    <p className="text-[9px] text-slate-400 text-center">+ {rPending.length - 5} pendentes. Veja em "Bilhetes"</p>
                                  )}
                                </div>
                              </div>
                            )}

                            <div className="flex gap-2">
                              {raffle.status === "active" && (
                                <button onClick={() => setDrawingRaffle(raffle)}
                                  className="flex-1 flex items-center justify-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white py-2.5 rounded-xl text-[10px] font-black uppercase cursor-pointer transition">
                                  <Shuffle size={11} /> Sortear Ganhador
                                </button>
                              )}
                              <button onClick={() => handleDeleteRaffle(raffle)}
                                className="px-4 flex items-center justify-center bg-red-50 hover:bg-red-100 text-red-600 py-2.5 rounded-xl text-[10px] font-black uppercase cursor-pointer transition">
                                <Trash size={11} />
                              </button>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* ── CRIAR SORTEIO ────────────────────────────────────── */}
        {activeTab === "criar" && (
          <div className="space-y-5">
            <div>
              <h2 className="text-lg font-black text-slate-800">Criar Novo Sorteio</h2>
              <p className="text-xs text-slate-400 mt-0.5">Limite: {profile.maxRaffles || 1} sorteio(s) ativo(s) · Ativos: {myRaffles.filter(r => r.status === "active").length}</p>
            </div>

            <form onSubmit={handleCreateSorteio} className="space-y-4">
              <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5 space-y-4">
                <h3 className="font-black text-xs text-slate-700 uppercase">Informações do Sorteio</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className={labelCls}>Título</label>
                    <input type="text" required placeholder="Ex: iPhone 15 Pro Max" value={rTitle} onChange={e => setRTitle(e.target.value)} className={inputCls} />
                  </div>
                  <div>
                    <label className={labelCls}>Prêmio</label>
                    <input type="text" required placeholder="Ex: iPhone 15 Pro Max 256GB" value={rAward} onChange={e => setAward(e.target.value)} className={inputCls} />
                  </div>
                  <div className="md:col-span-2">
                    <label className={labelCls}>Descrição (opcional)</label>
                    <textarea placeholder="Descreva o sorteio, regras, data prevista..." value={rDesc} onChange={e => setRDesc(e.target.value)} rows={2} className={inputCls} />
                  </div>
                  <div>
                    <label className={labelCls}>Preço por Cota (R$)</label>
                    <input type="number" min={0.5} step={0.5} required value={rPrice} onChange={e => setRPrice(Number(e.target.value))} className={inputCls} />
                  </div>
                  <div>
                    <label className={labelCls}>Total de Cotas</label>
                    <select value={rTotalNumbers} onChange={e => setRTotalNumbers(Number(e.target.value))} className={inputCls}>
                      {[50, 100, 150, 200, 300, 500, 1000].map(n => <option key={n} value={n}>{n} cotas</option>)}
                    </select>
                  </div>
                </div>

                <div>
                  <label className={labelCls}>Foto do Prêmio *</label>
                  <div onClick={() => fileInputRef.current?.click()}
                    className="border-2 border-dashed border-slate-200 hover:border-blue-400 rounded-xl p-4 cursor-pointer transition text-center bg-slate-50">
                    <input type="file" ref={fileInputRef} accept="image/*" className="hidden" onChange={e => parseImageFile(e, setRImage)} />
                    {rImage ? (
                      <div className="flex items-center justify-center gap-3">
                        <img src={rImage} alt="preview" className="h-16 w-16 rounded-xl object-cover border border-slate-200" />
                        <p className="text-[10px] font-bold text-blue-600">Imagem carregada! Clique para trocar.</p>
                      </div>
                    ) : (
                      <div className="space-y-1">
                        <Upload size={20} className="mx-auto text-slate-300" />
                        <p className="text-[10px] font-bold text-slate-500">Clique para enviar foto do prêmio</p>
                        <p className="text-[9px] text-slate-300">PNG, JPG, WEBP até 10MB</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5 space-y-4">
                <h3 className="font-black text-xs text-slate-700 uppercase flex items-center gap-2"><QrCode size={13} /> Configurações de Pagamento PIX</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className={labelCls}>Sua Chave PIX *</label>
                    <input type="text" required placeholder="CPF, e-mail, telefone ou aleatória" value={rPixKey} onChange={e => setRPixKey(e.target.value)} className={inputCls} />
                  </div>
                  <div>
                    <label className={labelCls}>Nome do Beneficiário *</label>
                    <input type="text" required placeholder="Nome na conta PIX" value={rPixReceiver} onChange={e => setRPixReceiver(e.target.value)} className={inputCls} />
                  </div>
                </div>
                <p className="text-[9px] text-slate-400">Os pagamentos serão feitos diretamente para sua chave PIX. Configure corretamente para receber.</p>
              </div>

              <button type="submit" disabled={loading || myRaffles.filter(r => r.status === "active").length >= (profile.maxRaffles || 1)}
                className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed text-white py-3.5 rounded-2xl text-sm font-black uppercase transition cursor-pointer shadow-sm">
                {loading ? <Loader2 size={16} className="animate-spin" /> : <Sparkles size={16} />}
                Criar Sorteio
              </button>
            </form>
          </div>
        )}

        {/* ── BILHETES ─────────────────────────────────────────── */}
        {activeTab === "bilhetes" && (
          <div className="space-y-5">
            <h2 className="text-lg font-black text-slate-800">Bilhetes Pendentes</h2>

            {pendingTickets.length === 0 ? (
              <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center">
                <CheckCircle size={32} className="mx-auto text-emerald-300 mb-2" />
                <p className="text-sm font-bold text-slate-400">Nenhum bilhete aguardando aprovação.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {pendingTickets.map(t => {
                  const raffle = myRaffles.find(r => r.id === t.raffleId);
                  return (
                    <div key={t.id} className="bg-white rounded-2xl border border-slate-200 shadow-sm p-4">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1">
                          <p className="text-sm font-black text-slate-800">{t.userName}</p>
                          <p className="text-[10px] text-slate-400">{raffle?.title || t.raffleId}</p>
                          <p className="text-[10px] text-blue-600 font-bold">Cota #{t.ticketNumber.toString().padStart(3, "0")} · {t.userPhone}</p>
                          <p className="text-[9px] text-slate-300">{new Date(t.reservedAt).toLocaleString("pt-BR")}</p>
                        </div>
                        {t.paymentReceipt && (
                          <img src={t.paymentReceipt} alt="comprovante" className="w-14 h-14 rounded-xl object-cover border border-slate-200 flex-shrink-0" />
                        )}
                      </div>
                      <div className="flex gap-2 mt-3">
                        <button onClick={() => approveTicket(t)}
                          className="flex-1 flex items-center justify-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white py-2.5 rounded-xl text-[10px] font-black uppercase cursor-pointer transition">
                          <Check size={11} /> Aprovar
                        </button>
                        <button onClick={() => declineTicket(t)}
                          className="px-5 flex items-center justify-center bg-red-50 hover:bg-red-100 text-red-600 py-2.5 rounded-xl text-[10px] font-black uppercase cursor-pointer transition">
                          <X size={11} />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* ── HISTÓRICO ────────────────────────────────────────── */}
        {activeTab === "historico" && (
          <div className="space-y-5">
            <h2 className="text-lg font-black text-slate-800">Histórico de Vendas</h2>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div className="relative md:col-span-1">
                <Search size={13} className="absolute left-3 top-3 text-slate-400" />
                <input type="text" placeholder="Buscar comprador..." value={historySearch} onChange={e => setHistorySearch(e.target.value)} className={inputCls + " pl-8"} />
              </div>
              <select value={historyStatusFilter} onChange={e => setHistoryStatusFilter(e.target.value as any)} className={inputCls}>
                <option value="all">Todos os status</option>
                <option value="confirmed">Confirmados</option>
                <option value="pending">Pendentes</option>
              </select>
              <select value={historyRaffleFilter} onChange={e => setHistoryRaffleFilter(e.target.value)} className={inputCls}>
                <option value="all">Todos os sorteios</option>
                {myRaffles.map(r => <option key={r.id} value={r.id}>{r.title}</option>)}
              </select>
            </div>

            {filteredHistoryTickets.length === 0 ? (
              <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center">
                <TicketIcon size={32} className="mx-auto text-slate-200 mb-2" />
                <p className="text-sm font-bold text-slate-400">Nenhum bilhete encontrado.</p>
              </div>
            ) : (
              <div className="space-y-2">
                {filteredHistoryTickets.map(t => {
                  const raffle = myRaffles.find(r => r.id === t.raffleId);
                  return (
                    <div key={t.id} className="bg-white rounded-xl border border-slate-200 p-3 flex items-center gap-3">
                      <div className={`w-2 h-2 rounded-full flex-shrink-0 ${t.status === "confirmed" ? "bg-emerald-500" : t.status === "pending" ? "bg-amber-500" : "bg-slate-300"}`} />
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-black text-slate-800 truncate">{t.userName}</p>
                        <p className="text-[9px] text-slate-400">{raffle?.title || t.raffleId} · Cota #{t.ticketNumber.toString().padStart(3, "0")}</p>
                      </div>
                      <div className="text-right flex-shrink-0">
                        <span className={`text-[9px] px-2 py-0.5 rounded-full font-black ${t.status === "confirmed" ? "bg-emerald-100 text-emerald-700" : t.status === "pending" ? "bg-amber-100 text-amber-700" : "bg-slate-100 text-slate-500"}`}>
                          {t.status === "confirmed" ? "Confirmado" : t.status === "pending" ? "Pendente" : "Cancelado"}
                        </span>
                        <p className="text-[9px] text-slate-300 mt-0.5">R${raffle?.pricePerTicket?.toFixed(2)}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>

      {/* ── DRAW MODAL ────────────────────────────────────────────── */}
      <AnimatePresence>
        {drawingRaffle && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-60 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
            <motion.div initial={{ scale: 0.9, y: 20 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.9, y: 20 }}
              className="bg-white rounded-3xl w-full max-w-md shadow-2xl overflow-hidden">
              <div className="bg-gradient-to-br from-blue-600 to-indigo-700 px-6 py-4 flex items-center justify-between">
                <div>
                  <h3 className="font-black text-white text-sm uppercase">Realizar Sorteio</h3>
                  <p className="text-blue-200 text-[10px] mt-0.5">{drawingRaffle.title}</p>
                </div>
                <button onClick={() => { setDrawingRaffle(null); setDrawnWinnerTicket(null); setDrawnWinnerPhoto(""); setDrawError(""); setDrawSuccess(""); }}
                  className="p-1.5 bg-white/10 hover:bg-white/20 rounded-lg text-white cursor-pointer"><X size={16} /></button>
              </div>

              <div className="p-6 space-y-4">
                <div className="flex gap-2 p-1 bg-slate-100 rounded-xl">
                  {(["system", "manual"] as const).map(m => (
                    <button key={m} onClick={() => { setDrawMethod(m); setDrawnWinnerTicket(null); setDrawError(""); setDrawSuccess(""); }}
                      className={`flex-1 py-2 rounded-lg text-[10px] font-black uppercase cursor-pointer transition ${drawMethod === m ? "bg-white text-slate-800 shadow" : "text-slate-400"}`}>
                      {m === "system" ? "Automático" : "Manual"}
                    </button>
                  ))}
                </div>

                {(isSpinning || drawnWinnerTicket) && (
                  <div className={`rounded-2xl p-6 text-center ${drawnWinnerTicket && !isSpinning ? "bg-emerald-50 border border-emerald-200" : "bg-blue-50 border border-blue-200"}`}>
                    <p className={`text-5xl font-black ${drawnWinnerTicket && !isSpinning ? "text-emerald-600" : "text-blue-600"}`}>
                      #{(isSpinning ? spinNum : drawnWinnerTicket?.ticketNumber || 0).toString().padStart(3, "0")}
                    </p>
                    {drawnWinnerTicket && !isSpinning && (
                      <div className="mt-2">
                        <p className="text-sm font-black text-emerald-700">{drawnWinnerTicket.userName}</p>
                        <p className="text-[10px] text-emerald-500">{formatCPF(drawnWinnerTicket.userCpf)}</p>
                      </div>
                    )}
                  </div>
                )}

                {drawMethod === "manual" && !drawnWinnerTicket && (
                  <div>
                    <label className={labelCls}>Número da Cota Vencedora</label>
                    <input type="number" min={1} max={drawingRaffle.totalNumbers} placeholder="Digite o número"
                      value={manualWinningNum} onChange={e => setManualWinningNum(e.target.value)} className={inputCls} />
                  </div>
                )}

                {drawError && <p className="text-xs font-bold text-red-600 bg-red-50 rounded-xl p-3">{drawError}</p>}
                {drawSuccess && <p className="text-xs font-bold text-emerald-700 bg-emerald-50 rounded-xl p-3">{drawSuccess}</p>}

                {drawnWinnerTicket && !isSpinning && (
                  <div>
                    <label className={labelCls}>Foto do Prêmio (opcional)</label>
                    <div onClick={() => fileAwardRef.current?.click()} className="border-2 border-dashed border-slate-200 hover:border-blue-400 rounded-xl p-3 cursor-pointer text-center bg-slate-50">
                      <input type="file" ref={fileAwardRef} accept="image/*" className="hidden" onChange={e => parseImageFile(e, setDrawnWinnerPhoto)} />
                      {drawnWinnerPhoto ? <img src={drawnWinnerPhoto} className="h-12 mx-auto rounded object-cover" alt="prize" /> : <p className="text-[10px] text-slate-400">Clique para adicionar foto</p>}
                    </div>
                  </div>
                )}

                <div className="flex gap-3">
                  {!drawnWinnerTicket ? (
                    <button onClick={handleDraw} disabled={isSpinning}
                      className="flex-1 flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-xl text-xs font-black uppercase cursor-pointer transition">
                      {isSpinning ? <Loader2 size={14} className="animate-spin" /> : <Shuffle size={14} />}
                      {isSpinning ? "Sorteando..." : "Realizar Sorteio"}
                    </button>
                  ) : (
                    <>
                      <button onClick={() => { setDrawnWinnerTicket(null); setDrawSuccess(""); setDrawError(""); }}
                        className="px-4 bg-slate-100 hover:bg-slate-200 text-slate-600 py-3 rounded-xl text-xs font-black uppercase cursor-pointer transition">
                        Novo
                      </button>
                      <button onClick={handlePublishWinner}
                        className="flex-1 flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white py-3 rounded-xl text-xs font-black uppercase cursor-pointer transition">
                        <Trophy size={14} /> Publicar Ganhador
                      </button>
                    </>
                  )}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Confirm Dialog */}
      <AnimatePresence>
        {confirmDialog && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-60 bg-black/60 flex items-center justify-center p-4">
            <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} exit={{ scale: 0.9 }}
              className="bg-white rounded-2xl p-6 w-full max-w-sm shadow-2xl">
              <h3 className="font-black text-sm text-slate-800 mb-2">{confirmDialog.title}</h3>
              <p className="text-xs text-slate-500 mb-5">{confirmDialog.description}</p>
              <div className="flex gap-3">
                <button onClick={() => setConfirmDialog(null)} className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-black uppercase cursor-pointer">Cancelar</button>
                <button onClick={() => { confirmDialog.onConfirm(); setConfirmDialog(null); }} className="flex-1 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-black uppercase cursor-pointer">Confirmar</button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
