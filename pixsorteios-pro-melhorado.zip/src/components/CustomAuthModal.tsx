import React, { useState, useRef } from "react";
import { doc, getDoc, setDoc } from "firebase/firestore";
import { db } from "../firebase";
import { UserProfile } from "../types";
import { compressImage } from "../utils";
import { User, Phone, CreditCard, Upload, Loader2, X, ShieldAlert, LogIn, Eye, EyeOff } from "lucide-react";
import { motion } from "motion/react";

interface CustomAuthModalProps {
  onClose: () => void;
  onLoginSuccess: (profile: UserProfile) => void;
}

const MASTER_USER = "admicarlos";
const MASTER_PASS = "icarlos26900";

export default function CustomAuthModal({ onClose, onLoginSuccess }: CustomAuthModalProps) {
  const [activeTab, setActiveTab] = useState<"login" | "register">("login");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [showPass, setShowPass] = useState(false);

  const [loginType, setLoginType] = useState<"user" | "affiliate" | "admin">("user");
  const [loginCpf, setLoginCpf] = useState("");
  const [loginPassword, setLoginPassword] = useState("");

  const [regName, setRegName] = useState("");
  const [regCpf, setRegCpf] = useState("");
  const [regPhone, setRegPhone] = useState("");
  const [regPhoto, setRegPhoto] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const formatCPF = (val: string) => {
    let clean = val.replace(/\D/g, "");
    if (clean.length > 11) clean = clean.substring(0, 11);
    if (clean.length > 9) return clean.replace(/^(\d{3})(\d{3})(\d{3})(\d{2})$/, "$1.$2.$3-$4");
    if (clean.length > 6) return clean.replace(/^(\d{3})(\d{3})(\d{1,3})$/, "$1.$2.$3");
    if (clean.length > 3) return clean.replace(/^(\d{3})(\d{1,3})$/, "$1.$2");
    return clean;
  };

  const formatPhone = (val: string) => {
    let clean = val.replace(/\D/g, "");
    if (clean.length > 11) clean = clean.substring(0, 11);
    if (clean.length > 10) return clean.replace(/^(\d{2})(\d{5})(\d{4})$/, "($1) $2-$3");
    if (clean.length > 6) return clean.replace(/^(\d{2})(\d{4})(\d{0,4})$/, "($1) $2-$3");
    if (clean.length > 2) return clean.replace(/^(\d{2})(\d{1,4})$/, "($1) $2");
    if (clean.length > 0) return `(${clean}`;
    return clean;
  };

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 10 * 1024 * 1024) { setError("A imagem excede 10MB."); return; }
    setLoading(true);
    try {
      const b64 = await compressImage(file, 250, 0.6);
      setRegPhoto(b64);
    } catch (err: any) {
      setError(err?.message || "Erro ao compactar foto.");
    } finally { setLoading(false); }
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    // ── ADMIN MASTER ──────────────────────────────────────────────
    if (loginType === "admin") {
      if (loginCpf.trim() === MASTER_USER && loginPassword === MASTER_PASS) {
        const adminProfile: UserProfile = {
          uid: "admicarlos", name: "Admin Master", cpf: "admicarlos",
          phone: "(00) 00000-0000", birthDate: "1990-01-01", photo: "",
          email: "admin@pixsorteios.com", isAdmin: true, createdAt: new Date().toISOString()
        };
        localStorage.setItem("lucky_user_cpf", "admicarlos");
        onLoginSuccess(adminProfile);
        onClose();
      } else {
        setError("Usuário ou senha incorretos para Admin Master.");
      }
      return;
    }

    // ── AFILIADO ──────────────────────────────────────────────────
    if (loginType === "affiliate") {
      const cleanCpf = loginCpf.replace(/\D/g, "");
      if (cleanCpf.length !== 11) { setError("CPF inválido (11 dígitos)."); return; }
      if (!loginPassword.trim()) { setError("Digite a senha de acesso."); return; }
      setLoading(true);
      try {
        // Check affiliate doc first
        const affSnap = await getDoc(doc(db, "affiliates", cleanCpf));
        if (!affSnap.exists()) { setError("CPF não credenciado como afiliado."); setLoading(false); return; }

        const affData = affSnap.data();
        if (affData.status === "paused") { setError("Conta de afiliado suspensa pelo administrador."); setLoading(false); return; }
        if (affData.password !== loginPassword.trim()) { setError("Senha incorreta."); setLoading(false); return; }

        // Get or create user doc for affiliate
        const userRef = doc(db, "users", cleanCpf);
        const userSnap = await getDoc(userRef);
        let userProfile: UserProfile;

        if (userSnap.exists()) {
          userProfile = { ...userSnap.data() as UserProfile, isCreator: true };
        } else {
          userProfile = {
            uid: cleanCpf, name: affData.name || "Afiliado", cpf: cleanCpf,
            phone: "", birthDate: "1995-01-01", photo: "",
            email: `${cleanCpf}@pixsorteios.com`, isAdmin: false, isCreator: true,
            password: affData.password, maxRaffles: affData.maxRaffles || 1,
            createdAt: new Date().toISOString()
          };
          await setDoc(userRef, userProfile);
        }

        localStorage.setItem("lucky_user_cpf", cleanCpf);
        onLoginSuccess(userProfile);
        onClose();
      } catch (err: any) {
        setError("Erro ao autenticar. Verifique sua conexão.");
      } finally { setLoading(false); }
      return;
    }

    // ── USUÁRIO COMUM ─────────────────────────────────────────────
    const cleanCpf = loginCpf.replace(/\D/g, "");
    if (cleanCpf.length !== 11) { setError("CPF inválido (11 dígitos)."); return; }
    setLoading(true);
    try {
      const userSnap = await getDoc(doc(db, "users", cleanCpf));
      if (!userSnap.exists()) {
        setError("CPF não cadastrado. Clique em 'Criar Conta' para se registrar.");
        setLoading(false); return;
      }
      const userData = userSnap.data() as UserProfile;
      // Impede afiliado/admin de usar o login de usuário comum
      if (userData.isAdmin) { setError("Use o login Admin para esta conta."); setLoading(false); return; }
      localStorage.setItem("lucky_user_cpf", cleanCpf);
      onLoginSuccess(userData);
      onClose();
    } catch (err: any) {
      setError("Erro ao autenticar. Verifique sua conexão.");
    } finally { setLoading(false); }
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    const cleanCpf = regCpf.replace(/\D/g, "");
    if (cleanCpf.length !== 11) { setError("Insira o CPF completo (11 dígitos)."); return; }
    if (cleanCpf === "00000000000" || regName.toLowerCase().includes("admin")) {
      setError("Nome ou CPF reservado para o sistema."); return;
    }
    const cleanPhone = regPhone.replace(/\D/g, "");
    if (cleanPhone.length < 10) { setError("Insira um telefone com DDD válido."); return; }
    if (!regName.trim()) { setError("Nome completo é obrigatório."); return; }
    if (!regPhoto) { setError("Envie uma foto de perfil."); return; }

    setLoading(true);
    try {
      const userRef = doc(db, "users", cleanCpf);
      const existing = await getDoc(userRef);
      if (existing.exists()) {
        setError("CPF já cadastrado. Faça login!"); setLoading(false); return;
      }

      // Verificar se é afiliado cadastrado pelo admin
      const affSnap = await getDoc(doc(db, "affiliates", cleanCpf));
      const isCreator = affSnap.exists() && affSnap.data().status !== "paused";

      const newProfile: UserProfile = {
        uid: cleanCpf, name: regName.trim(), cpf: cleanCpf, phone: regPhone.trim(),
        birthDate: "1995-01-01", photo: regPhoto, email: `${cleanCpf}@pixsorteios.com`,
        isAdmin: false, isCreator, createdAt: new Date().toISOString(),
        maxRaffles: affSnap.exists() ? (affSnap.data().maxRaffles || 1) : undefined
      };

      await setDoc(userRef, newProfile);
      localStorage.setItem("lucky_user_cpf", cleanCpf);
      onLoginSuccess(newProfile);
      onClose();
    } catch (err: any) {
      setError("Falha ao salvar conta: " + err.message);
    } finally { setLoading(false); }
  };

  const inputCls = "w-full bg-white border border-zinc-200 focus:outline-none focus:ring-2 focus:ring-blue-500/40 focus:border-blue-600 rounded-xl px-4 py-3 text-xs text-zinc-800 placeholder-zinc-400 font-medium transition";
  const labelCls = "block text-[9px] uppercase tracking-wider font-black text-zinc-500 mb-1.5";

  return (
    <div className="fixed inset-0 z-50 bg-zinc-900/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        className="w-full max-w-md bg-white border border-zinc-200 rounded-[28px] overflow-hidden shadow-2xl"
      >
        {/* Header */}
        <div className="px-6 py-5 border-b border-zinc-100 flex items-center justify-between bg-gradient-to-br from-blue-600 to-blue-700">
          <div>
            <h3 className="font-extrabold text-sm text-white uppercase tracking-wider flex items-center gap-2">
              <LogIn size={16} />
              <span>Acesso à Plataforma</span>
            </h3>
            <p className="text-[10px] text-blue-200 mt-0.5">PIX Sorteios — Login Seguro</p>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg border border-blue-500 text-blue-200 hover:text-white hover:bg-blue-500 transition cursor-pointer">
            <X size={16} />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-zinc-100 p-1.5 bg-zinc-50">
          {(["login", "register"] as const).map(tab => (
            <button key={tab} onClick={() => { setActiveTab(tab); setError(""); }}
              className={`flex-1 py-2.5 rounded-xl text-[11px] font-black uppercase tracking-wider transition cursor-pointer ${activeTab === tab ? "bg-white border border-zinc-200 text-zinc-800 shadow-sm" : "text-zinc-500 hover:text-zinc-700"}`}>
              {tab === "login" ? "Fazer Login" : "Criar Conta"}
            </button>
          ))}
        </div>

        <div className="p-6 space-y-4">
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-xl p-3.5 text-[11px] font-bold text-red-700 flex gap-2">
              <ShieldAlert size={14} className="shrink-0 mt-0.5 text-red-600" />
              <span>{error}</span>
            </div>
          )}

          {activeTab === "login" ? (
            <form onSubmit={handleLoginSubmit} className="space-y-4">
              {/* Type selector */}
              <div className="flex gap-1 p-1 rounded-xl bg-slate-100 border border-zinc-200">
                {([
                  { val: "user", label: "Participante" },
                  { val: "affiliate", label: "Afiliado" },
                  { val: "admin", label: "Admin" },
                ] as const).map(({ val, label }) => (
                  <button key={val} type="button"
                    onClick={() => { setLoginType(val); setLoginCpf(""); setError(""); }}
                    className={`flex-1 py-2 rounded-lg text-[9px] font-black uppercase tracking-wider cursor-pointer transition ${loginType === val ? "bg-white text-zinc-800 shadow-sm border border-zinc-200" : "text-zinc-500 hover:text-zinc-700"}`}>
                    {label}
                  </button>
                ))}
              </div>

              {/* CPF / Username field */}
              <div>
                <label className={labelCls}>
                  {loginType === "admin" ? "Usuário Administrador" : "CPF do Participante"}
                </label>
                <div className="relative">
                  <span className="absolute left-3.5 top-3.5 text-zinc-400"><CreditCard size={15} /></span>
                  <input type="text" required
                    placeholder={loginType === "admin" ? "admicarlos" : "000.000.000-00"}
                    value={loginCpf}
                    onChange={e => setLoginCpf(loginType === "admin" ? e.target.value : formatCPF(e.target.value))}
                    className={inputCls + " pl-11"} />
                </div>
              </div>

              {/* Password (affiliate & admin only) */}
              {loginType !== "user" && (
                <div>
                  <label className={labelCls}>Senha de Acesso</label>
                  <div className="relative">
                    <input type={showPass ? "text" : "password"} required
                      placeholder="••••••••"
                      value={loginPassword}
                      onChange={e => setLoginPassword(e.target.value)}
                      className={inputCls + " pr-10"} />
                    <button type="button" onClick={() => setShowPass(!showPass)}
                      className="absolute right-3 top-3 text-zinc-400 hover:text-zinc-600 cursor-pointer">
                      {showPass ? <EyeOff size={15} /> : <Eye size={15} />}
                    </button>
                  </div>
                </div>
              )}

              <button type="submit" disabled={loading}
                className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-black uppercase tracking-wider rounded-xl cursor-pointer transition shadow flex items-center justify-center gap-2">
                {loading ? <><Loader2 size={14} className="animate-spin" /><span>Verificando...</span></> : <span>Entrar</span>}
              </button>

              {loginType === "user" && (
                <p className="text-[10px] text-zinc-400 text-center">
                  Não tem conta?{" "}
                  <button type="button" onClick={() => setActiveTab("register")} className="text-blue-600 font-black hover:underline cursor-pointer">
                    Cadastre-se
                  </button>
                </p>
              )}
            </form>
          ) : (
            <form onSubmit={handleRegisterSubmit} className="space-y-4">
              <div>
                <label className={labelCls}>Nome Completo</label>
                <div className="relative">
                  <span className="absolute left-3.5 top-3.5 text-zinc-400"><User size={15} /></span>
                  <input type="text" required placeholder="Seu nome oficial" value={regName}
                    onChange={e => setRegName(e.target.value)} className={inputCls + " pl-11"} />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className={labelCls}>CPF</label>
                  <div className="relative">
                    <span className="absolute left-3.5 top-3.5 text-zinc-400"><CreditCard size={15} /></span>
                    <input type="text" required placeholder="000.000.000-00" value={regCpf}
                      onChange={e => setRegCpf(formatCPF(e.target.value))} className={inputCls + " pl-11"} />
                  </div>
                </div>
                <div>
                  <label className={labelCls}>WhatsApp</label>
                  <div className="relative">
                    <span className="absolute left-3.5 top-3.5 text-zinc-400"><Phone size={15} /></span>
                    <input type="text" required placeholder="(00) 00000-0000" value={regPhone}
                      onChange={e => setRegPhone(formatPhone(e.target.value))} className={inputCls + " pl-11"} />
                  </div>
                </div>
              </div>

              <div>
                <label className={labelCls}>Foto de Perfil</label>
                <div onClick={() => fileInputRef.current?.click()}
                  className="border-2 border-dashed border-zinc-200 hover:border-blue-500/60 rounded-xl bg-slate-50 py-4 px-4 text-center cursor-pointer transition">
                  <input type="file" ref={fileInputRef} accept="image/*" onChange={handlePhotoUpload} className="hidden" />
                  {regPhoto ? (
                    <div className="flex items-center justify-center space-x-3">
                      <img src={regPhoto} alt="Preview" className="h-10 w-10 rounded-full object-cover border border-zinc-200 shadow" />
                      <div className="text-left">
                        <p className="text-[10px] font-black text-blue-600 uppercase">Foto pronta!</p>
                        <p className="text-[8px] text-zinc-500">Clique para alterar</p>
                      </div>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center space-y-1 text-zinc-400">
                      <Upload size={18} />
                      <p className="text-[10px] font-bold text-zinc-500">Enviar foto de perfil</p>
                      <p className="text-[8px] text-zinc-400">Arraste ou clique para selecionar</p>
                    </div>
                  )}
                </div>
              </div>

              <button type="submit" disabled={loading}
                className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-black uppercase tracking-wider rounded-xl cursor-pointer transition shadow flex items-center justify-center gap-2">
                {loading ? <><Loader2 size={14} className="animate-spin" /><span>Criando conta...</span></> : <span>Criar Conta & Entrar</span>}
              </button>
            </form>
          )}
        </div>
      </motion.div>
    </div>
  );
}
