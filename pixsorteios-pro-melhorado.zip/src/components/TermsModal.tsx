import React, { useState, useEffect } from "react";
import { X, ShieldCheck, Loader2 } from "lucide-react";
import { doc, onSnapshot } from "firebase/firestore";
import { db } from "../firebase";
import { motion } from "motion/react";

interface TermsModalProps {
  onClose: () => void;
}

const DEFAULT_TERMS = `1. Elegibilidade e Identificação

Para adquirir e concorrer a qualquer sorteio, o usuário deverá preencher obrigatoriamente um perfil contendo seu nome completo, CPF, contato de telefone/WhatsApp e foto local. A foto e informações adicionadas servem como certificação contra lavagem de dinheiro, garantindo transparência completa.

2. Reservas e Pagamentos

Ao escolher um número no grid do produto, o mesmo ficará temporariamente reservado com status de "pendência" exclusivo do seu CPF. O usuário deverá realizar o pagamento correspondente por meio da chave Pix copia e cola ou QR Code exibidos na tela, e anexar obrigatoriamente a imagem do comprovante direto da interface.

3. Liberação de Bilhetes

Cada comprovante é analisado minuciosamente pelo nosso administrador contra dados de CPF informados na transação. O bilhete só será oficializado ("pago/confirmado") no momento em que o administrador validar o recebimento bancário no cofre central e marcar nos registros admin. Contestações fraudulentas resultarão em suspensão imediata da conta do CPF agressor.

4. Sorteio e Entrega

O sorteio é executado na data acordada com base nas numerações sorteadas pelos canais centrais da Loteria Federal do Brasil. O ganhador será contatado no telefone do perfil para coordenação de entrega do produto físico ou transferência de valor PIX equivalente.`;

export default function TermsModal({ onClose }: TermsModalProps) {
  const [termsText, setTermsText] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsub = onSnapshot(doc(db, "config", "terms"), (docSnap) => {
      if (docSnap.exists()) {
        setTermsText(docSnap.data().content || DEFAULT_TERMS);
      } else {
        setTermsText(DEFAULT_TERMS);
      }
      setLoading(false);
    }, (err) => {
      console.warn("Error loading terms (using offline fallback terms):", err);
      setTermsText(DEFAULT_TERMS);
      setLoading(false);
    });

    return () => unsub();
  }, []);

  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4 backdrop-blur-sm select-none">
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="w-full max-w-lg bg-white border border-slate-200 text-slate-800 rounded-2xl overflow-hidden shadow-2xl"
      >
        <div className="flex items-center justify-between bg-blue-950 px-6 py-4 border-b border-blue-900 text-white">
          <div className="flex items-center space-x-2">
            <ShieldCheck className="text-blue-300" size={20} />
            <span className="font-extrabold text-sm uppercase text-white tracking-wider">Regulamento & Termos</span>
          </div>
          <button onClick={onClose} className="text-slate-300 hover:text-white transition cursor-pointer">
            <X size={20} />
          </button>
        </div>

        <div className="p-6 space-y-4 text-xs text-slate-600 max-h-[350px] overflow-y-auto leading-relaxed text-left">
          {loading ? (
            <div className="flex items-center justify-center py-12 gap-2 text-slate-400">
              <Loader2 className="animate-spin" size={16} />
              <span className="font-bold">Carregando termos e regulamentos...</span>
            </div>
          ) : (
            <div className="space-y-4 whitespace-pre-line">
              {termsText.split("\n\n").map((para, idx) => {
                if (!para.trim()) return null;
                const isHeading = /^\d+\.\s/.test(para.trim());
                return (
                  <p 
                    key={idx} 
                    className={`${isHeading ? "font-extrabold text-blue-950 text-xs uppercase mt-4 mb-1" : "text-slate-600"}`}
                  >
                    {para}
                  </p>
                );
              })}
            </div>
          )}
        </div>

        <div className="p-4 bg-slate-50 border-t border-slate-100 flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2 bg-blue-900 hover:bg-blue-800 font-bold text-white rounded-xl transition text-xs uppercase cursor-pointer"
          >
            Entendido
          </button>
        </div>
      </motion.div>
    </div>
  );
}
