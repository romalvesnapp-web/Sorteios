import React, { useState, useEffect } from "react";
import { collection, onSnapshot, query, where } from "firebase/firestore";
import { db, loginWithGoogle, logoutUser, handleFirestoreError, OperationType } from "../firebase";
import { Banner, UserProfile } from "../types";
import { Clover, LogIn, LogOut, ShieldAlert, Award, Grid, Clock, FileText, Menu, X } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface HeaderProps {
  user: any;
  profile: UserProfile | null;
  isAdmin: boolean;
  onOpenAdmin: () => void;
  onViewTickets: () => void;
  onOpenTerms: () => void;
  winnersCount?: number;
  showBanner: boolean;
  onCloseBanner: () => void;
}

export default function Header({ user, profile, isAdmin, onOpenAdmin, onViewTickets, onOpenTerms, winnersCount, showBanner, onCloseBanner }: HeaderProps) {
  const [banners, setBanners] = useState<Banner[]>([]);
  const [currentSlide, setCurrentSlide] = useState(0);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Load banners in real-time
  useEffect(() => {
    const q = query(collection(db, "banners"), where("active", "==", true));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const loadedBanners: Banner[] = [];
      snapshot.forEach((doc) => {
        loadedBanners.push({ id: doc.id, ...doc.data() } as Banner);
      });
      setBanners(loadedBanners);
    }, (error) => {
      console.warn("Error loading banners from firebase (falling back to empty/mock banners list): ", error);
      const errMsg = error?.message || String(error);
      const isQuota = errMsg.toLowerCase().includes("quota") ||
                      errMsg.toLowerCase().includes("limit") ||
                      errMsg.toLowerCase().includes("exhausted");
      if (!isQuota) {
        handleFirestoreError(error, OperationType.LIST, "banners");
      }
    });

    return () => unsubscribe();
  }, []);

  // Banner slideshow auto-play effect
  useEffect(() => {
    if (banners.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % banners.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [banners]);

  return (
    <header className="bg-white text-slate-800 select-none border-b border-slate-200 shadow-sm relative z-20">
      {/* Upper Navigation Bar */}
      <div className="mx-auto max-w-7xl px-4">
        <div className="flex h-16 items-center justify-between">
          {/* Logo Brand (Icon Only) */}
          <div className="flex items-center space-x-2 cursor-pointer group" onClick={() => window.location.reload()}>
            <Clover className="text-blue-600 animate-pulse fill-blue-500/10 group-hover:rotate-12 transition-transform duration-300" size={26} />
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center space-x-6 text-xs font-bold uppercase tracking-wider text-slate-600">
            <button onClick={() => window.location.reload()} className="hover:text-blue-600 transition cursor-pointer text-slate-650 font-extrabold">
              Início
            </button>
            <a href="#sorteios-section" className="hover:text-blue-600 transition cursor-pointer text-slate-650 font-extrabold">
              Sorteios
            </a>
            {winnersCount && winnersCount > 0 ? (
              <a href="#ganhadores-section" className="hover:text-blue-600 text-slate-650 transition cursor-pointer flex items-center gap-1 font-extrabold">
                <Award size={14} className="text-blue-600 animate-pulse" /> Ganhadores
              </a>
            ) : null}
            {user && profile && !profile.isAdmin && !profile.isCreator && (
              <button onClick={onViewTickets} className="hover:text-blue-600 transition cursor-pointer text-slate-650 font-extrabold font-sans">
                Meus Bilhetes
              </button>
            )}
            <button onClick={onOpenTerms} className="hover:text-blue-600 transition cursor-pointer flex items-center gap-1.5 text-slate-650 font-extrabold">
              <FileText size={14} /> Regulamento
            </button>

            {isAdmin && (
              <button
                onClick={onOpenAdmin}
                className="flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white px-3 py-1.5 rounded-lg text-xs font-black transition shadow-xs cursor-pointer uppercase"
              >
                <ShieldAlert size={14} /> Painel Adm
              </button>
            )}
          </nav>

          {/* User Auth Badge Section */}
          <div className="hidden md:flex items-center space-x-3">
            {profile ? (
              <div className="flex items-center space-x-2.5 bg-slate-50 p-1.5 pr-3.5 rounded-full border border-slate-200">
                {profile.photo ? (
                  <img
                    src={profile.photo}
                    alt={profile.name}
                    referrerPolicy="no-referrer"
                    className="h-8 w-8 rounded-full object-cover border border-slate-200"
                  />
                ) : (
                  <div className="h-8 w-8 bg-blue-50 rounded-full flex items-center justify-center text-blue-600 font-bold border border-slate-205">
                    {profile.name.charAt(0).toUpperCase()}
                  </div>
                )}
                <div className="text-left text-xs font-medium">
                  <p className="text-slate-800 font-extrabold leading-tight truncate max-w-[110px]">{profile.name}</p>
                  <p className="text-slate-500 text-[10px] truncate max-w-[110px]">{profile.phone}</p>
                </div>
                <button
                  onClick={logoutUser}
                  title="Sair do App"
                  className="p-1 text-slate-400 hover:text-red-550 hover:scale-105 transition duration-150 cursor-pointer"
                >
                  <LogOut size={15} />
                </button>
              </div>
            ) : user && isAdmin ? (
              <div className="flex items-center space-x-2.5 bg-blue-50 p-1.5 pr-3.5 rounded-full border border-blue-200">
                <div className="h-8 w-8 bg-blue-605 rounded-full flex items-center justify-center text-white font-black shadow-xs">
                  A
                </div>
                <div className="text-left text-xs">
                  <p className="text-blue-650 font-black">LOGIN ADMIN</p>
                  <p className="text-slate-500 text-[10px]">{user.email}</p>
                </div>
                <button
                  onClick={logoutUser}
                  title="Sair"
                  className="p-1 text-slate-400 hover:text-red-550 hover:scale-105 transition cursor-pointer"
                >
                  <LogOut size={15} />
                </button>
              </div>
            ) : (
              <button
                onClick={loginWithGoogle}
                className="flex items-center space-x-1.5 bg-blue-600 hover:bg-blue-700 text-white font-black text-xs uppercase px-4.5 py-2.5 rounded-xl transition shadow-xs hover:scale-102 cursor-pointer duration-200"
              >
                <LogIn size={15} className="stroke-[2.5]" />
                <span>Entrar no Google</span>
              </button>
            )}
          </div>

          {/* Mobile menu toggle button */}
          <div className="flex md:hidden items-center space-x-2">
            {isAdmin && (
              <button
                onClick={onOpenAdmin}
                className="flex items-center gap-1 bg-blue-600 text-white px-2.5 py-1.5 rounded-lg text-xs font-extrabold hover:bg-blue-700 transition shadow-xs"
              >
                <ShieldAlert size={14} /> ADM
              </button>
            )}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-1.5 rounded-lg bg-slate-50 border border-slate-200 text-slate-600 hover:text-slate-950"
            >
              {mobileMenuOpen ? <X size={22} /> : <Menu size={22} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Navigation */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-white border-t border-slate-200 shadow-md relative z-30"
          >
            <div className="px-4 py-4 space-y-3 font-semibold uppercase tracking-wider text-xs">
              <button
                onClick={() => {
                  window.location.reload();
                  setMobileMenuOpen(false);
                }}
                className="block w-full text-left py-2 hover:text-blue-600 text-slate-600"
              >
                Início
              </button>
              <a
                href="#sorteios-section"
                onClick={() => setMobileMenuOpen(false)}
                className="block w-full text-left py-2 hover:text-blue-600 text-slate-600"
              >
                Sorteios
              </a>
              {winnersCount !== undefined && winnersCount > 0 ? (
                <a
                  href="#ganhadores-section"
                  onClick={() => setMobileMenuOpen(false)}
                  className="w-full text-left py-2 hover:text-blue-600 text-slate-600 flex items-center gap-1"
                >
                  <Award size={14} className="text-blue-600 animate-pulse" /> Ganhadores
                </a>
              ) : null}
              {user && profile && !profile.isAdmin && !profile.isCreator && (
                <button
                  onClick={() => {
                    onViewTickets();
                    setMobileMenuOpen(false);
                  }}
                  className="block w-full text-left py-2 hover:text-blue-600 text-slate-600 font-sans"
                >
                  Meus Bilhetes
                </button>
              )}
              <button
                onClick={() => {
                  onOpenTerms();
                  setMobileMenuOpen(false);
                }}
                className="block w-full text-left py-2 hover:text-blue-600 text-slate-600"
              >
                Termos de Uso
              </button>

              <div className="pt-4 border-t border-slate-100 flex flex-col items-center">
                {profile ? (
                  <div className="flex flex-col items-center space-y-2">
                    <div className="flex items-center space-x-2">
                      <img
                        src={profile.photo}
                        alt={profile.name}
                        referrerPolicy="no-referrer"
                        className="h-8 w-8 rounded-full border border-slate-205 object-cover"
                      />
                      <span className="text-slate-800 text-sm font-bold">{profile.name}</span>
                    </div>
                    <button
                      onClick={() => {
                        logoutUser();
                        setMobileMenuOpen(false);
                      }}
                      className="text-red-500 font-bold hover:underline transition text-xs mt-1"
                    >
                      Sair da Conta
                    </button>
                  </div>
                ) : user && isAdmin ? (
                  <div className="flex flex-col items-center space-y-2">
                    <span className="text-blue-600 text-xs font-bold">LOGADO COMO ADMIN</span>
                    <button
                      onClick={() => {
                        logoutUser();
                        setMobileMenuOpen(false);
                      }}
                      className="text-red-500 font-bold hover:underline text-xs"
                    >
                      Sair
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => {
                      loginWithGoogle();
                      setMobileMenuOpen(false);
                    }}
                    className="w-full flex items-center justify-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white font-black py-2.5 rounded-xl transition"
                  >
                    <LogIn size={15} />
                    <span>ENTRAR NO GOOGLE</span>
                  </button>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Campaign Banner Header Container */}
      {showBanner && (
        <div className="relative w-full overflow-hidden bg-slate-950 border-b border-blue-500/15">
          <button
            onClick={onCloseBanner}
            title="Remover banner"
            className="absolute top-2.5 right-2.5 z-30 p-1.5 rounded-full bg-black/60 hover:bg-black/90 hover:scale-105 hover:text-white text-slate-300 transition shadow-lg border border-white/10 cursor-pointer"
          >
            <X size={13} className="stroke-[2.5]" />
          </button>

          <AnimatePresence mode="wait">
            {banners.length > 0 ? (
              <motion.div
                key={currentSlide}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.6 }}
                className="relative w-full h-[120px] sm:h-[180px] md:h-[220px] lg:h-[260px]"
              >
                <img
                  src={banners[currentSlide].image}
                  alt="Banner principal"
                  className="w-full h-full object-cover cursor-pointer"
                  onClick={() => {
                    const targetLink = banners[currentSlide]?.link;
                    if (targetLink && targetLink !== "#") window.open(targetLink, "_blank");
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/55 via-transparent to-transparent pointer-events-none" />
              </motion.div>
            ) : (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="relative w-full h-[120px] sm:h-[180px] md:h-[220px] lg:h-[260px]"
              >
                <img
                  src="https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1600&auto=format&fit=crop&q=80"
                  alt="Banner padrão"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/55 via-transparent to-transparent pointer-events-none" />
                <div className="absolute inset-0 bg-[radial-gradient(ellipse_60%_50%_at_50%_50%,rgba(37,99,235,0.05),transparent_100%)] pointer-events-none" />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      )}
    </header>
  );
}
