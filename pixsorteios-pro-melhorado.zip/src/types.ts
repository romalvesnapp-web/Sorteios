export interface UserProfile {
  uid: string;
  name: string;
  cpf: string;
  phone: string;
  birthDate: string;
  photo?: string;
  email: string;
  isAdmin: boolean;
  createdAt: string;
  isCreator?: boolean;
  password?: string;
  maxRaffles?: number;
  status?: "active" | "paused";
}

export interface AffiliateProfile {
  cpf: string;
  name: string;
  password: string;
  maxRaffles: number;
  status: "active" | "paused";
  createdAt: string;
  phone?: string;
  pixKey?: string;
  pixReceiver?: string;
}

export type RaffleStatus = "active" | "finished";

export interface Raffle {
  id: string;
  title: string;
  description: string;
  image: string;
  pricePerTicket: number;
  totalNumbers: number;
  status: RaffleStatus;
  award: string;
  createdAt: string;
  creatorUid?: string;
  creatorName?: string;
  pixKey?: string;
  pixReceiver?: string;
}

export type TicketStatus = "pending" | "confirmed" | "cancelled";

export interface Ticket {
  id: string;
  raffleId: string;
  ticketNumber: number;
  userCpf: string;
  userName: string;
  userPhone: string;
  status: TicketStatus;
  paymentReceipt?: string;
  reservedAt: string;
  confirmedAt?: string;
}

export interface Banner {
  id: string;
  image: string;
  link: string;
  active: boolean;
  updatedAt: string;
}

export interface PixConfig {
  id: string;
  pixKey: string;
  pixReceiver: string;
}

export interface Winner {
  id: string;
  raffleId: string;
  raffleTitle: string;
  userName: string;
  userCpf: string;
  winningNumber: number;
  award: string;
  prizePhoto: string;
  userProfile?: string;
  announcedAt: string;
}
