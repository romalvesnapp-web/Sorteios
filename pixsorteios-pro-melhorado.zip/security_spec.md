# Security Specification (Abac Rules)

## 1. Data Invariants

1. **User Identity Invariant**: A user's profile document ID must match their verified CPF. The profile's `uid` must match the authenticated `request.auth.uid`. No user can modify another user's profile.
2. **Admin Supremacy Invariant**: The Google account `romalvesnapp@gmail.com` with a verified email is the absolute Administrator, bypasses standard user constraints on raffle configuration and ticket confirmation, and is the only role allowed to create or modify Raffles, Banners, and System configuration.
3. **Ticket Selection Atomicity**: A ticket document must have an ID of `{raffleId}_{ticketNumber}`. This guarantees that only one user can hold a reservation on a specific ticket number.
4. **Email Protection**: No standard authenticated user can declare themselves an Admin (`isAdmin = true`) or spoof the administrator email.

## 2. The "Dirty Dozen" Payloads

1. **Admin Spoof in Profile**: A user tries to create their profile in `users/{cpf}` with `"isAdmin": true`.
2. **User Identity Theft**: A logged-in user with UID `userA` attempts to write a profile in `users/00000000000` with `"uid": "userB"`.
3. **Unauthenticated User Profile Creation**: Creating a profile in `users` while not signed in.
4. **Spoofed Admin Bypass**: A user signs in with email `romalvesnapp@gmail.com` but with `email_verified = false` and tries to write a Raffle.
5. **Raffle Creation by Non-Admin**: Standard user `userA` attempts to POST to `raffles/raffle123`.
6. **Banner Hijacking**: A normal user tries to update custom banners in `banners/banner1`.
7. **Ticket Double Purchase**: A user attempts to change double-booked tickets by editing an existing confirmed ticket belonging to another CPF.
8. **Malicious State Shortcut**: A user creates a ticket reservation with `status: "confirmed"` directly on creation, skipping the admin payment step.
9. **Tampering with Pricing**: A user tries to update the `pricePerTicket` of an existing raffle.
10. **Receipt Hijacking**: A user updates another user's ticket with their own Base64 payment receipt.
11. **Massive String/Buffer Injection**: A user tries to inject a huge string payload (> 200KB) into a ticket's status field.
12. **Anonymous Collection Querying**: Querying list of users without specifying correct scope or being the Admin.

## 3. Test Cases Draft

All 12 malicious operations will be blocked by the Firestore rules which will be written in `/firestore.rules`.
The rule conditions will enforce:
- `request.auth != null`
- Admin is identified strictly of `request.auth.token.email == "romalvesnapp@gmail.com" && request.auth.token.email_verified == true`.
- Normal operations require `request.auth.token.email_verified == true`.
- User can only read or write their own profile where the profile `uid` matches `request.auth.uid`.
- Standard users are forbidden from setting `isAdmin` to true.
- A user can only reserve their own ticket (matching their CPF and name) with `status == "pending"`.
- A user can only write their base64 receipt to a ticket where `userCpf == user's CPF` and `status == "pending"`.
- Banners, Config, and Raffles are read-only for standard users and full read-write for Admin.
